(function (T, Ye) {
    typeof exports == "object" && typeof module < "u" ? module.exports = Ye() : typeof define == "function" && define.amd ? define(Ye) : (T = typeof globalThis < "u" ? globalThis : T || self, T.GrapesJsPlugins_prosemirror = Ye())
})(this, function () {
    "use strict";

    function T(n) {
        this.content = n
    }

    T.prototype = {
        constructor: T, find: function (n) {
            for (var e = 0; e < this.content.length; e += 2) if (this.content[e] === n) return e;
            return -1
        }, get: function (n) {
            var e = this.find(n);
            return e == -1 ? void 0 : this.content[e + 1]
        }, update: function (n, e, t) {
            var r = t && t != n ? this.remove(t) : this, i = r.find(n), s = r.content.slice();
            return i == -1 ? s.push(t || n, e) : (s[i + 1] = e, t && (s[i] = t)), new T(s)
        }, remove: function (n) {
            var e = this.find(n);
            if (e == -1) return this;
            var t = this.content.slice();
            return t.splice(e, 2), new T(t)
        }, addToStart: function (n, e) {
            return new T([n, e].concat(this.remove(n).content))
        }, addToEnd: function (n, e) {
            var t = this.remove(n).content.slice();
            return t.push(n, e), new T(t)
        }, addBefore: function (n, e, t) {
            var r = this.remove(e), i = r.content.slice(), s = r.find(n);
            return i.splice(s == -1 ? i.length : s, 0, e, t), new T(i)
        }, forEach: function (n) {
            for (var e = 0; e < this.content.length; e += 2) n(this.content[e], this.content[e + 1])
        }, prepend: function (n) {
            return n = T.from(n), n.size ? new T(n.content.concat(this.subtract(n).content)) : this
        }, append: function (n) {
            return n = T.from(n), n.size ? new T(this.subtract(n).content.concat(n.content)) : this
        }, subtract: function (n) {
            var e = this;
            n = T.from(n);
            for (var t = 0; t < n.content.length; t += 2) e = e.remove(n.content[t]);
            return e
        }, toObject: function () {
            var n = {};
            return this.forEach(function (e, t) {
                n[e] = t
            }), n
        }, get size() {
            return this.content.length >> 1
        }
    }, T.from = function (n) {
        if (n instanceof T) return n;
        var e = [];
        if (n) for (var t in n) e.push(t, n[t]);
        return new T(e)
    };

    function Ye(n, e, t) {
        for (let r = 0; ; r++) {
            if (r == n.childCount || r == e.childCount) return n.childCount == e.childCount ? null : t;
            let i = n.child(r), s = e.child(r);
            if (i == s) {
                t += i.nodeSize;
                continue
            }
            if (!i.sameMarkup(s)) return t;
            if (i.isText && i.text != s.text) {
                for (let o = 0; i.text[o] == s.text[o]; o++) t++;
                return t
            }
            if (i.content.size || s.content.size) {
                let o = Ye(i.content, s.content, t + 1);
                if (o != null) return o
            }
            t += i.nodeSize
        }
    }

    function Er(n, e, t, r) {
        for (let i = n.childCount, s = e.childCount; ;) {
            if (i == 0 || s == 0) return i == s ? null : {a: t, b: r};
            let o = n.child(--i), l = e.child(--s), a = o.nodeSize;
            if (o == l) {
                t -= a, r -= a;
                continue
            }
            if (!o.sameMarkup(l)) return {a: t, b: r};
            if (o.isText && o.text != l.text) {
                let c = 0, f = Math.min(o.text.length, l.text.length);
                for (; c < f && o.text[o.text.length - c - 1] == l.text[l.text.length - c - 1];) c++, t--, r--;
                return {a: t, b: r}
            }
            if (o.content.size || l.content.size) {
                let c = Er(o.content, l.content, t - 1, r - 1);
                if (c) return c
            }
            t -= a, r -= a
        }
    }

    class y {
        constructor(e, t) {
            if (this.content = e, this.size = t || 0, t == null) for (let r = 0; r < e.length; r++) this.size += e[r].nodeSize
        }

        nodesBetween(e, t, r, i = 0, s) {
            for (let o = 0, l = 0; l < t; o++) {
                let a = this.content[o], c = l + a.nodeSize;
                if (c > e && r(a, i + l, s || null, o) !== !1 && a.content.size) {
                    let f = l + 1;
                    a.nodesBetween(Math.max(0, e - f), Math.min(a.content.size, t - f), r, i + f)
                }
                l = c
            }
        }

        descendants(e) {
            this.nodesBetween(0, this.size, e)
        }

        textBetween(e, t, r, i) {
            let s = "", o = !0;
            return this.nodesBetween(e, t, (l, a) => {
                let c = l.isText ? l.text.slice(Math.max(e, a) - a, t - a) : l.isLeaf ? i ? typeof i == "function" ? i(l) : i : l.type.spec.leafText ? l.type.spec.leafText(l) : "" : "";
                l.isBlock && (l.isLeaf && c || l.isTextblock) && r && (o ? o = !1 : s += r), s += c
            }, 0), s
        }

        append(e) {
            if (!e.size) return this;
            if (!this.size) return e;
            let t = this.lastChild, r = e.firstChild, i = this.content.slice(), s = 0;
            for (t.isText && t.sameMarkup(r) && (i[i.length - 1] = t.withText(t.text + r.text), s = 1); s < e.content.length; s++) i.push(e.content[s]);
            return new y(i, this.size + e.size)
        }

        cut(e, t = this.size) {
            if (e == 0 && t == this.size) return this;
            let r = [], i = 0;
            if (t > e) for (let s = 0, o = 0; o < t; s++) {
                let l = this.content[s], a = o + l.nodeSize;
                a > e && ((o < e || a > t) && (l.isText ? l = l.cut(Math.max(0, e - o), Math.min(l.text.length, t - o)) : l = l.cut(Math.max(0, e - o - 1), Math.min(l.content.size, t - o - 1))), r.push(l), i += l.nodeSize), o = a
            }
            return new y(r, i)
        }

        cutByIndex(e, t) {
            return e == t ? y.empty : e == 0 && t == this.content.length ? this : new y(this.content.slice(e, t))
        }

        replaceChild(e, t) {
            let r = this.content[e];
            if (r == t) return this;
            let i = this.content.slice(), s = this.size + t.nodeSize - r.nodeSize;
            return i[e] = t, new y(i, s)
        }

        addToStart(e) {
            return new y([e].concat(this.content), this.size + e.nodeSize)
        }

        addToEnd(e) {
            return new y(this.content.concat(e), this.size + e.nodeSize)
        }

        eq(e) {
            if (this.content.length != e.content.length) return !1;
            for (let t = 0; t < this.content.length; t++) if (!this.content[t].eq(e.content[t])) return !1;
            return !0
        }

        get firstChild() {
            return this.content.length ? this.content[0] : null
        }

        get lastChild() {
            return this.content.length ? this.content[this.content.length - 1] : null
        }

        get childCount() {
            return this.content.length
        }

        child(e) {
            let t = this.content[e];
            if (!t) throw new RangeError("Index " + e + " out of range for " + this);
            return t
        }

        maybeChild(e) {
            return this.content[e] || null
        }

        forEach(e) {
            for (let t = 0, r = 0; t < this.content.length; t++) {
                let i = this.content[t];
                e(i, r, t), r += i.nodeSize
            }
        }

        findDiffStart(e, t = 0) {
            return Ye(this, e, t)
        }

        findDiffEnd(e, t = this.size, r = e.size) {
            return Er(this, e, t, r)
        }

        findIndex(e, t = -1) {
            if (e == 0) return Lt(0, e);
            if (e == this.size) return Lt(this.content.length, e);
            if (e > this.size || e < 0) throw new RangeError(`Position ${e} outside of fragment (${this})`);
            for (let r = 0, i = 0; ; r++) {
                let s = this.child(r), o = i + s.nodeSize;
                if (o >= e) return o == e || t > 0 ? Lt(r + 1, o) : Lt(r, i);
                i = o
            }
        }

        toString() {
            return "<" + this.toStringInner() + ">"
        }

        toStringInner() {
            return this.content.join(", ")
        }

        toJSON() {
            return this.content.length ? this.content.map(e => e.toJSON()) : null
        }

        static fromJSON(e, t) {
            if (!t) return y.empty;
            if (!Array.isArray(t)) throw new RangeError("Invalid input for Fragment.fromJSON");
            return new y(t.map(e.nodeFromJSON))
        }

        static fromArray(e) {
            if (!e.length) return y.empty;
            let t, r = 0;
            for (let i = 0; i < e.length; i++) {
                let s = e[i];
                r += s.nodeSize, i && s.isText && e[i - 1].sameMarkup(s) ? (t || (t = e.slice(0, i)), t[t.length - 1] = s.withText(t[t.length - 1].text + s.text)) : t && t.push(s)
            }
            return new y(t || e, r)
        }

        static from(e) {
            if (!e) return y.empty;
            if (e instanceof y) return e;
            if (Array.isArray(e)) return this.fromArray(e);
            if (e.attrs) return new y([e], e.nodeSize);
            throw new RangeError("Can not convert " + e + " to a Fragment" + (e.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""))
        }
    }

    y.empty = new y([], 0);
    const wn = {index: 0, offset: 0};

    function Lt(n, e) {
        return wn.index = n, wn.offset = e, wn
    }

    function Ht(n, e) {
        if (n === e) return !0;
        if (!(n && typeof n == "object") || !(e && typeof e == "object")) return !1;
        let t = Array.isArray(n);
        if (Array.isArray(e) != t) return !1;
        if (t) {
            if (n.length != e.length) return !1;
            for (let r = 0; r < n.length; r++) if (!Ht(n[r], e[r])) return !1
        } else {
            for (let r in n) if (!(r in e) || !Ht(n[r], e[r])) return !1;
            for (let r in e) if (!(r in n)) return !1
        }
        return !0
    }

    class O {
        constructor(e, t) {
            this.type = e, this.attrs = t
        }

        addToSet(e) {
            let t, r = !1;
            for (let i = 0; i < e.length; i++) {
                let s = e[i];
                if (this.eq(s)) return e;
                if (this.type.excludes(s.type)) t || (t = e.slice(0, i)); else {
                    if (s.type.excludes(this.type)) return e;
                    !r && s.type.rank > this.type.rank && (t || (t = e.slice(0, i)), t.push(this), r = !0), t && t.push(s)
                }
            }
            return t || (t = e.slice()), r || t.push(this), t
        }

        removeFromSet(e) {
            for (let t = 0; t < e.length; t++) if (this.eq(e[t])) return e.slice(0, t).concat(e.slice(t + 1));
            return e
        }

        isInSet(e) {
            for (let t = 0; t < e.length; t++) if (this.eq(e[t])) return !0;
            return !1
        }

        eq(e) {
            return this == e || this.type == e.type && Ht(this.attrs, e.attrs)
        }

        toJSON() {
            let e = {type: this.type.name};
            for (let t in this.attrs) {
                e.attrs = this.attrs;
                break
            }
            return e
        }

        static fromJSON(e, t) {
            if (!t) throw new RangeError("Invalid input for Mark.fromJSON");
            let r = e.marks[t.type];
            if (!r) throw new RangeError(`There is no mark type ${t.type} in this schema`);
            let i = r.create(t.attrs);
            return r.checkAttrs(i.attrs), i
        }

        static sameSet(e, t) {
            if (e == t) return !0;
            if (e.length != t.length) return !1;
            for (let r = 0; r < e.length; r++) if (!e[r].eq(t[r])) return !1;
            return !0
        }

        static setFrom(e) {
            if (!e || Array.isArray(e) && e.length == 0) return O.none;
            if (e instanceof O) return [e];
            let t = e.slice();
            return t.sort((r, i) => r.type.rank - i.type.rank), t
        }
    }

    O.none = [];

    class $t extends Error {
    }

    class x {
        constructor(e, t, r) {
            this.content = e, this.openStart = t, this.openEnd = r
        }

        get size() {
            return this.content.size - this.openStart - this.openEnd
        }

        insertAt(e, t) {
            let r = Ir(this.content, e + this.openStart, t);
            return r && new x(r, this.openStart, this.openEnd)
        }

        removeBetween(e, t) {
            return new x(Rr(this.content, e + this.openStart, t + this.openStart), this.openStart, this.openEnd)
        }

        eq(e) {
            return this.content.eq(e.content) && this.openStart == e.openStart && this.openEnd == e.openEnd
        }

        toString() {
            return this.content + "(" + this.openStart + "," + this.openEnd + ")"
        }

        toJSON() {
            if (!this.content.size) return null;
            let e = {content: this.content.toJSON()};
            return this.openStart > 0 && (e.openStart = this.openStart), this.openEnd > 0 && (e.openEnd = this.openEnd), e
        }

        static fromJSON(e, t) {
            if (!t) return x.empty;
            let r = t.openStart || 0, i = t.openEnd || 0;
            if (typeof r != "number" || typeof i != "number") throw new RangeError("Invalid input for Slice.fromJSON");
            return new x(y.fromJSON(e, t.content), r, i)
        }

        static maxOpen(e, t = !0) {
            let r = 0, i = 0;
            for (let s = e.firstChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.firstChild) r++;
            for (let s = e.lastChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.lastChild) i++;
            return new x(e, r, i)
        }
    }

    x.empty = new x(y.empty, 0, 0);

    function Rr(n, e, t) {
        let {index: r, offset: i} = n.findIndex(e), s = n.maybeChild(r), {index: o, offset: l} = n.findIndex(t);
        if (i == e || s.isText) {
            if (l != t && !n.child(o).isText) throw new RangeError("Removing non-flat range");
            return n.cut(0, e).append(n.cut(t))
        }
        if (r != o) throw new RangeError("Removing non-flat range");
        return n.replaceChild(r, s.copy(Rr(s.content, e - i - 1, t - i - 1)))
    }

    function Ir(n, e, t, r) {
        let {index: i, offset: s} = n.findIndex(e), o = n.maybeChild(i);
        if (s == e || o.isText) return n.cut(0, e).append(t).append(n.cut(e));
        let l = Ir(o.content, e - s - 1, t);
        return l && n.replaceChild(i, o.copy(l))
    }

    function $o(n, e, t) {
        if (t.openStart > n.depth) throw new $t("Inserted content deeper than insertion position");
        if (n.depth - t.openStart != e.depth - t.openEnd) throw new $t("Inconsistent open depths");
        return vr(n, e, t, 0)
    }

    function vr(n, e, t, r) {
        let i = n.index(r), s = n.node(r);
        if (i == e.index(r) && r < n.depth - t.openStart) {
            let o = vr(n, e, t, r + 1);
            return s.copy(s.content.replaceChild(i, o))
        } else if (t.content.size) if (!t.openStart && !t.openEnd && n.depth == r && e.depth == r) {
            let o = n.parent, l = o.content;
            return Ve(o, l.cut(0, n.parentOffset).append(t.content).append(l.cut(e.parentOffset)))
        } else {
            let {start: o, end: l} = Wo(t, n);
            return Ve(s, Br(n, o, l, e, r))
        } else return Ve(s, Wt(n, e, r))
    }

    function zr(n, e) {
        if (!e.type.compatibleContent(n.type)) throw new $t("Cannot join " + e.type.name + " onto " + n.type.name)
    }

    function Mn(n, e, t) {
        let r = n.node(t);
        return zr(r, e.node(t)), r
    }

    function Pe(n, e) {
        let t = e.length - 1;
        t >= 0 && n.isText && n.sameMarkup(e[t]) ? e[t] = n.withText(e[t].text + n.text) : e.push(n)
    }

    function mt(n, e, t, r) {
        let i = (e || n).node(t), s = 0, o = e ? e.index(t) : i.childCount;
        n && (s = n.index(t), n.depth > t ? s++ : n.textOffset && (Pe(n.nodeAfter, r), s++));
        for (let l = s; l < o; l++) Pe(i.child(l), r);
        e && e.depth == t && e.textOffset && Pe(e.nodeBefore, r)
    }

    function Ve(n, e) {
        return n.type.checkContent(e), n.copy(e)
    }

    function Br(n, e, t, r, i) {
        let s = n.depth > i && Mn(n, e, i + 1), o = r.depth > i && Mn(t, r, i + 1), l = [];
        return mt(null, n, i, l), s && o && e.index(i) == t.index(i) ? (zr(s, o), Pe(Ve(s, Br(n, e, t, r, i + 1)), l)) : (s && Pe(Ve(s, Wt(n, e, i + 1)), l), mt(e, t, i, l), o && Pe(Ve(o, Wt(t, r, i + 1)), l)), mt(r, null, i, l), new y(l)
    }

    function Wt(n, e, t) {
        let r = [];
        if (mt(null, n, t, r), n.depth > t) {
            let i = Mn(n, e, t + 1);
            Pe(Ve(i, Wt(n, e, t + 1)), r)
        }
        return mt(e, null, t, r), new y(r)
    }

    function Wo(n, e) {
        let t = e.depth - n.openStart, i = e.node(t).copy(n.content);
        for (let s = t - 1; s >= 0; s--) i = e.node(s).copy(y.from(i));
        return {start: i.resolveNoCache(n.openStart + t), end: i.resolveNoCache(i.content.size - n.openEnd - t)}
    }

    class gt {
        constructor(e, t, r) {
            this.pos = e, this.path = t, this.parentOffset = r, this.depth = t.length / 3 - 1
        }

        resolveDepth(e) {
            return e == null ? this.depth : e < 0 ? this.depth + e : e
        }

        get parent() {
            return this.node(this.depth)
        }

        get doc() {
            return this.node(0)
        }

        node(e) {
            return this.path[this.resolveDepth(e) * 3]
        }

        index(e) {
            return this.path[this.resolveDepth(e) * 3 + 1]
        }

        indexAfter(e) {
            return e = this.resolveDepth(e), this.index(e) + (e == this.depth && !this.textOffset ? 0 : 1)
        }

        start(e) {
            return e = this.resolveDepth(e), e == 0 ? 0 : this.path[e * 3 - 1] + 1
        }

        end(e) {
            return e = this.resolveDepth(e), this.start(e) + this.node(e).content.size
        }

        before(e) {
            if (e = this.resolveDepth(e), !e) throw new RangeError("There is no position before the top-level node");
            return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1]
        }

        after(e) {
            if (e = this.resolveDepth(e), !e) throw new RangeError("There is no position after the top-level node");
            return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1] + this.path[e * 3].nodeSize
        }

        get textOffset() {
            return this.pos - this.path[this.path.length - 1]
        }

        get nodeAfter() {
            let e = this.parent, t = this.index(this.depth);
            if (t == e.childCount) return null;
            let r = this.pos - this.path[this.path.length - 1], i = e.child(t);
            return r ? e.child(t).cut(r) : i
        }

        get nodeBefore() {
            let e = this.index(this.depth), t = this.pos - this.path[this.path.length - 1];
            return t ? this.parent.child(e).cut(0, t) : e == 0 ? null : this.parent.child(e - 1)
        }

        posAtIndex(e, t) {
            t = this.resolveDepth(t);
            let r = this.path[t * 3], i = t == 0 ? 0 : this.path[t * 3 - 1] + 1;
            for (let s = 0; s < e; s++) i += r.child(s).nodeSize;
            return i
        }

        marks() {
            let e = this.parent, t = this.index();
            if (e.content.size == 0) return O.none;
            if (this.textOffset) return e.child(t).marks;
            let r = e.maybeChild(t - 1), i = e.maybeChild(t);
            if (!r) {
                let l = r;
                r = i, i = l
            }
            let s = r.marks;
            for (var o = 0; o < s.length; o++) s[o].type.spec.inclusive === !1 && (!i || !s[o].isInSet(i.marks)) && (s = s[o--].removeFromSet(s));
            return s
        }

        marksAcross(e) {
            let t = this.parent.maybeChild(this.index());
            if (!t || !t.isInline) return null;
            let r = t.marks, i = e.parent.maybeChild(e.index());
            for (var s = 0; s < r.length; s++) r[s].type.spec.inclusive === !1 && (!i || !r[s].isInSet(i.marks)) && (r = r[s--].removeFromSet(r));
            return r
        }

        sharedDepth(e) {
            for (let t = this.depth; t > 0; t--) if (this.start(t) <= e && this.end(t) >= e) return t;
            return 0
        }

        blockRange(e = this, t) {
            if (e.pos < this.pos) return e.blockRange(this);
            for (let r = this.depth - (this.parent.inlineContent || this.pos == e.pos ? 1 : 0); r >= 0; r--) if (e.pos <= this.end(r) && (!t || t(this.node(r)))) return new Jt(this, e, r);
            return null
        }

        sameParent(e) {
            return this.pos - this.parentOffset == e.pos - e.parentOffset
        }

        max(e) {
            return e.pos > this.pos ? e : this
        }

        min(e) {
            return e.pos < this.pos ? e : this
        }

        toString() {
            let e = "";
            for (let t = 1; t <= this.depth; t++) e += (e ? "/" : "") + this.node(t).type.name + "_" + this.index(t - 1);
            return e + ":" + this.parentOffset
        }

        static resolve(e, t) {
            if (!(t >= 0 && t <= e.content.size)) throw new RangeError("Position " + t + " out of range");
            let r = [], i = 0, s = t;
            for (let o = e; ;) {
                let {index: l, offset: a} = o.content.findIndex(s), c = s - a;
                if (r.push(o, l, i + a), !c || (o = o.child(l), o.isText)) break;
                s = c - 1, i += a + 1
            }
            return new gt(t, r, s)
        }

        static resolveCached(e, t) {
            let r = Pr.get(e);
            if (r) for (let s = 0; s < r.elts.length; s++) {
                let o = r.elts[s];
                if (o.pos == t) return o
            } else Pr.set(e, r = new Jo);
            let i = r.elts[r.i] = gt.resolve(e, t);
            return r.i = (r.i + 1) % qo, i
        }
    }

    class Jo {
        constructor() {
            this.elts = [], this.i = 0
        }
    }

    const qo = 12, Pr = new WeakMap;

    class Jt {
        constructor(e, t, r) {
            this.$from = e, this.$to = t, this.depth = r
        }

        get start() {
            return this.$from.before(this.depth + 1)
        }

        get end() {
            return this.$to.after(this.depth + 1)
        }

        get parent() {
            return this.$from.node(this.depth)
        }

        get startIndex() {
            return this.$from.index(this.depth)
        }

        get endIndex() {
            return this.$to.indexAfter(this.depth)
        }
    }

    const Ko = Object.create(null);
    let Fe = class Dr {
        constructor(e, t, r, i = O.none) {
            this.type = e, this.attrs = t, this.marks = i, this.content = r || y.empty
        }

        get children() {
            return this.content.content
        }

        get nodeSize() {
            return this.isLeaf ? 1 : 2 + this.content.size
        }

        get childCount() {
            return this.content.childCount
        }

        child(e) {
            return this.content.child(e)
        }

        maybeChild(e) {
            return this.content.maybeChild(e)
        }

        forEach(e) {
            this.content.forEach(e)
        }

        nodesBetween(e, t, r, i = 0) {
            this.content.nodesBetween(e, t, r, i, this)
        }

        descendants(e) {
            this.nodesBetween(0, this.content.size, e)
        }

        get textContent() {
            return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "")
        }

        textBetween(e, t, r, i) {
            return this.content.textBetween(e, t, r, i)
        }

        get firstChild() {
            return this.content.firstChild
        }

        get lastChild() {
            return this.content.lastChild
        }

        eq(e) {
            return this == e || this.sameMarkup(e) && this.content.eq(e.content)
        }

        sameMarkup(e) {
            return this.hasMarkup(e.type, e.attrs, e.marks)
        }

        hasMarkup(e, t, r) {
            return this.type == e && Ht(this.attrs, t || e.defaultAttrs || Ko) && O.sameSet(this.marks, r || O.none)
        }

        copy(e = null) {
            return e == this.content ? this : new Dr(this.type, this.attrs, e, this.marks)
        }

        mark(e) {
            return e == this.marks ? this : new Dr(this.type, this.attrs, this.content, e)
        }

        cut(e, t = this.content.size) {
            return e == 0 && t == this.content.size ? this : this.copy(this.content.cut(e, t))
        }

        slice(e, t = this.content.size, r = !1) {
            if (e == t) return x.empty;
            let i = this.resolve(e), s = this.resolve(t), o = r ? 0 : i.sharedDepth(t), l = i.start(o),
                c = i.node(o).content.cut(i.pos - l, s.pos - l);
            return new x(c, i.depth - o, s.depth - o)
        }

        replace(e, t, r) {
            return $o(this.resolve(e), this.resolve(t), r)
        }

        nodeAt(e) {
            for (let t = this; ;) {
                let {index: r, offset: i} = t.content.findIndex(e);
                if (t = t.maybeChild(r), !t) return null;
                if (i == e || t.isText) return t;
                e -= i + 1
            }
        }

        childAfter(e) {
            let {index: t, offset: r} = this.content.findIndex(e);
            return {node: this.content.maybeChild(t), index: t, offset: r}
        }

        childBefore(e) {
            if (e == 0) return {node: null, index: 0, offset: 0};
            let {index: t, offset: r} = this.content.findIndex(e);
            if (r < e) return {node: this.content.child(t), index: t, offset: r};
            let i = this.content.child(t - 1);
            return {node: i, index: t - 1, offset: r - i.nodeSize}
        }

        resolve(e) {
            return gt.resolveCached(this, e)
        }

        resolveNoCache(e) {
            return gt.resolve(this, e)
        }

        rangeHasMark(e, t, r) {
            let i = !1;
            return t > e && this.nodesBetween(e, t, s => (r.isInSet(s.marks) && (i = !0), !i)), i
        }

        get isBlock() {
            return this.type.isBlock
        }

        get isTextblock() {
            return this.type.isTextblock
        }

        get inlineContent() {
            return this.type.inlineContent
        }

        get isInline() {
            return this.type.isInline
        }

        get isText() {
            return this.type.isText
        }

        get isLeaf() {
            return this.type.isLeaf
        }

        get isAtom() {
            return this.type.isAtom
        }

        toString() {
            if (this.type.spec.toDebugString) return this.type.spec.toDebugString(this);
            let e = this.type.name;
            return this.content.size && (e += "(" + this.content.toStringInner() + ")"), Vr(this.marks, e)
        }

        contentMatchAt(e) {
            let t = this.type.contentMatch.matchFragment(this.content, 0, e);
            if (!t) throw new Error("Called contentMatchAt on a node with invalid content");
            return t
        }

        canReplace(e, t, r = y.empty, i = 0, s = r.childCount) {
            let o = this.contentMatchAt(e).matchFragment(r, i, s), l = o && o.matchFragment(this.content, t);
            if (!l || !l.validEnd) return !1;
            for (let a = i; a < s; a++) if (!this.type.allowsMarks(r.child(a).marks)) return !1;
            return !0
        }

        canReplaceWith(e, t, r, i) {
            if (i && !this.type.allowsMarks(i)) return !1;
            let s = this.contentMatchAt(e).matchType(r), o = s && s.matchFragment(this.content, t);
            return o ? o.validEnd : !1
        }

        canAppend(e) {
            return e.content.size ? this.canReplace(this.childCount, this.childCount, e.content) : this.type.compatibleContent(e.type)
        }

        check() {
            this.type.checkContent(this.content), this.type.checkAttrs(this.attrs);
            let e = O.none;
            for (let t = 0; t < this.marks.length; t++) {
                let r = this.marks[t];
                r.type.checkAttrs(r.attrs), e = r.addToSet(e)
            }
            if (!O.sameSet(e, this.marks)) throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map(t => t.type.name)}`);
            this.content.forEach(t => t.check())
        }

        toJSON() {
            let e = {type: this.type.name};
            for (let t in this.attrs) {
                e.attrs = this.attrs;
                break
            }
            return this.content.size && (e.content = this.content.toJSON()), this.marks.length && (e.marks = this.marks.map(t => t.toJSON())), e
        }

        static fromJSON(e, t) {
            if (!t) throw new RangeError("Invalid input for Node.fromJSON");
            let r;
            if (t.marks) {
                if (!Array.isArray(t.marks)) throw new RangeError("Invalid mark data for Node.fromJSON");
                r = t.marks.map(e.markFromJSON)
            }
            if (t.type == "text") {
                if (typeof t.text != "string") throw new RangeError("Invalid text node in JSON");
                return e.text(t.text, r)
            }
            let i = y.fromJSON(e, t.content), s = e.nodeType(t.type).create(t.attrs, i, r);
            return s.type.checkAttrs(s.attrs), s
        }
    };
    Fe.prototype.text = void 0;

    class qt extends Fe {
        constructor(e, t, r, i) {
            if (super(e, t, null, i), !r) throw new RangeError("Empty text nodes are not allowed");
            this.text = r
        }

        toString() {
            return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : Vr(this.marks, JSON.stringify(this.text))
        }

        get textContent() {
            return this.text
        }

        textBetween(e, t) {
            return this.text.slice(e, t)
        }

        get nodeSize() {
            return this.text.length
        }

        mark(e) {
            return e == this.marks ? this : new qt(this.type, this.attrs, this.text, e)
        }

        withText(e) {
            return e == this.text ? this : new qt(this.type, this.attrs, e, this.marks)
        }

        cut(e = 0, t = this.text.length) {
            return e == 0 && t == this.text.length ? this : this.withText(this.text.slice(e, t))
        }

        eq(e) {
            return this.sameMarkup(e) && this.text == e.text
        }

        toJSON() {
            let e = super.toJSON();
            return e.text = this.text, e
        }
    }

    function Vr(n, e) {
        for (let t = n.length - 1; t >= 0; t--) e = n[t].type.name + "(" + e + ")";
        return e
    }

    class Le {
        constructor(e) {
            this.validEnd = e, this.next = [], this.wrapCache = []
        }

        static parse(e, t) {
            let r = new jo(e, t);
            if (r.next == null) return Le.empty;
            let i = Fr(r);
            r.next && r.err("Unexpected trailing text");
            let s = Qo(Zo(i));
            return el(s, r), s
        }

        matchType(e) {
            for (let t = 0; t < this.next.length; t++) if (this.next[t].type == e) return this.next[t].next;
            return null
        }

        matchFragment(e, t = 0, r = e.childCount) {
            let i = this;
            for (let s = t; i && s < r; s++) i = i.matchType(e.child(s).type);
            return i
        }

        get inlineContent() {
            return this.next.length != 0 && this.next[0].type.isInline
        }

        get defaultType() {
            for (let e = 0; e < this.next.length; e++) {
                let {type: t} = this.next[e];
                if (!(t.isText || t.hasRequiredAttrs())) return t
            }
            return null
        }

        compatible(e) {
            for (let t = 0; t < this.next.length; t++) for (let r = 0; r < e.next.length; r++) if (this.next[t].type == e.next[r].type) return !0;
            return !1
        }

        fillBefore(e, t = !1, r = 0) {
            let i = [this];

            function s(o, l) {
                let a = o.matchFragment(e, r);
                if (a && (!t || a.validEnd)) return y.from(l.map(c => c.createAndFill()));
                for (let c = 0; c < o.next.length; c++) {
                    let {type: f, next: h} = o.next[c];
                    if (!(f.isText || f.hasRequiredAttrs()) && i.indexOf(h) == -1) {
                        i.push(h);
                        let d = s(h, l.concat(f));
                        if (d) return d
                    }
                }
                return null
            }

            return s(this, [])
        }

        findWrapping(e) {
            for (let r = 0; r < this.wrapCache.length; r += 2) if (this.wrapCache[r] == e) return this.wrapCache[r + 1];
            let t = this.computeWrapping(e);
            return this.wrapCache.push(e, t), t
        }

        computeWrapping(e) {
            let t = Object.create(null), r = [{match: this, type: null, via: null}];
            for (; r.length;) {
                let i = r.shift(), s = i.match;
                if (s.matchType(e)) {
                    let o = [];
                    for (let l = i; l.type; l = l.via) o.push(l.type);
                    return o.reverse()
                }
                for (let o = 0; o < s.next.length; o++) {
                    let {type: l, next: a} = s.next[o];
                    !l.isLeaf && !l.hasRequiredAttrs() && !(l.name in t) && (!i.type || a.validEnd) && (r.push({
                        match: l.contentMatch,
                        type: l,
                        via: i
                    }), t[l.name] = !0)
                }
            }
            return null
        }

        get edgeCount() {
            return this.next.length
        }

        edge(e) {
            if (e >= this.next.length) throw new RangeError(`There's no ${e}th edge in this content match`);
            return this.next[e]
        }

        toString() {
            let e = [];

            function t(r) {
                e.push(r);
                for (let i = 0; i < r.next.length; i++) e.indexOf(r.next[i].next) == -1 && t(r.next[i].next)
            }

            return t(this), e.map((r, i) => {
                let s = i + (r.validEnd ? "*" : " ") + " ";
                for (let o = 0; o < r.next.length; o++) s += (o ? ", " : "") + r.next[o].type.name + "->" + e.indexOf(r.next[o].next);
                return s
            }).join(`
`)
        }
    }

    Le.empty = new Le(!0);

    class jo {
        constructor(e, t) {
            this.string = e, this.nodeTypes = t, this.inline = null, this.pos = 0, this.tokens = e.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift()
        }

        get next() {
            return this.tokens[this.pos]
        }

        eat(e) {
            return this.next == e && (this.pos++ || !0)
        }

        err(e) {
            throw new SyntaxError(e + " (in content expression '" + this.string + "')")
        }
    }

    function Fr(n) {
        let e = [];
        do e.push(Uo(n)); while (n.eat("|"));
        return e.length == 1 ? e[0] : {type: "choice", exprs: e}
    }

    function Uo(n) {
        let e = [];
        do e.push(Go(n)); while (n.next && n.next != ")" && n.next != "|");
        return e.length == 1 ? e[0] : {type: "seq", exprs: e}
    }

    function Go(n) {
        let e = Yo(n);
        for (; ;) if (n.eat("+")) e = {type: "plus", expr: e}; else if (n.eat("*")) e = {
            type: "star",
            expr: e
        }; else if (n.eat("?")) e = {type: "opt", expr: e}; else if (n.eat("{")) e = _o(n, e); else break;
        return e
    }

    function Lr(n) {
        /\D/.test(n.next) && n.err("Expected number, got '" + n.next + "'");
        let e = Number(n.next);
        return n.pos++, e
    }

    function _o(n, e) {
        let t = Lr(n), r = t;
        return n.eat(",") && (n.next != "}" ? r = Lr(n) : r = -1), n.eat("}") || n.err("Unclosed braced range"), {
            type: "range",
            min: t,
            max: r,
            expr: e
        }
    }

    function Xo(n, e) {
        let t = n.nodeTypes, r = t[e];
        if (r) return [r];
        let i = [];
        for (let s in t) {
            let o = t[s];
            o.isInGroup(e) && i.push(o)
        }
        return i.length == 0 && n.err("No node type or group '" + e + "' found"), i
    }

    function Yo(n) {
        if (n.eat("(")) {
            let e = Fr(n);
            return n.eat(")") || n.err("Missing closing paren"), e
        } else if (/\W/.test(n.next)) n.err("Unexpected token '" + n.next + "'"); else {
            let e = Xo(n, n.next).map(t => (n.inline == null ? n.inline = t.isInline : n.inline != t.isInline && n.err("Mixing inline and block content"), {
                type: "name",
                value: t
            }));
            return n.pos++, e.length == 1 ? e[0] : {type: "choice", exprs: e}
        }
    }

    function Zo(n) {
        let e = [[]];
        return i(s(n, 0), t()), e;

        function t() {
            return e.push([]) - 1
        }

        function r(o, l, a) {
            let c = {term: a, to: l};
            return e[o].push(c), c
        }

        function i(o, l) {
            o.forEach(a => a.to = l)
        }

        function s(o, l) {
            if (o.type == "choice") return o.exprs.reduce((a, c) => a.concat(s(c, l)), []);
            if (o.type == "seq") for (let a = 0; ; a++) {
                let c = s(o.exprs[a], l);
                if (a == o.exprs.length - 1) return c;
                i(c, l = t())
            } else if (o.type == "star") {
                let a = t();
                return r(l, a), i(s(o.expr, a), a), [r(a)]
            } else if (o.type == "plus") {
                let a = t();
                return i(s(o.expr, l), a), i(s(o.expr, a), a), [r(a)]
            } else {
                if (o.type == "opt") return [r(l)].concat(s(o.expr, l));
                if (o.type == "range") {
                    let a = l;
                    for (let c = 0; c < o.min; c++) {
                        let f = t();
                        i(s(o.expr, a), f), a = f
                    }
                    if (o.max == -1) i(s(o.expr, a), a); else for (let c = o.min; c < o.max; c++) {
                        let f = t();
                        r(a, f), i(s(o.expr, a), f), a = f
                    }
                    return [r(a)]
                } else {
                    if (o.type == "name") return [r(l, void 0, o.value)];
                    throw new Error("Unknown expr type")
                }
            }
        }
    }

    function Hr(n, e) {
        return e - n
    }

    function $r(n, e) {
        let t = [];
        return r(e), t.sort(Hr);

        function r(i) {
            let s = n[i];
            if (s.length == 1 && !s[0].term) return r(s[0].to);
            t.push(i);
            for (let o = 0; o < s.length; o++) {
                let {term: l, to: a} = s[o];
                !l && t.indexOf(a) == -1 && r(a)
            }
        }
    }

    function Qo(n) {
        let e = Object.create(null);
        return t($r(n, 0));

        function t(r) {
            let i = [];
            r.forEach(o => {
                n[o].forEach(({term: l, to: a}) => {
                    if (!l) return;
                    let c;
                    for (let f = 0; f < i.length; f++) i[f][0] == l && (c = i[f][1]);
                    $r(n, a).forEach(f => {
                        c || i.push([l, c = []]), c.indexOf(f) == -1 && c.push(f)
                    })
                })
            });
            let s = e[r.join(",")] = new Le(r.indexOf(n.length - 1) > -1);
            for (let o = 0; o < i.length; o++) {
                let l = i[o][1].sort(Hr);
                s.next.push({type: i[o][0], next: e[l.join(",")] || t(l)})
            }
            return s
        }
    }

    function el(n, e) {
        for (let t = 0, r = [n]; t < r.length; t++) {
            let i = r[t], s = !i.validEnd, o = [];
            for (let l = 0; l < i.next.length; l++) {
                let {type: a, next: c} = i.next[l];
                o.push(a.name), s && !(a.isText || a.hasRequiredAttrs()) && (s = !1), r.indexOf(c) == -1 && r.push(c)
            }
            s && e.err("Only non-generatable nodes (" + o.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)")
        }
    }

    function Wr(n) {
        let e = Object.create(null);
        for (let t in n) {
            let r = n[t];
            if (!r.hasDefault) return null;
            e[t] = r.default
        }
        return e
    }

    function Jr(n, e) {
        let t = Object.create(null);
        for (let r in n) {
            let i = e && e[r];
            if (i === void 0) {
                let s = n[r];
                if (s.hasDefault) i = s.default; else throw new RangeError("No value supplied for attribute " + r)
            }
            t[r] = i
        }
        return t
    }

    function qr(n, e, t, r) {
        for (let i in e) if (!(i in n)) throw new RangeError(`Unsupported attribute ${i} for ${t} of type ${i}`);
        for (let i in n) {
            let s = n[i];
            s.validate && s.validate(e[i])
        }
    }

    function Kr(n, e) {
        let t = Object.create(null);
        if (e) for (let r in e) t[r] = new nl(n, r, e[r]);
        return t
    }

    let jr = class Lo {
        constructor(e, t, r) {
            this.name = e, this.schema = t, this.spec = r, this.markSet = null, this.groups = r.group ? r.group.split(" ") : [], this.attrs = Kr(e, r.attrs), this.defaultAttrs = Wr(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(r.inline || e == "text"), this.isText = e == "text"
        }

        get isInline() {
            return !this.isBlock
        }

        get isTextblock() {
            return this.isBlock && this.inlineContent
        }

        get isLeaf() {
            return this.contentMatch == Le.empty
        }

        get isAtom() {
            return this.isLeaf || !!this.spec.atom
        }

        isInGroup(e) {
            return this.groups.indexOf(e) > -1
        }

        get whitespace() {
            return this.spec.whitespace || (this.spec.code ? "pre" : "normal")
        }

        hasRequiredAttrs() {
            for (let e in this.attrs) if (this.attrs[e].isRequired) return !0;
            return !1
        }

        compatibleContent(e) {
            return this == e || this.contentMatch.compatible(e.contentMatch)
        }

        computeAttrs(e) {
            return !e && this.defaultAttrs ? this.defaultAttrs : Jr(this.attrs, e)
        }

        create(e = null, t, r) {
            if (this.isText) throw new Error("NodeType.create can't construct text nodes");
            return new Fe(this, this.computeAttrs(e), y.from(t), O.setFrom(r))
        }

        createChecked(e = null, t, r) {
            return t = y.from(t), this.checkContent(t), new Fe(this, this.computeAttrs(e), t, O.setFrom(r))
        }

        createAndFill(e = null, t, r) {
            if (e = this.computeAttrs(e), t = y.from(t), t.size) {
                let o = this.contentMatch.fillBefore(t);
                if (!o) return null;
                t = o.append(t)
            }
            let i = this.contentMatch.matchFragment(t), s = i && i.fillBefore(y.empty, !0);
            return s ? new Fe(this, e, t.append(s), O.setFrom(r)) : null
        }

        validContent(e) {
            let t = this.contentMatch.matchFragment(e);
            if (!t || !t.validEnd) return !1;
            for (let r = 0; r < e.childCount; r++) if (!this.allowsMarks(e.child(r).marks)) return !1;
            return !0
        }

        checkContent(e) {
            if (!this.validContent(e)) throw new RangeError(`Invalid content for node ${this.name}: ${e.toString().slice(0, 50)}`)
        }

        checkAttrs(e) {
            qr(this.attrs, e, "node", this.name)
        }

        allowsMarkType(e) {
            return this.markSet == null || this.markSet.indexOf(e) > -1
        }

        allowsMarks(e) {
            if (this.markSet == null) return !0;
            for (let t = 0; t < e.length; t++) if (!this.allowsMarkType(e[t].type)) return !1;
            return !0
        }

        allowedMarks(e) {
            if (this.markSet == null) return e;
            let t;
            for (let r = 0; r < e.length; r++) this.allowsMarkType(e[r].type) ? t && t.push(e[r]) : t || (t = e.slice(0, r));
            return t ? t.length ? t : O.none : e
        }

        static compile(e, t) {
            let r = Object.create(null);
            e.forEach((s, o) => r[s] = new Lo(s, t, o));
            let i = t.spec.topNode || "doc";
            if (!r[i]) throw new RangeError("Schema is missing its top node type ('" + i + "')");
            if (!r.text) throw new RangeError("Every schema needs a 'text' type");
            for (let s in r.text.attrs) throw new RangeError("The text node type should not have attributes");
            return r
        }
    };

    function tl(n, e, t) {
        let r = t.split("|");
        return i => {
            let s = i === null ? "null" : typeof i;
            if (r.indexOf(s) < 0) throw new RangeError(`Expected value of type ${r} for attribute ${e} on type ${n}, got ${s}`)
        }
    }

    class nl {
        constructor(e, t, r) {
            this.hasDefault = Object.prototype.hasOwnProperty.call(r, "default"), this.default = r.default, this.validate = typeof r.validate == "string" ? tl(e, t, r.validate) : r.validate
        }

        get isRequired() {
            return !this.hasDefault
        }
    }

    class Kt {
        constructor(e, t, r, i) {
            this.name = e, this.rank = t, this.schema = r, this.spec = i, this.attrs = Kr(e, i.attrs), this.excluded = null;
            let s = Wr(this.attrs);
            this.instance = s ? new O(this, s) : null
        }

        create(e = null) {
            return !e && this.instance ? this.instance : new O(this, Jr(this.attrs, e))
        }

        static compile(e, t) {
            let r = Object.create(null), i = 0;
            return e.forEach((s, o) => r[s] = new Kt(s, i++, t, o)), r
        }

        removeFromSet(e) {
            for (var t = 0; t < e.length; t++) e[t].type == this && (e = e.slice(0, t).concat(e.slice(t + 1)), t--);
            return e
        }

        isInSet(e) {
            for (let t = 0; t < e.length; t++) if (e[t].type == this) return e[t]
        }

        checkAttrs(e) {
            qr(this.attrs, e, "mark", this.name)
        }

        excludes(e) {
            return this.excluded.indexOf(e) > -1
        }
    }

    class rl {
        constructor(e) {
            this.linebreakReplacement = null, this.cached = Object.create(null);
            let t = this.spec = {};
            for (let i in e) t[i] = e[i];
            t.nodes = T.from(e.nodes), t.marks = T.from(e.marks || {}), this.nodes = jr.compile(this.spec.nodes, this), this.marks = Kt.compile(this.spec.marks, this);
            let r = Object.create(null);
            for (let i in this.nodes) {
                if (i in this.marks) throw new RangeError(i + " can not be both a node and a mark");
                let s = this.nodes[i], o = s.spec.content || "", l = s.spec.marks;
                if (s.contentMatch = r[o] || (r[o] = Le.parse(o, this.nodes)), s.inlineContent = s.contentMatch.inlineContent, s.spec.linebreakReplacement) {
                    if (this.linebreakReplacement) throw new RangeError("Multiple linebreak nodes defined");
                    if (!s.isInline || !s.isLeaf) throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
                    this.linebreakReplacement = s
                }
                s.markSet = l == "_" ? null : l ? Ur(this, l.split(" ")) : l == "" || !s.inlineContent ? [] : null
            }
            for (let i in this.marks) {
                let s = this.marks[i], o = s.spec.excludes;
                s.excluded = o == null ? [s] : o == "" ? [] : Ur(this, o.split(" "))
            }
            this.nodeFromJSON = this.nodeFromJSON.bind(this), this.markFromJSON = this.markFromJSON.bind(this), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = Object.create(null)
        }

        node(e, t = null, r, i) {
            if (typeof e == "string") e = this.nodeType(e); else if (e instanceof jr) {
                if (e.schema != this) throw new RangeError("Node type from different schema used (" + e.name + ")")
            } else throw new RangeError("Invalid node type: " + e);
            return e.createChecked(t, r, i)
        }

        text(e, t) {
            let r = this.nodes.text;
            return new qt(r, r.defaultAttrs, e, O.setFrom(t))
        }

        mark(e, t) {
            return typeof e == "string" && (e = this.marks[e]), e.create(t)
        }

        nodeFromJSON(e) {
            return Fe.fromJSON(this, e)
        }

        markFromJSON(e) {
            return O.fromJSON(this, e)
        }

        nodeType(e) {
            let t = this.nodes[e];
            if (!t) throw new RangeError("Unknown node type: " + e);
            return t
        }
    }

    function Ur(n, e) {
        let t = [];
        for (let r = 0; r < e.length; r++) {
            let i = e[r], s = n.marks[i], o = s;
            if (s) t.push(s); else for (let l in n.marks) {
                let a = n.marks[l];
                (i == "_" || a.spec.group && a.spec.group.split(" ").indexOf(i) > -1) && t.push(o = a)
            }
            if (!o) throw new SyntaxError("Unknown mark type: '" + e[r] + "'")
        }
        return t
    }

    function il(n) {
        return n.tag != null
    }

    function sl(n) {
        return n.style != null
    }

    class Ze {
        constructor(e, t) {
            this.schema = e, this.rules = t, this.tags = [], this.styles = [];
            let r = this.matchedStyles = [];
            t.forEach(i => {
                if (il(i)) this.tags.push(i); else if (sl(i)) {
                    let s = /[^=]*/.exec(i.style)[0];
                    r.indexOf(s) < 0 && r.push(s), this.styles.push(i)
                }
            }), this.normalizeLists = !this.tags.some(i => {
                if (!/^(ul|ol)\b/.test(i.tag) || !i.node) return !1;
                let s = e.nodes[i.node];
                return s.contentMatch.matchType(s)
            })
        }

        parse(e, t = {}) {
            let r = new Yr(this, t, !1);
            return r.addAll(e, O.none, t.from, t.to), r.finish()
        }

        parseSlice(e, t = {}) {
            let r = new Yr(this, t, !0);
            return r.addAll(e, O.none, t.from, t.to), x.maxOpen(r.finish())
        }

        matchTag(e, t, r) {
            for (let i = r ? this.tags.indexOf(r) + 1 : 0; i < this.tags.length; i++) {
                let s = this.tags[i];
                if (al(e, s.tag) && (s.namespace === void 0 || e.namespaceURI == s.namespace) && (!s.context || t.matchesContext(s.context))) {
                    if (s.getAttrs) {
                        let o = s.getAttrs(e);
                        if (o === !1) continue;
                        s.attrs = o || void 0
                    }
                    return s
                }
            }
        }

        matchStyle(e, t, r, i) {
            for (let s = i ? this.styles.indexOf(i) + 1 : 0; s < this.styles.length; s++) {
                let o = this.styles[s], l = o.style;
                if (!(l.indexOf(e) != 0 || o.context && !r.matchesContext(o.context) || l.length > e.length && (l.charCodeAt(e.length) != 61 || l.slice(e.length + 1) != t))) {
                    if (o.getAttrs) {
                        let a = o.getAttrs(t);
                        if (a === !1) continue;
                        o.attrs = a || void 0
                    }
                    return o
                }
            }
        }

        static schemaRules(e) {
            let t = [];

            function r(i) {
                let s = i.priority == null ? 50 : i.priority, o = 0;
                for (; o < t.length; o++) {
                    let l = t[o];
                    if ((l.priority == null ? 50 : l.priority) < s) break
                }
                t.splice(o, 0, i)
            }

            for (let i in e.marks) {
                let s = e.marks[i].spec.parseDOM;
                s && s.forEach(o => {
                    r(o = Zr(o)), o.mark || o.ignore || o.clearMark || (o.mark = i)
                })
            }
            for (let i in e.nodes) {
                let s = e.nodes[i].spec.parseDOM;
                s && s.forEach(o => {
                    r(o = Zr(o)), o.node || o.ignore || o.mark || (o.node = i)
                })
            }
            return t
        }

        static fromSchema(e) {
            return e.cached.domParser || (e.cached.domParser = new Ze(e, Ze.schemaRules(e)))
        }
    }

    const Gr = {
            address: !0,
            article: !0,
            aside: !0,
            blockquote: !0,
            canvas: !0,
            dd: !0,
            div: !0,
            dl: !0,
            fieldset: !0,
            figcaption: !0,
            figure: !0,
            footer: !0,
            form: !0,
            h1: !0,
            h2: !0,
            h3: !0,
            h4: !0,
            h5: !0,
            h6: !0,
            header: !0,
            hgroup: !0,
            hr: !0,
            li: !0,
            noscript: !0,
            ol: !0,
            output: !0,
            p: !0,
            pre: !0,
            section: !0,
            table: !0,
            tfoot: !0,
            ul: !0
        }, ol = {head: !0, noscript: !0, object: !0, script: !0, style: !0, title: !0}, _r = {ol: !0, ul: !0}, jt = 1,
        Ut = 2, yt = 4;

    function Xr(n, e, t) {
        return e != null ? (e ? jt : 0) | (e === "full" ? Ut : 0) : n && n.whitespace == "pre" ? jt | Ut : t & ~yt
    }

    class Gt {
        constructor(e, t, r, i, s, o) {
            this.type = e, this.attrs = t, this.marks = r, this.solid = i, this.options = o, this.content = [], this.activeMarks = O.none, this.match = s || (o & yt ? null : e.contentMatch)
        }

        findWrapping(e) {
            if (!this.match) {
                if (!this.type) return [];
                let t = this.type.contentMatch.fillBefore(y.from(e));
                if (t) this.match = this.type.contentMatch.matchFragment(t); else {
                    let r = this.type.contentMatch, i;
                    return (i = r.findWrapping(e.type)) ? (this.match = r, i) : null
                }
            }
            return this.match.findWrapping(e.type)
        }

        finish(e) {
            if (!(this.options & jt)) {
                let r = this.content[this.content.length - 1], i;
                if (r && r.isText && (i = /[ \t\r\n\u000c]+$/.exec(r.text))) {
                    let s = r;
                    r.text.length == i[0].length ? this.content.pop() : this.content[this.content.length - 1] = s.withText(s.text.slice(0, s.text.length - i[0].length))
                }
            }
            let t = y.from(this.content);
            return !e && this.match && (t = t.append(this.match.fillBefore(y.empty, !0))), this.type ? this.type.create(this.attrs, t, this.marks) : t
        }

        inlineContext(e) {
            return this.type ? this.type.inlineContent : this.content.length ? this.content[0].isInline : e.parentNode && !Gr.hasOwnProperty(e.parentNode.nodeName.toLowerCase())
        }
    }

    class Yr {
        constructor(e, t, r) {
            this.parser = e, this.options = t, this.isOpen = r, this.open = 0;
            let i = t.topNode, s, o = Xr(null, t.preserveWhitespace, 0) | (r ? yt : 0);
            i ? s = new Gt(i.type, i.attrs, O.none, !0, t.topMatch || i.type.contentMatch, o) : r ? s = new Gt(null, null, O.none, !0, null, o) : s = new Gt(e.schema.topNodeType, null, O.none, !0, null, o), this.nodes = [s], this.find = t.findPositions, this.needsBlock = !1
        }

        get top() {
            return this.nodes[this.open]
        }

        addDOM(e, t) {
            e.nodeType == 3 ? this.addTextNode(e, t) : e.nodeType == 1 && this.addElement(e, t)
        }

        addTextNode(e, t) {
            let r = e.nodeValue, i = this.top;
            if (i.options & Ut || i.inlineContext(e) || /[^ \t\r\n\u000c]/.test(r)) {
                if (i.options & jt) i.options & Ut ? r = r.replace(/\r\n?/g, `
`) : r = r.replace(/\r?\n|\r/g, " "); else if (r = r.replace(/[ \t\r\n\u000c]+/g, " "), /^[ \t\r\n\u000c]/.test(r) && this.open == this.nodes.length - 1) {
                    let s = i.content[i.content.length - 1], o = e.previousSibling;
                    (!s || o && o.nodeName == "BR" || s.isText && /[ \t\r\n\u000c]$/.test(s.text)) && (r = r.slice(1))
                }
                r && this.insertNode(this.parser.schema.text(r), t), this.findInText(e)
            } else this.findInside(e)
        }

        addElement(e, t, r) {
            let i = e.nodeName.toLowerCase(), s;
            _r.hasOwnProperty(i) && this.parser.normalizeLists && ll(e);
            let o = this.options.ruleFromNode && this.options.ruleFromNode(e) || (s = this.parser.matchTag(e, this, r));
            if (o ? o.ignore : ol.hasOwnProperty(i)) this.findInside(e), this.ignoreFallback(e, t); else if (!o || o.skip || o.closeParent) {
                o && o.closeParent ? this.open = Math.max(0, this.open - 1) : o && o.skip.nodeType && (e = o.skip);
                let l, a = this.top, c = this.needsBlock;
                if (Gr.hasOwnProperty(i)) a.content.length && a.content[0].isInline && this.open && (this.open--, a = this.top), l = !0, a.type || (this.needsBlock = !0); else if (!e.firstChild) {
                    this.leafFallback(e, t);
                    return
                }
                let f = o && o.skip ? t : this.readStyles(e, t);
                f && this.addAll(e, f), l && this.sync(a), this.needsBlock = c
            } else {
                let l = this.readStyles(e, t);
                l && this.addElementByRule(e, o, l, o.consuming === !1 ? s : void 0)
            }
        }

        leafFallback(e, t) {
            e.nodeName == "BR" && this.top.type && this.top.type.inlineContent && this.addTextNode(e.ownerDocument.createTextNode(`
`), t)
        }

        ignoreFallback(e, t) {
            e.nodeName == "BR" && (!this.top.type || !this.top.type.inlineContent) && this.findPlace(this.parser.schema.text("-"), t)
        }

        readStyles(e, t) {
            let r = e.style;
            if (r && r.length) for (let i = 0; i < this.parser.matchedStyles.length; i++) {
                let s = this.parser.matchedStyles[i], o = r.getPropertyValue(s);
                if (o) for (let l = void 0; ;) {
                    let a = this.parser.matchStyle(s, o, this, l);
                    if (!a) break;
                    if (a.ignore) return null;
                    if (a.clearMark ? t = t.filter(c => !a.clearMark(c)) : t = t.concat(this.parser.schema.marks[a.mark].create(a.attrs)), a.consuming === !1) l = a; else break
                }
            }
            return t
        }

        addElementByRule(e, t, r, i) {
            let s, o;
            if (t.node) if (o = this.parser.schema.nodes[t.node], o.isLeaf) this.insertNode(o.create(t.attrs), r) || this.leafFallback(e, r); else {
                let a = this.enter(o, t.attrs || null, r, t.preserveWhitespace);
                a && (s = !0, r = a)
            } else {
                let a = this.parser.schema.marks[t.mark];
                r = r.concat(a.create(t.attrs))
            }
            let l = this.top;
            if (o && o.isLeaf) this.findInside(e); else if (i) this.addElement(e, r, i); else if (t.getContent) this.findInside(e), t.getContent(e, this.parser.schema).forEach(a => this.insertNode(a, r)); else {
                let a = e;
                typeof t.contentElement == "string" ? a = e.querySelector(t.contentElement) : typeof t.contentElement == "function" ? a = t.contentElement(e) : t.contentElement && (a = t.contentElement), this.findAround(e, a, !0), this.addAll(a, r), this.findAround(e, a, !1)
            }
            s && this.sync(l) && this.open--
        }

        addAll(e, t, r, i) {
            let s = r || 0;
            for (let o = r ? e.childNodes[r] : e.firstChild, l = i == null ? null : e.childNodes[i]; o != l; o = o.nextSibling, ++s) this.findAtPoint(e, s), this.addDOM(o, t);
            this.findAtPoint(e, s)
        }

        findPlace(e, t) {
            let r, i;
            for (let s = this.open; s >= 0; s--) {
                let o = this.nodes[s], l = o.findWrapping(e);
                if (l && (!r || r.length > l.length) && (r = l, i = o, !l.length) || o.solid) break
            }
            if (!r) return null;
            this.sync(i);
            for (let s = 0; s < r.length; s++) t = this.enterInner(r[s], null, t, !1);
            return t
        }

        insertNode(e, t) {
            if (e.isInline && this.needsBlock && !this.top.type) {
                let i = this.textblockFromContext();
                i && (t = this.enterInner(i, null, t))
            }
            let r = this.findPlace(e, t);
            if (r) {
                this.closeExtra();
                let i = this.top;
                i.match && (i.match = i.match.matchType(e.type));
                let s = O.none;
                for (let o of r.concat(e.marks)) (i.type ? i.type.allowsMarkType(o.type) : Qr(o.type, e.type)) && (s = o.addToSet(s));
                return i.content.push(e.mark(s)), !0
            }
            return !1
        }

        enter(e, t, r, i) {
            let s = this.findPlace(e.create(t), r);
            return s && (s = this.enterInner(e, t, r, !0, i)), s
        }

        enterInner(e, t, r, i = !1, s) {
            this.closeExtra();
            let o = this.top;
            o.match = o.match && o.match.matchType(e);
            let l = Xr(e, s, o.options);
            o.options & yt && o.content.length == 0 && (l |= yt);
            let a = O.none;
            return r = r.filter(c => (o.type ? o.type.allowsMarkType(c.type) : Qr(c.type, e)) ? (a = c.addToSet(a), !1) : !0), this.nodes.push(new Gt(e, t, a, i, null, l)), this.open++, r
        }

        closeExtra(e = !1) {
            let t = this.nodes.length - 1;
            if (t > this.open) {
                for (; t > this.open; t--) this.nodes[t - 1].content.push(this.nodes[t].finish(e));
                this.nodes.length = this.open + 1
            }
        }

        finish() {
            return this.open = 0, this.closeExtra(this.isOpen), this.nodes[0].finish(this.isOpen || this.options.topOpen)
        }

        sync(e) {
            for (let t = this.open; t >= 0; t--) if (this.nodes[t] == e) return this.open = t, !0;
            return !1
        }

        get currentPos() {
            this.closeExtra();
            let e = 0;
            for (let t = this.open; t >= 0; t--) {
                let r = this.nodes[t].content;
                for (let i = r.length - 1; i >= 0; i--) e += r[i].nodeSize;
                t && e++
            }
            return e
        }

        findAtPoint(e, t) {
            if (this.find) for (let r = 0; r < this.find.length; r++) this.find[r].node == e && this.find[r].offset == t && (this.find[r].pos = this.currentPos)
        }

        findInside(e) {
            if (this.find) for (let t = 0; t < this.find.length; t++) this.find[t].pos == null && e.nodeType == 1 && e.contains(this.find[t].node) && (this.find[t].pos = this.currentPos)
        }

        findAround(e, t, r) {
            if (e != t && this.find) for (let i = 0; i < this.find.length; i++) this.find[i].pos == null && e.nodeType == 1 && e.contains(this.find[i].node) && t.compareDocumentPosition(this.find[i].node) & (r ? 2 : 4) && (this.find[i].pos = this.currentPos)
        }

        findInText(e) {
            if (this.find) for (let t = 0; t < this.find.length; t++) this.find[t].node == e && (this.find[t].pos = this.currentPos - (e.nodeValue.length - this.find[t].offset))
        }

        matchesContext(e) {
            if (e.indexOf("|") > -1) return e.split(/\s*\|\s*/).some(this.matchesContext, this);
            let t = e.split("/"), r = this.options.context,
                i = !this.isOpen && (!r || r.parent.type == this.nodes[0].type),
                s = -(r ? r.depth + 1 : 0) + (i ? 0 : 1), o = (l, a) => {
                    for (; l >= 0; l--) {
                        let c = t[l];
                        if (c == "") {
                            if (l == t.length - 1 || l == 0) continue;
                            for (; a >= s; a--) if (o(l - 1, a)) return !0;
                            return !1
                        } else {
                            let f = a > 0 || a == 0 && i ? this.nodes[a].type : r && a >= s ? r.node(a - s).type : null;
                            if (!f || f.name != c && !f.isInGroup(c)) return !1;
                            a--
                        }
                    }
                    return !0
                };
            return o(t.length - 1, this.open)
        }

        textblockFromContext() {
            let e = this.options.context;
            if (e) for (let t = e.depth; t >= 0; t--) {
                let r = e.node(t).contentMatchAt(e.indexAfter(t)).defaultType;
                if (r && r.isTextblock && r.defaultAttrs) return r
            }
            for (let t in this.parser.schema.nodes) {
                let r = this.parser.schema.nodes[t];
                if (r.isTextblock && r.defaultAttrs) return r
            }
        }
    }

    function ll(n) {
        for (let e = n.firstChild, t = null; e; e = e.nextSibling) {
            let r = e.nodeType == 1 ? e.nodeName.toLowerCase() : null;
            r && _r.hasOwnProperty(r) && t ? (t.appendChild(e), e = t) : r == "li" ? t = e : r && (t = null)
        }
    }

    function al(n, e) {
        return (n.matches || n.msMatchesSelector || n.webkitMatchesSelector || n.mozMatchesSelector).call(n, e)
    }

    function Zr(n) {
        let e = {};
        for (let t in n) e[t] = n[t];
        return e
    }

    function Qr(n, e) {
        let t = e.schema.nodes;
        for (let r in t) {
            let i = t[r];
            if (!i.allowsMarkType(n)) continue;
            let s = [], o = l => {
                s.push(l);
                for (let a = 0; a < l.edgeCount; a++) {
                    let {type: c, next: f} = l.edge(a);
                    if (c == e || s.indexOf(f) < 0 && o(f)) return !0
                }
            };
            if (o(i.contentMatch)) return !0
        }
    }

    class He {
        constructor(e, t) {
            this.nodes = e, this.marks = t
        }

        serializeFragment(e, t = {}, r) {
            r || (r = On(t).createDocumentFragment());
            let i = r, s = [];
            return e.forEach(o => {
                if (s.length || o.marks.length) {
                    let l = 0, a = 0;
                    for (; l < s.length && a < o.marks.length;) {
                        let c = o.marks[a];
                        if (!this.marks[c.type.name]) {
                            a++;
                            continue
                        }
                        if (!c.eq(s[l][0]) || c.type.spec.spanning === !1) break;
                        l++, a++
                    }
                    for (; l < s.length;) i = s.pop()[1];
                    for (; a < o.marks.length;) {
                        let c = o.marks[a++], f = this.serializeMark(c, o.isInline, t);
                        f && (s.push([c, i]), i.appendChild(f.dom), i = f.contentDOM || f.dom)
                    }
                }
                i.appendChild(this.serializeNodeInner(o, t))
            }), r
        }

        serializeNodeInner(e, t) {
            let {dom: r, contentDOM: i} = _t(On(t), this.nodes[e.type.name](e), null, e.attrs);
            if (i) {
                if (e.isLeaf) throw new RangeError("Content hole not allowed in a leaf node spec");
                this.serializeFragment(e.content, t, i)
            }
            return r
        }

        serializeNode(e, t = {}) {
            let r = this.serializeNodeInner(e, t);
            for (let i = e.marks.length - 1; i >= 0; i--) {
                let s = this.serializeMark(e.marks[i], e.isInline, t);
                s && ((s.contentDOM || s.dom).appendChild(r), r = s.dom)
            }
            return r
        }

        serializeMark(e, t, r = {}) {
            let i = this.marks[e.type.name];
            return i && _t(On(r), i(e, t), null, e.attrs)
        }

        static renderSpec(e, t, r = null, i) {
            return _t(e, t, r, i)
        }

        static fromSchema(e) {
            return e.cached.domSerializer || (e.cached.domSerializer = new He(this.nodesFromSchema(e), this.marksFromSchema(e)))
        }

        static nodesFromSchema(e) {
            let t = ei(e.nodes);
            return t.text || (t.text = r => r.text), t
        }

        static marksFromSchema(e) {
            return ei(e.marks)
        }
    }

    function ei(n) {
        let e = {};
        for (let t in n) {
            let r = n[t].spec.toDOM;
            r && (e[t] = r)
        }
        return e
    }

    function On(n) {
        return n.document || window.document
    }

    const ti = new WeakMap;

    function cl(n) {
        let e = ti.get(n);
        return e === void 0 && ti.set(n, e = fl(n)), e
    }

    function fl(n) {
        let e = null;

        function t(r) {
            if (r && typeof r == "object") if (Array.isArray(r)) if (typeof r[0] == "string") e || (e = []), e.push(r); else for (let i = 0; i < r.length; i++) t(r[i]); else for (let i in r) t(r[i])
        }

        return t(n), e
    }

    function _t(n, e, t, r) {
        if (typeof e == "string") return {dom: n.createTextNode(e)};
        if (e.nodeType != null) return {dom: e};
        if (e.dom && e.dom.nodeType != null) return e;
        let i = e[0], s;
        if (typeof i != "string") throw new RangeError("Invalid array passed to renderSpec");
        if (r && (s = cl(r)) && s.indexOf(e) > -1) throw new RangeError("Using an array from an attribute object as a DOM spec. This may be an attempted cross site scripting attack.");
        let o = i.indexOf(" ");
        o > 0 && (t = i.slice(0, o), i = i.slice(o + 1));
        let l, a = t ? n.createElementNS(t, i) : n.createElement(i), c = e[1], f = 1;
        if (c && typeof c == "object" && c.nodeType == null && !Array.isArray(c)) {
            f = 2;
            for (let h in c) if (c[h] != null) {
                let d = h.indexOf(" ");
                d > 0 ? a.setAttributeNS(h.slice(0, d), h.slice(d + 1), c[h]) : a.setAttribute(h, c[h])
            }
        }
        for (let h = f; h < e.length; h++) {
            let d = e[h];
            if (d === 0) {
                if (h < e.length - 1 || h > f) throw new RangeError("Content hole must be the only child of its parent node");
                return {dom: a, contentDOM: a}
            } else {
                let {dom: u, contentDOM: p} = _t(n, d, t, r);
                if (a.appendChild(u), p) {
                    if (l) throw new RangeError("Multiple content holes");
                    l = p
                }
            }
        }
        return {dom: a, contentDOM: l}
    }

    const ni = 65535, ri = Math.pow(2, 16);

    function hl(n, e) {
        return n + e * ri
    }

    function ii(n) {
        return n & ni
    }

    function dl(n) {
        return (n - (n & ni)) / ri
    }

    const si = 1, oi = 2, Xt = 4, li = 8;

    class Nn {
        constructor(e, t, r) {
            this.pos = e, this.delInfo = t, this.recover = r
        }

        get deleted() {
            return (this.delInfo & li) > 0
        }

        get deletedBefore() {
            return (this.delInfo & (si | Xt)) > 0
        }

        get deletedAfter() {
            return (this.delInfo & (oi | Xt)) > 0
        }

        get deletedAcross() {
            return (this.delInfo & Xt) > 0
        }
    }

    class G {
        constructor(e, t = !1) {
            if (this.ranges = e, this.inverted = t, !e.length && G.empty) return G.empty
        }

        recover(e) {
            let t = 0, r = ii(e);
            if (!this.inverted) for (let i = 0; i < r; i++) t += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
            return this.ranges[r * 3] + t + dl(e)
        }

        mapResult(e, t = 1) {
            return this._map(e, t, !1)
        }

        map(e, t = 1) {
            return this._map(e, t, !0)
        }

        _map(e, t, r) {
            let i = 0, s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
            for (let l = 0; l < this.ranges.length; l += 3) {
                let a = this.ranges[l] - (this.inverted ? i : 0);
                if (a > e) break;
                let c = this.ranges[l + s], f = this.ranges[l + o], h = a + c;
                if (e <= h) {
                    let d = c ? e == a ? -1 : e == h ? 1 : t : t, u = a + i + (d < 0 ? 0 : f);
                    if (r) return u;
                    let p = e == (t < 0 ? a : h) ? null : hl(l / 3, e - a), m = e == a ? oi : e == h ? si : Xt;
                    return (t < 0 ? e != a : e != h) && (m |= li), new Nn(u, m, p)
                }
                i += f - c
            }
            return r ? e + i : new Nn(e + i, 0, null)
        }

        touches(e, t) {
            let r = 0, i = ii(t), s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
            for (let l = 0; l < this.ranges.length; l += 3) {
                let a = this.ranges[l] - (this.inverted ? r : 0);
                if (a > e) break;
                let c = this.ranges[l + s], f = a + c;
                if (e <= f && l == i * 3) return !0;
                r += this.ranges[l + o] - c
            }
            return !1
        }

        forEach(e) {
            let t = this.inverted ? 2 : 1, r = this.inverted ? 1 : 2;
            for (let i = 0, s = 0; i < this.ranges.length; i += 3) {
                let o = this.ranges[i], l = o - (this.inverted ? s : 0), a = o + (this.inverted ? 0 : s),
                    c = this.ranges[i + t], f = this.ranges[i + r];
                e(l, l + c, a, a + f), s += f - c
            }
        }

        invert() {
            return new G(this.ranges, !this.inverted)
        }

        toString() {
            return (this.inverted ? "-" : "") + JSON.stringify(this.ranges)
        }

        static offset(e) {
            return e == 0 ? G.empty : new G(e < 0 ? [0, -e, 0] : [0, 0, e])
        }
    }

    G.empty = new G([]);

    class Qe {
        constructor(e = [], t, r = 0, i = e.length) {
            this.maps = e, this.mirror = t, this.from = r, this.to = i
        }

        slice(e = 0, t = this.maps.length) {
            return new Qe(this.maps, this.mirror, e, t)
        }

        copy() {
            return new Qe(this.maps.slice(), this.mirror && this.mirror.slice(), this.from, this.to)
        }

        appendMap(e, t) {
            this.to = this.maps.push(e), t != null && this.setMirror(this.maps.length - 1, t)
        }

        appendMapping(e) {
            for (let t = 0, r = this.maps.length; t < e.maps.length; t++) {
                let i = e.getMirror(t);
                this.appendMap(e.maps[t], i != null && i < t ? r + i : void 0)
            }
        }

        getMirror(e) {
            if (this.mirror) {
                for (let t = 0; t < this.mirror.length; t++) if (this.mirror[t] == e) return this.mirror[t + (t % 2 ? -1 : 1)]
            }
        }

        setMirror(e, t) {
            this.mirror || (this.mirror = []), this.mirror.push(e, t)
        }

        appendMappingInverted(e) {
            for (let t = e.maps.length - 1, r = this.maps.length + e.maps.length; t >= 0; t--) {
                let i = e.getMirror(t);
                this.appendMap(e.maps[t].invert(), i != null && i > t ? r - i - 1 : void 0)
            }
        }

        invert() {
            let e = new Qe;
            return e.appendMappingInverted(this), e
        }

        map(e, t = 1) {
            if (this.mirror) return this._map(e, t, !0);
            for (let r = this.from; r < this.to; r++) e = this.maps[r].map(e, t);
            return e
        }

        mapResult(e, t = 1) {
            return this._map(e, t, !1)
        }

        _map(e, t, r) {
            let i = 0;
            for (let s = this.from; s < this.to; s++) {
                let o = this.maps[s], l = o.mapResult(e, t);
                if (l.recover != null) {
                    let a = this.getMirror(s);
                    if (a != null && a > s && a < this.to) {
                        s = a, e = this.maps[a].recover(l.recover);
                        continue
                    }
                }
                i |= l.delInfo, e = l.pos
            }
            return r ? e : new Nn(e, i, null)
        }
    }

    const Tn = Object.create(null);

    class L {
        getMap() {
            return G.empty
        }

        merge(e) {
            return null
        }

        static fromJSON(e, t) {
            if (!t || !t.stepType) throw new RangeError("Invalid input for Step.fromJSON");
            let r = Tn[t.stepType];
            if (!r) throw new RangeError(`No step type ${t.stepType} defined`);
            return r.fromJSON(e, t)
        }

        static jsonID(e, t) {
            if (e in Tn) throw new RangeError("Duplicate use of step JSON ID " + e);
            return Tn[e] = t, t.prototype.jsonID = e, t
        }
    }

    class E {
        constructor(e, t) {
            this.doc = e, this.failed = t
        }

        static ok(e) {
            return new E(e, null)
        }

        static fail(e) {
            return new E(null, e)
        }

        static fromReplace(e, t, r, i) {
            try {
                return E.ok(e.replace(t, r, i))
            } catch (s) {
                if (s instanceof $t) return E.fail(s.message);
                throw s
            }
        }
    }

    function An(n, e, t) {
        let r = [];
        for (let i = 0; i < n.childCount; i++) {
            let s = n.child(i);
            s.content.size && (s = s.copy(An(s.content, e, s))), s.isInline && (s = e(s, t, i)), r.push(s)
        }
        return y.fromArray(r)
    }

    class xe extends L {
        constructor(e, t, r) {
            super(), this.from = e, this.to = t, this.mark = r
        }

        apply(e) {
            let t = e.slice(this.from, this.to), r = e.resolve(this.from), i = r.node(r.sharedDepth(this.to)),
                s = new x(An(t.content, (o, l) => !o.isAtom || !l.type.allowsMarkType(this.mark.type) ? o : o.mark(this.mark.addToSet(o.marks)), i), t.openStart, t.openEnd);
            return E.fromReplace(e, this.from, this.to, s)
        }

        invert() {
            return new se(this.from, this.to, this.mark)
        }

        map(e) {
            let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
            return t.deleted && r.deleted || t.pos >= r.pos ? null : new xe(t.pos, r.pos, this.mark)
        }

        merge(e) {
            return e instanceof xe && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new xe(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null
        }

        toJSON() {
            return {stepType: "addMark", mark: this.mark.toJSON(), from: this.from, to: this.to}
        }

        static fromJSON(e, t) {
            if (typeof t.from != "number" || typeof t.to != "number") throw new RangeError("Invalid input for AddMarkStep.fromJSON");
            return new xe(t.from, t.to, e.markFromJSON(t.mark))
        }
    }

    L.jsonID("addMark", xe);

    class se extends L {
        constructor(e, t, r) {
            super(), this.from = e, this.to = t, this.mark = r
        }

        apply(e) {
            let t = e.slice(this.from, this.to),
                r = new x(An(t.content, i => i.mark(this.mark.removeFromSet(i.marks)), e), t.openStart, t.openEnd);
            return E.fromReplace(e, this.from, this.to, r)
        }

        invert() {
            return new xe(this.from, this.to, this.mark)
        }

        map(e) {
            let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
            return t.deleted && r.deleted || t.pos >= r.pos ? null : new se(t.pos, r.pos, this.mark)
        }

        merge(e) {
            return e instanceof se && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new se(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null
        }

        toJSON() {
            return {stepType: "removeMark", mark: this.mark.toJSON(), from: this.from, to: this.to}
        }

        static fromJSON(e, t) {
            if (typeof t.from != "number" || typeof t.to != "number") throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
            return new se(t.from, t.to, e.markFromJSON(t.mark))
        }
    }

    L.jsonID("removeMark", se);

    class ke extends L {
        constructor(e, t) {
            super(), this.pos = e, this.mark = t
        }

        apply(e) {
            let t = e.nodeAt(this.pos);
            if (!t) return E.fail("No node at mark step's position");
            let r = t.type.create(t.attrs, null, this.mark.addToSet(t.marks));
            return E.fromReplace(e, this.pos, this.pos + 1, new x(y.from(r), 0, t.isLeaf ? 0 : 1))
        }

        invert(e) {
            let t = e.nodeAt(this.pos);
            if (t) {
                let r = this.mark.addToSet(t.marks);
                if (r.length == t.marks.length) {
                    for (let i = 0; i < t.marks.length; i++) if (!t.marks[i].isInSet(r)) return new ke(this.pos, t.marks[i]);
                    return new ke(this.pos, this.mark)
                }
            }
            return new et(this.pos, this.mark)
        }

        map(e) {
            let t = e.mapResult(this.pos, 1);
            return t.deletedAfter ? null : new ke(t.pos, this.mark)
        }

        toJSON() {
            return {stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON()}
        }

        static fromJSON(e, t) {
            if (typeof t.pos != "number") throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
            return new ke(t.pos, e.markFromJSON(t.mark))
        }
    }

    L.jsonID("addNodeMark", ke);

    class et extends L {
        constructor(e, t) {
            super(), this.pos = e, this.mark = t
        }

        apply(e) {
            let t = e.nodeAt(this.pos);
            if (!t) return E.fail("No node at mark step's position");
            let r = t.type.create(t.attrs, null, this.mark.removeFromSet(t.marks));
            return E.fromReplace(e, this.pos, this.pos + 1, new x(y.from(r), 0, t.isLeaf ? 0 : 1))
        }

        invert(e) {
            let t = e.nodeAt(this.pos);
            return !t || !this.mark.isInSet(t.marks) ? this : new ke(this.pos, this.mark)
        }

        map(e) {
            let t = e.mapResult(this.pos, 1);
            return t.deletedAfter ? null : new et(t.pos, this.mark)
        }

        toJSON() {
            return {stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON()}
        }

        static fromJSON(e, t) {
            if (typeof t.pos != "number") throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
            return new et(t.pos, e.markFromJSON(t.mark))
        }
    }

    L.jsonID("removeNodeMark", et);

    class H extends L {
        constructor(e, t, r, i = !1) {
            super(), this.from = e, this.to = t, this.slice = r, this.structure = i
        }

        apply(e) {
            return this.structure && Dn(e, this.from, this.to) ? E.fail("Structure replace would overwrite content") : E.fromReplace(e, this.from, this.to, this.slice)
        }

        getMap() {
            return new G([this.from, this.to - this.from, this.slice.size])
        }

        invert(e) {
            return new H(this.from, this.from + this.slice.size, e.slice(this.from, this.to))
        }

        map(e) {
            let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1);
            return t.deletedAcross && r.deletedAcross ? null : new H(t.pos, Math.max(t.pos, r.pos), this.slice)
        }

        merge(e) {
            if (!(e instanceof H) || e.structure || this.structure) return null;
            if (this.from + this.slice.size == e.from && !this.slice.openEnd && !e.slice.openStart) {
                let t = this.slice.size + e.slice.size == 0 ? x.empty : new x(this.slice.content.append(e.slice.content), this.slice.openStart, e.slice.openEnd);
                return new H(this.from, this.to + (e.to - e.from), t, this.structure)
            } else if (e.to == this.from && !this.slice.openStart && !e.slice.openEnd) {
                let t = this.slice.size + e.slice.size == 0 ? x.empty : new x(e.slice.content.append(this.slice.content), e.slice.openStart, this.slice.openEnd);
                return new H(e.from, this.to, t, this.structure)
            } else return null
        }

        toJSON() {
            let e = {stepType: "replace", from: this.from, to: this.to};
            return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e
        }

        static fromJSON(e, t) {
            if (typeof t.from != "number" || typeof t.to != "number") throw new RangeError("Invalid input for ReplaceStep.fromJSON");
            return new H(t.from, t.to, x.fromJSON(e, t.slice), !!t.structure)
        }
    }

    L.jsonID("replace", H);

    class P extends L {
        constructor(e, t, r, i, s, o, l = !1) {
            super(), this.from = e, this.to = t, this.gapFrom = r, this.gapTo = i, this.slice = s, this.insert = o, this.structure = l
        }

        apply(e) {
            if (this.structure && (Dn(e, this.from, this.gapFrom) || Dn(e, this.gapTo, this.to))) return E.fail("Structure gap-replace would overwrite content");
            let t = e.slice(this.gapFrom, this.gapTo);
            if (t.openStart || t.openEnd) return E.fail("Gap is not a flat range");
            let r = this.slice.insertAt(this.insert, t.content);
            return r ? E.fromReplace(e, this.from, this.to, r) : E.fail("Content does not fit in gap")
        }

        getMap() {
            return new G([this.from, this.gapFrom - this.from, this.insert, this.gapTo, this.to - this.gapTo, this.slice.size - this.insert])
        }

        invert(e) {
            let t = this.gapTo - this.gapFrom;
            return new P(this.from, this.from + this.slice.size + t, this.from + this.insert, this.from + this.insert + t, e.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure)
        }

        map(e) {
            let t = e.mapResult(this.from, 1), r = e.mapResult(this.to, -1),
                i = this.from == this.gapFrom ? t.pos : e.map(this.gapFrom, -1),
                s = this.to == this.gapTo ? r.pos : e.map(this.gapTo, 1);
            return t.deletedAcross && r.deletedAcross || i < t.pos || s > r.pos ? null : new P(t.pos, r.pos, i, s, this.slice, this.insert, this.structure)
        }

        toJSON() {
            let e = {
                stepType: "replaceAround",
                from: this.from,
                to: this.to,
                gapFrom: this.gapFrom,
                gapTo: this.gapTo,
                insert: this.insert
            };
            return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e
        }

        static fromJSON(e, t) {
            if (typeof t.from != "number" || typeof t.to != "number" || typeof t.gapFrom != "number" || typeof t.gapTo != "number" || typeof t.insert != "number") throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
            return new P(t.from, t.to, t.gapFrom, t.gapTo, x.fromJSON(e, t.slice), t.insert, !!t.structure)
        }
    }

    L.jsonID("replaceAround", P);

    function Dn(n, e, t) {
        let r = n.resolve(e), i = t - e, s = r.depth;
        for (; i > 0 && s > 0 && r.indexAfter(s) == r.node(s).childCount;) s--, i--;
        if (i > 0) {
            let o = r.node(s).maybeChild(r.indexAfter(s));
            for (; i > 0;) {
                if (!o || o.isLeaf) return !0;
                o = o.firstChild, i--
            }
        }
        return !1
    }

    function ul(n, e, t, r) {
        let i = [], s = [], o, l;
        n.doc.nodesBetween(e, t, (a, c, f) => {
            if (!a.isInline) return;
            let h = a.marks;
            if (!r.isInSet(h) && f.type.allowsMarkType(r.type)) {
                let d = Math.max(c, e), u = Math.min(c + a.nodeSize, t), p = r.addToSet(h);
                for (let m = 0; m < h.length; m++) h[m].isInSet(p) || (o && o.to == d && o.mark.eq(h[m]) ? o.to = u : i.push(o = new se(d, u, h[m])));
                l && l.to == d ? l.to = u : s.push(l = new xe(d, u, r))
            }
        }), i.forEach(a => n.step(a)), s.forEach(a => n.step(a))
    }

    function pl(n, e, t, r) {
        let i = [], s = 0;
        n.doc.nodesBetween(e, t, (o, l) => {
            if (!o.isInline) return;
            s++;
            let a = null;
            if (r instanceof Kt) {
                let c = o.marks, f;
                for (; f = r.isInSet(c);) (a || (a = [])).push(f), c = f.removeFromSet(c)
            } else r ? r.isInSet(o.marks) && (a = [r]) : a = o.marks;
            if (a && a.length) {
                let c = Math.min(l + o.nodeSize, t);
                for (let f = 0; f < a.length; f++) {
                    let h = a[f], d;
                    for (let u = 0; u < i.length; u++) {
                        let p = i[u];
                        p.step == s - 1 && h.eq(i[u].style) && (d = p)
                    }
                    d ? (d.to = c, d.step = s) : i.push({style: h, from: Math.max(l, e), to: c, step: s})
                }
            }
        }), i.forEach(o => n.step(new se(o.from, o.to, o.style)))
    }

    function En(n, e, t, r = t.contentMatch, i = !0) {
        let s = n.doc.nodeAt(e), o = [], l = e + 1;
        for (let a = 0; a < s.childCount; a++) {
            let c = s.child(a), f = l + c.nodeSize, h = r.matchType(c.type);
            if (!h) o.push(new H(l, f, x.empty)); else {
                r = h;
                for (let d = 0; d < c.marks.length; d++) t.allowsMarkType(c.marks[d].type) || n.step(new se(l, f, c.marks[d]));
                if (i && c.isText && t.whitespace != "pre") {
                    let d, u = /\r?\n|\r/g, p;
                    for (; d = u.exec(c.text);) p || (p = new x(y.from(t.schema.text(" ", t.allowedMarks(c.marks))), 0, 0)), o.push(new H(l + d.index, l + d.index + d[0].length, p))
                }
            }
            l = f
        }
        if (!r.validEnd) {
            let a = r.fillBefore(y.empty, !0);
            n.replace(l, l, new x(a, 0, 0))
        }
        for (let a = o.length - 1; a >= 0; a--) n.step(o[a])
    }

    function ml(n, e, t) {
        return (e == 0 || n.canReplace(e, n.childCount)) && (t == n.childCount || n.canReplace(0, t))
    }

    function Yt(n) {
        let t = n.parent.content.cutByIndex(n.startIndex, n.endIndex);
        for (let r = n.depth; ; --r) {
            let i = n.$from.node(r), s = n.$from.index(r), o = n.$to.indexAfter(r);
            if (r < n.depth && i.canReplace(s, o, t)) return r;
            if (r == 0 || i.type.spec.isolating || !ml(i, s, o)) break
        }
        return null
    }

    function gl(n, e, t) {
        let {$from: r, $to: i, depth: s} = e, o = r.before(s + 1), l = i.after(s + 1), a = o, c = l, f = y.empty, h = 0;
        for (let p = s, m = !1; p > t; p--) m || r.index(p) > 0 ? (m = !0, f = y.from(r.node(p).copy(f)), h++) : a--;
        let d = y.empty, u = 0;
        for (let p = s, m = !1; p > t; p--) m || i.after(p + 1) < i.end(p) ? (m = !0, d = y.from(i.node(p).copy(d)), u++) : c++;
        n.step(new P(a, c, o, l, new x(f.append(d), h, u), f.size - h, !0))
    }

    function ai(n, e, t = null, r = n) {
        let i = yl(n, e), s = i && bl(r, e);
        return s ? i.map(ci).concat({type: e, attrs: t}).concat(s.map(ci)) : null
    }

    function ci(n) {
        return {type: n, attrs: null}
    }

    function yl(n, e) {
        let {parent: t, startIndex: r, endIndex: i} = n, s = t.contentMatchAt(r).findWrapping(e);
        if (!s) return null;
        let o = s.length ? s[0] : e;
        return t.canReplaceWith(r, i, o) ? s : null
    }

    function bl(n, e) {
        let {parent: t, startIndex: r, endIndex: i} = n, s = t.child(r), o = e.contentMatch.findWrapping(s.type);
        if (!o) return null;
        let a = (o.length ? o[o.length - 1] : e).contentMatch;
        for (let c = r; a && c < i; c++) a = a.matchType(t.child(c).type);
        return !a || !a.validEnd ? null : o
    }

    function xl(n, e, t) {
        let r = y.empty;
        for (let o = t.length - 1; o >= 0; o--) {
            if (r.size) {
                let l = t[o].type.contentMatch.matchFragment(r);
                if (!l || !l.validEnd) throw new RangeError("Wrapper type given to Transform.wrap does not form valid content of its parent wrapper")
            }
            r = y.from(t[o].type.create(t[o].attrs, r))
        }
        let i = e.start, s = e.end;
        n.step(new P(i, s, i, s, new x(r, 0, 0), t.length, !0))
    }

    function kl(n, e, t, r, i) {
        if (!r.isTextblock) throw new RangeError("Type given to setBlockType should be a textblock");
        let s = n.steps.length;
        n.doc.nodesBetween(e, t, (o, l) => {
            let a = typeof i == "function" ? i(o) : i;
            if (o.isTextblock && !o.hasMarkup(r, a) && Sl(n.doc, n.mapping.slice(s).map(l), r)) {
                let c = null;
                if (r.schema.linebreakReplacement) {
                    let u = r.whitespace == "pre", p = !!r.contentMatch.matchType(r.schema.linebreakReplacement);
                    u && !p ? c = !1 : !u && p && (c = !0)
                }
                c === !1 && hi(n, o, l, s), En(n, n.mapping.slice(s).map(l, 1), r, void 0, c === null);
                let f = n.mapping.slice(s), h = f.map(l, 1), d = f.map(l + o.nodeSize, 1);
                return n.step(new P(h, d, h + 1, d - 1, new x(y.from(r.create(a, null, o.marks)), 0, 0), 1, !0)), c === !0 && fi(n, o, l, s), !1
            }
        })
    }

    function fi(n, e, t, r) {
        e.forEach((i, s) => {
            if (i.isText) {
                let o, l = /\r?\n|\r/g;
                for (; o = l.exec(i.text);) {
                    let a = n.mapping.slice(r).map(t + 1 + s + o.index);
                    n.replaceWith(a, a + 1, e.type.schema.linebreakReplacement.create())
                }
            }
        })
    }

    function hi(n, e, t, r) {
        e.forEach((i, s) => {
            if (i.type == i.type.schema.linebreakReplacement) {
                let o = n.mapping.slice(r).map(t + 1 + s);
                n.replaceWith(o, o + 1, e.type.schema.text(`
`))
            }
        })
    }

    function Sl(n, e, t) {
        let r = n.resolve(e), i = r.index();
        return r.parent.canReplaceWith(i, i + 1, t)
    }

    function Cl(n, e, t, r, i) {
        let s = n.doc.nodeAt(e);
        if (!s) throw new RangeError("No node at given position");
        t || (t = s.type);
        let o = t.create(r, null, i || s.marks);
        if (s.isLeaf) return n.replaceWith(e, e + s.nodeSize, o);
        if (!t.validContent(s.content)) throw new RangeError("Invalid content for node type " + t.name);
        n.step(new P(e, e + s.nodeSize, e + 1, e + s.nodeSize - 1, new x(y.from(o), 0, 0), 1, !0))
    }

    function tt(n, e, t = 1, r) {
        let i = n.resolve(e), s = i.depth - t, o = r && r[r.length - 1] || i.parent;
        if (s < 0 || i.parent.type.spec.isolating || !i.parent.canReplace(i.index(), i.parent.childCount) || !o.type.validContent(i.parent.content.cutByIndex(i.index(), i.parent.childCount))) return !1;
        for (let c = i.depth - 1, f = t - 2; c > s; c--, f--) {
            let h = i.node(c), d = i.index(c);
            if (h.type.spec.isolating) return !1;
            let u = h.content.cutByIndex(d, h.childCount), p = r && r[f + 1];
            p && (u = u.replaceChild(0, p.type.create(p.attrs)));
            let m = r && r[f] || h;
            if (!h.canReplace(d + 1, h.childCount) || !m.type.validContent(u)) return !1
        }
        let l = i.indexAfter(s), a = r && r[0];
        return i.node(s).canReplaceWith(l, l, a ? a.type : i.node(s + 1).type)
    }

    function wl(n, e, t = 1, r) {
        let i = n.doc.resolve(e), s = y.empty, o = y.empty;
        for (let l = i.depth, a = i.depth - t, c = t - 1; l > a; l--, c--) {
            s = y.from(i.node(l).copy(s));
            let f = r && r[c];
            o = y.from(f ? f.type.create(f.attrs, o) : i.node(l).copy(o))
        }
        n.step(new H(e, e, new x(s.append(o), t, t), !0))
    }

    function Zt(n, e) {
        let t = n.resolve(e), r = t.index();
        return Ol(t.nodeBefore, t.nodeAfter) && t.parent.canReplace(r, r + 1)
    }

    function Ml(n, e) {
        e.content.size || n.type.compatibleContent(e.type);
        let t = n.contentMatchAt(n.childCount), {linebreakReplacement: r} = n.type.schema;
        for (let i = 0; i < e.childCount; i++) {
            let s = e.child(i), o = s.type == r ? n.type.schema.nodes.text : s.type;
            if (t = t.matchType(o), !t || !n.type.allowsMarks(s.marks)) return !1
        }
        return t.validEnd
    }

    function Ol(n, e) {
        return !!(n && e && !n.isLeaf && Ml(n, e))
    }

    function Nl(n, e, t) {
        let r = null, {linebreakReplacement: i} = n.doc.type.schema, s = n.doc.resolve(e - t), o = s.node().type;
        if (i && o.inlineContent) {
            let f = o.whitespace == "pre", h = !!o.contentMatch.matchType(i);
            f && !h ? r = !1 : !f && h && (r = !0)
        }
        let l = n.steps.length;
        if (r === !1) {
            let f = n.doc.resolve(e + t);
            hi(n, f.node(), f.before(), l)
        }
        o.inlineContent && En(n, e + t - 1, o, s.node().contentMatchAt(s.index()), r == null);
        let a = n.mapping.slice(l), c = a.map(e - t);
        if (n.step(new H(c, a.map(e + t, -1), x.empty, !0)), r === !0) {
            let f = n.doc.resolve(c);
            fi(n, f.node(), f.before(), n.steps.length)
        }
        return n
    }

    function Tl(n, e, t) {
        let r = n.resolve(e);
        if (r.parent.canReplaceWith(r.index(), r.index(), t)) return e;
        if (r.parentOffset == 0) for (let i = r.depth - 1; i >= 0; i--) {
            let s = r.index(i);
            if (r.node(i).canReplaceWith(s, s, t)) return r.before(i + 1);
            if (s > 0) return null
        }
        if (r.parentOffset == r.parent.content.size) for (let i = r.depth - 1; i >= 0; i--) {
            let s = r.indexAfter(i);
            if (r.node(i).canReplaceWith(s, s, t)) return r.after(i + 1);
            if (s < r.node(i).childCount) return null
        }
        return null
    }

    function Al(n, e, t) {
        let r = n.resolve(e);
        if (!t.content.size) return e;
        let i = t.content;
        for (let s = 0; s < t.openStart; s++) i = i.firstChild.content;
        for (let s = 1; s <= (t.openStart == 0 && t.size ? 2 : 1); s++) for (let o = r.depth; o >= 0; o--) {
            let l = o == r.depth ? 0 : r.pos <= (r.start(o + 1) + r.end(o + 1)) / 2 ? -1 : 1,
                a = r.index(o) + (l > 0 ? 1 : 0), c = r.node(o), f = !1;
            if (s == 1) f = c.canReplace(a, a, i); else {
                let h = c.contentMatchAt(a).findWrapping(i.firstChild.type);
                f = h && c.canReplaceWith(a, a, h[0])
            }
            if (f) return l == 0 ? r.pos : l < 0 ? r.before(o + 1) : r.after(o + 1)
        }
        return null
    }

    function Rn(n, e, t = e, r = x.empty) {
        if (e == t && !r.size) return null;
        let i = n.resolve(e), s = n.resolve(t);
        return di(i, s, r) ? new H(e, t, r) : new Dl(i, s, r).fit()
    }

    function di(n, e, t) {
        return !t.openStart && !t.openEnd && n.start() == e.start() && n.parent.canReplace(n.index(), e.index(), t.content)
    }

    class Dl {
        constructor(e, t, r) {
            this.$from = e, this.$to = t, this.unplaced = r, this.frontier = [], this.placed = y.empty;
            for (let i = 0; i <= e.depth; i++) {
                let s = e.node(i);
                this.frontier.push({type: s.type, match: s.contentMatchAt(e.indexAfter(i))})
            }
            for (let i = e.depth; i > 0; i--) this.placed = y.from(e.node(i).copy(this.placed))
        }

        get depth() {
            return this.frontier.length - 1
        }

        fit() {
            for (; this.unplaced.size;) {
                let c = this.findFittable();
                c ? this.placeNodes(c) : this.openMore() || this.dropNode()
            }
            let e = this.mustMoveInline(), t = this.placed.size - this.depth - this.$from.depth, r = this.$from,
                i = this.close(e < 0 ? this.$to : r.doc.resolve(e));
            if (!i) return null;
            let s = this.placed, o = r.depth, l = i.depth;
            for (; o && l && s.childCount == 1;) s = s.firstChild.content, o--, l--;
            let a = new x(s, o, l);
            return e > -1 ? new P(r.pos, e, this.$to.pos, this.$to.end(), a, t) : a.size || r.pos != this.$to.pos ? new H(r.pos, i.pos, a) : null
        }

        findFittable() {
            let e = this.unplaced.openStart;
            for (let t = this.unplaced.content, r = 0, i = this.unplaced.openEnd; r < e; r++) {
                let s = t.firstChild;
                if (t.childCount > 1 && (i = 0), s.type.spec.isolating && i <= r) {
                    e = r;
                    break
                }
                t = s.content
            }
            for (let t = 1; t <= 2; t++) for (let r = t == 1 ? e : this.unplaced.openStart; r >= 0; r--) {
                let i, s = null;
                r ? (s = In(this.unplaced.content, r - 1).firstChild, i = s.content) : i = this.unplaced.content;
                let o = i.firstChild;
                for (let l = this.depth; l >= 0; l--) {
                    let {type: a, match: c} = this.frontier[l], f, h = null;
                    if (t == 1 && (o ? c.matchType(o.type) || (h = c.fillBefore(y.from(o), !1)) : s && a.compatibleContent(s.type))) return {
                        sliceDepth: r,
                        frontierDepth: l,
                        parent: s,
                        inject: h
                    };
                    if (t == 2 && o && (f = c.findWrapping(o.type))) return {
                        sliceDepth: r,
                        frontierDepth: l,
                        parent: s,
                        wrap: f
                    };
                    if (s && c.matchType(s.type)) break
                }
            }
        }

        openMore() {
            let {content: e, openStart: t, openEnd: r} = this.unplaced, i = In(e, t);
            return !i.childCount || i.firstChild.isLeaf ? !1 : (this.unplaced = new x(e, t + 1, Math.max(r, i.size + t >= e.size - r ? t + 1 : 0)), !0)
        }

        dropNode() {
            let {content: e, openStart: t, openEnd: r} = this.unplaced, i = In(e, t);
            if (i.childCount <= 1 && t > 0) {
                let s = e.size - t <= t + i.size;
                this.unplaced = new x(bt(e, t - 1, 1), t - 1, s ? t - 1 : r)
            } else this.unplaced = new x(bt(e, t, 1), t, r)
        }

        placeNodes({sliceDepth: e, frontierDepth: t, parent: r, inject: i, wrap: s}) {
            for (; this.depth > t;) this.closeFrontierNode();
            if (s) for (let m = 0; m < s.length; m++) this.openFrontierNode(s[m]);
            let o = this.unplaced, l = r ? r.content : o.content, a = o.openStart - e, c = 0, f = [], {
                match: h,
                type: d
            } = this.frontier[t];
            if (i) {
                for (let m = 0; m < i.childCount; m++) f.push(i.child(m));
                h = h.matchFragment(i)
            }
            let u = l.size + e - (o.content.size - o.openEnd);
            for (; c < l.childCount;) {
                let m = l.child(c), g = h.matchType(m.type);
                if (!g) break;
                c++, (c > 1 || a == 0 || m.content.size) && (h = g, f.push(ui(m.mark(d.allowedMarks(m.marks)), c == 1 ? a : 0, c == l.childCount ? u : -1)))
            }
            let p = c == l.childCount;
            p || (u = -1), this.placed = xt(this.placed, t, y.from(f)), this.frontier[t].match = h, p && u < 0 && r && r.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
            for (let m = 0, g = l; m < u; m++) {
                let b = g.lastChild;
                this.frontier.push({type: b.type, match: b.contentMatchAt(b.childCount)}), g = b.content
            }
            this.unplaced = p ? e == 0 ? x.empty : new x(bt(o.content, e - 1, 1), e - 1, u < 0 ? o.openEnd : e - 1) : new x(bt(o.content, e, c), o.openStart, o.openEnd)
        }

        mustMoveInline() {
            if (!this.$to.parent.isTextblock) return -1;
            let e = this.frontier[this.depth], t;
            if (!e.type.isTextblock || !vn(this.$to, this.$to.depth, e.type, e.match, !1) || this.$to.depth == this.depth && (t = this.findCloseLevel(this.$to)) && t.depth == this.depth) return -1;
            let {depth: r} = this.$to, i = this.$to.after(r);
            for (; r > 1 && i == this.$to.end(--r);) ++i;
            return i
        }

        findCloseLevel(e) {
            e:for (let t = Math.min(this.depth, e.depth); t >= 0; t--) {
                let {match: r, type: i} = this.frontier[t],
                    s = t < e.depth && e.end(t + 1) == e.pos + (e.depth - (t + 1)), o = vn(e, t, i, r, s);
                if (o) {
                    for (let l = t - 1; l >= 0; l--) {
                        let {match: a, type: c} = this.frontier[l], f = vn(e, l, c, a, !0);
                        if (!f || f.childCount) continue e
                    }
                    return {depth: t, fit: o, move: s ? e.doc.resolve(e.after(t + 1)) : e}
                }
            }
        }

        close(e) {
            let t = this.findCloseLevel(e);
            if (!t) return null;
            for (; this.depth > t.depth;) this.closeFrontierNode();
            t.fit.childCount && (this.placed = xt(this.placed, t.depth, t.fit)), e = t.move;
            for (let r = t.depth + 1; r <= e.depth; r++) {
                let i = e.node(r), s = i.type.contentMatch.fillBefore(i.content, !0, e.index(r));
                this.openFrontierNode(i.type, i.attrs, s)
            }
            return e
        }

        openFrontierNode(e, t = null, r) {
            let i = this.frontier[this.depth];
            i.match = i.match.matchType(e), this.placed = xt(this.placed, this.depth, y.from(e.create(t, r))), this.frontier.push({
                type: e,
                match: e.contentMatch
            })
        }

        closeFrontierNode() {
            let t = this.frontier.pop().match.fillBefore(y.empty, !0);
            t.childCount && (this.placed = xt(this.placed, this.frontier.length, t))
        }
    }

    function bt(n, e, t) {
        return e == 0 ? n.cutByIndex(t, n.childCount) : n.replaceChild(0, n.firstChild.copy(bt(n.firstChild.content, e - 1, t)))
    }

    function xt(n, e, t) {
        return e == 0 ? n.append(t) : n.replaceChild(n.childCount - 1, n.lastChild.copy(xt(n.lastChild.content, e - 1, t)))
    }

    function In(n, e) {
        for (let t = 0; t < e; t++) n = n.firstChild.content;
        return n
    }

    function ui(n, e, t) {
        if (e <= 0) return n;
        let r = n.content;
        return e > 1 && (r = r.replaceChild(0, ui(r.firstChild, e - 1, r.childCount == 1 ? t - 1 : 0))), e > 0 && (r = n.type.contentMatch.fillBefore(r).append(r), t <= 0 && (r = r.append(n.type.contentMatch.matchFragment(r).fillBefore(y.empty, !0)))), n.copy(r)
    }

    function vn(n, e, t, r, i) {
        let s = n.node(e), o = i ? n.indexAfter(e) : n.index(e);
        if (o == s.childCount && !t.compatibleContent(s.type)) return null;
        let l = r.fillBefore(s.content, !0, o);
        return l && !El(t, s.content, o) ? l : null
    }

    function El(n, e, t) {
        for (let r = t; r < e.childCount; r++) if (!n.allowsMarks(e.child(r).marks)) return !0;
        return !1
    }

    function Rl(n) {
        return n.spec.defining || n.spec.definingForContent
    }

    function Il(n, e, t, r) {
        if (!r.size) return n.deleteRange(e, t);
        let i = n.doc.resolve(e), s = n.doc.resolve(t);
        if (di(i, s, r)) return n.step(new H(e, t, r));
        let o = mi(i, n.doc.resolve(t));
        o[o.length - 1] == 0 && o.pop();
        let l = -(i.depth + 1);
        o.unshift(l);
        for (let d = i.depth, u = i.pos - 1; d > 0; d--, u--) {
            let p = i.node(d).type.spec;
            if (p.defining || p.definingAsContext || p.isolating) break;
            o.indexOf(d) > -1 ? l = d : i.before(d) == u && o.splice(1, 0, -d)
        }
        let a = o.indexOf(l), c = [], f = r.openStart;
        for (let d = r.content, u = 0; ; u++) {
            let p = d.firstChild;
            if (c.push(p), u == r.openStart) break;
            d = p.content
        }
        for (let d = f - 1; d >= 0; d--) {
            let u = c[d], p = Rl(u.type);
            if (p && !u.sameMarkup(i.node(Math.abs(l) - 1))) f = d; else if (p || !u.type.isTextblock) break
        }
        for (let d = r.openStart; d >= 0; d--) {
            let u = (d + f + 1) % (r.openStart + 1), p = c[u];
            if (p) for (let m = 0; m < o.length; m++) {
                let g = o[(m + a) % o.length], b = !0;
                g < 0 && (b = !1, g = -g);
                let w = i.node(g - 1), N = i.index(g - 1);
                if (w.canReplaceWith(N, N, p.type, p.marks)) return n.replace(i.before(g), b ? s.after(g) : t, new x(pi(r.content, 0, r.openStart, u), u, r.openEnd))
            }
        }
        let h = n.steps.length;
        for (let d = o.length - 1; d >= 0 && (n.replace(e, t, r), !(n.steps.length > h)); d--) {
            let u = o[d];
            u < 0 || (e = i.before(u), t = s.after(u))
        }
    }

    function pi(n, e, t, r, i) {
        if (e < t) {
            let s = n.firstChild;
            n = n.replaceChild(0, s.copy(pi(s.content, e + 1, t, r, s)))
        }
        if (e > r) {
            let s = i.contentMatchAt(0), o = s.fillBefore(n).append(n);
            n = o.append(s.matchFragment(o).fillBefore(y.empty, !0))
        }
        return n
    }

    function vl(n, e, t, r) {
        if (!r.isInline && e == t && n.doc.resolve(e).parent.content.size) {
            let i = Tl(n.doc, e, r.type);
            i != null && (e = t = i)
        }
        n.replaceRange(e, t, new x(y.from(r), 0, 0))
    }

    function zl(n, e, t) {
        let r = n.doc.resolve(e), i = n.doc.resolve(t), s = mi(r, i);
        for (let o = 0; o < s.length; o++) {
            let l = s[o], a = o == s.length - 1;
            if (a && l == 0 || r.node(l).type.contentMatch.validEnd) return n.delete(r.start(l), i.end(l));
            if (l > 0 && (a || r.node(l - 1).canReplace(r.index(l - 1), i.indexAfter(l - 1)))) return n.delete(r.before(l), i.after(l))
        }
        for (let o = 1; o <= r.depth && o <= i.depth; o++) if (e - r.start(o) == r.depth - o && t > r.end(o) && i.end(o) - t != i.depth - o && r.start(o - 1) == i.start(o - 1) && r.node(o - 1).canReplace(r.index(o - 1), i.index(o - 1))) return n.delete(r.before(o), t);
        n.delete(e, t)
    }

    function mi(n, e) {
        let t = [], r = Math.min(n.depth, e.depth);
        for (let i = r; i >= 0; i--) {
            let s = n.start(i);
            if (s < n.pos - (n.depth - i) || e.end(i) > e.pos + (e.depth - i) || n.node(i).type.spec.isolating || e.node(i).type.spec.isolating) break;
            (s == e.start(i) || i == n.depth && i == e.depth && n.parent.inlineContent && e.parent.inlineContent && i && e.start(i - 1) == s - 1) && t.push(i)
        }
        return t
    }

    class nt extends L {
        constructor(e, t, r) {
            super(), this.pos = e, this.attr = t, this.value = r
        }

        apply(e) {
            let t = e.nodeAt(this.pos);
            if (!t) return E.fail("No node at attribute step's position");
            let r = Object.create(null);
            for (let s in t.attrs) r[s] = t.attrs[s];
            r[this.attr] = this.value;
            let i = t.type.create(r, null, t.marks);
            return E.fromReplace(e, this.pos, this.pos + 1, new x(y.from(i), 0, t.isLeaf ? 0 : 1))
        }

        getMap() {
            return G.empty
        }

        invert(e) {
            return new nt(this.pos, this.attr, e.nodeAt(this.pos).attrs[this.attr])
        }

        map(e) {
            let t = e.mapResult(this.pos, 1);
            return t.deletedAfter ? null : new nt(t.pos, this.attr, this.value)
        }

        toJSON() {
            return {stepType: "attr", pos: this.pos, attr: this.attr, value: this.value}
        }

        static fromJSON(e, t) {
            if (typeof t.pos != "number" || typeof t.attr != "string") throw new RangeError("Invalid input for AttrStep.fromJSON");
            return new nt(t.pos, t.attr, t.value)
        }
    }

    L.jsonID("attr", nt);

    class kt extends L {
        constructor(e, t) {
            super(), this.attr = e, this.value = t
        }

        apply(e) {
            let t = Object.create(null);
            for (let i in e.attrs) t[i] = e.attrs[i];
            t[this.attr] = this.value;
            let r = e.type.create(t, e.content, e.marks);
            return E.ok(r)
        }

        getMap() {
            return G.empty
        }

        invert(e) {
            return new kt(this.attr, e.attrs[this.attr])
        }

        map(e) {
            return this
        }

        toJSON() {
            return {stepType: "docAttr", attr: this.attr, value: this.value}
        }

        static fromJSON(e, t) {
            if (typeof t.attr != "string") throw new RangeError("Invalid input for DocAttrStep.fromJSON");
            return new kt(t.attr, t.value)
        }
    }

    L.jsonID("docAttr", kt);
    let rt = class extends Error {
    };
    rt = function n(e) {
        let t = Error.call(this, e);
        return t.__proto__ = n.prototype, t
    }, rt.prototype = Object.create(Error.prototype), rt.prototype.constructor = rt, rt.prototype.name = "TransformError";

    class gi {
        constructor(e) {
            this.doc = e, this.steps = [], this.docs = [], this.mapping = new Qe
        }

        get before() {
            return this.docs.length ? this.docs[0] : this.doc
        }

        step(e) {
            let t = this.maybeStep(e);
            if (t.failed) throw new rt(t.failed);
            return this
        }

        maybeStep(e) {
            let t = e.apply(this.doc);
            return t.failed || this.addStep(e, t.doc), t
        }

        get docChanged() {
            return this.steps.length > 0
        }

        addStep(e, t) {
            this.docs.push(this.doc), this.steps.push(e), this.mapping.appendMap(e.getMap()), this.doc = t
        }

        replace(e, t = e, r = x.empty) {
            let i = Rn(this.doc, e, t, r);
            return i && this.step(i), this
        }

        replaceWith(e, t, r) {
            return this.replace(e, t, new x(y.from(r), 0, 0))
        }

        delete(e, t) {
            return this.replace(e, t, x.empty)
        }

        insert(e, t) {
            return this.replaceWith(e, e, t)
        }

        replaceRange(e, t, r) {
            return Il(this, e, t, r), this
        }

        replaceRangeWith(e, t, r) {
            return vl(this, e, t, r), this
        }

        deleteRange(e, t) {
            return zl(this, e, t), this
        }

        lift(e, t) {
            return gl(this, e, t), this
        }

        join(e, t = 1) {
            return Nl(this, e, t), this
        }

        wrap(e, t) {
            return xl(this, e, t), this
        }

        setBlockType(e, t = e, r, i = null) {
            return kl(this, e, t, r, i), this
        }

        setNodeMarkup(e, t, r = null, i) {
            return Cl(this, e, t, r, i), this
        }

        setNodeAttribute(e, t, r) {
            return this.step(new nt(e, t, r)), this
        }

        setDocAttribute(e, t) {
            return this.step(new kt(e, t)), this
        }

        addNodeMark(e, t) {
            return this.step(new ke(e, t)), this
        }

        removeNodeMark(e, t) {
            if (!(t instanceof O)) {
                let r = this.doc.nodeAt(e);
                if (!r) throw new RangeError("No node at position " + e);
                if (t = t.isInSet(r.marks), !t) return this
            }
            return this.step(new et(e, t)), this
        }

        split(e, t = 1, r) {
            return wl(this, e, t, r), this
        }

        addMark(e, t, r) {
            return ul(this, e, t, r), this
        }

        removeMark(e, t, r) {
            return pl(this, e, t, r), this
        }

        clearIncompatible(e, t, r) {
            return En(this, e, t, r), this
        }
    }

    const zn = Object.create(null);

    class S {
        constructor(e, t, r) {
            this.$anchor = e, this.$head = t, this.ranges = r || [new yi(e.min(t), e.max(t))]
        }

        get anchor() {
            return this.$anchor.pos
        }

        get head() {
            return this.$head.pos
        }

        get from() {
            return this.$from.pos
        }

        get to() {
            return this.$to.pos
        }

        get $from() {
            return this.ranges[0].$from
        }

        get $to() {
            return this.ranges[0].$to
        }

        get empty() {
            let e = this.ranges;
            for (let t = 0; t < e.length; t++) if (e[t].$from.pos != e[t].$to.pos) return !1;
            return !0
        }

        content() {
            return this.$from.doc.slice(this.from, this.to, !0)
        }

        replace(e, t = x.empty) {
            let r = t.content.lastChild, i = null;
            for (let l = 0; l < t.openEnd; l++) i = r, r = r.lastChild;
            let s = e.steps.length, o = this.ranges;
            for (let l = 0; l < o.length; l++) {
                let {$from: a, $to: c} = o[l], f = e.mapping.slice(s);
                e.replaceRange(f.map(a.pos), f.map(c.pos), l ? x.empty : t), l == 0 && ki(e, s, (r ? r.isInline : i && i.isTextblock) ? -1 : 1)
            }
        }

        replaceWith(e, t) {
            let r = e.steps.length, i = this.ranges;
            for (let s = 0; s < i.length; s++) {
                let {$from: o, $to: l} = i[s], a = e.mapping.slice(r), c = a.map(o.pos), f = a.map(l.pos);
                s ? e.deleteRange(c, f) : (e.replaceRangeWith(c, f, t), ki(e, r, t.isInline ? -1 : 1))
            }
        }

        static findFrom(e, t, r = !1) {
            let i = e.parent.inlineContent ? new C(e) : it(e.node(0), e.parent, e.pos, e.index(), t, r);
            if (i) return i;
            for (let s = e.depth - 1; s >= 0; s--) {
                let o = t < 0 ? it(e.node(0), e.node(s), e.before(s + 1), e.index(s), t, r) : it(e.node(0), e.node(s), e.after(s + 1), e.index(s) + 1, t, r);
                if (o) return o
            }
            return null
        }

        static near(e, t = 1) {
            return this.findFrom(e, t) || this.findFrom(e, -t) || new _(e.node(0))
        }

        static atStart(e) {
            return it(e, e, 0, 0, 1) || new _(e)
        }

        static atEnd(e) {
            return it(e, e, e.content.size, e.childCount, -1) || new _(e)
        }

        static fromJSON(e, t) {
            if (!t || !t.type) throw new RangeError("Invalid input for Selection.fromJSON");
            let r = zn[t.type];
            if (!r) throw new RangeError(`No selection type ${t.type} defined`);
            return r.fromJSON(e, t)
        }

        static jsonID(e, t) {
            if (e in zn) throw new RangeError("Duplicate use of selection JSON ID " + e);
            return zn[e] = t, t.prototype.jsonID = e, t
        }

        getBookmark() {
            return C.between(this.$anchor, this.$head).getBookmark()
        }
    }

    S.prototype.visible = !0;

    class yi {
        constructor(e, t) {
            this.$from = e, this.$to = t
        }
    }

    let bi = !1;

    function xi(n) {
        !bi && !n.parent.inlineContent && (bi = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + n.parent.type.name + ")"))
    }

    class C extends S {
        constructor(e, t = e) {
            xi(e), xi(t), super(e, t)
        }

        get $cursor() {
            return this.$anchor.pos == this.$head.pos ? this.$head : null
        }

        map(e, t) {
            let r = e.resolve(t.map(this.head));
            if (!r.parent.inlineContent) return S.near(r);
            let i = e.resolve(t.map(this.anchor));
            return new C(i.parent.inlineContent ? i : r, r)
        }

        replace(e, t = x.empty) {
            if (super.replace(e, t), t == x.empty) {
                let r = this.$from.marksAcross(this.$to);
                r && e.ensureMarks(r)
            }
        }

        eq(e) {
            return e instanceof C && e.anchor == this.anchor && e.head == this.head
        }

        getBookmark() {
            return new Qt(this.anchor, this.head)
        }

        toJSON() {
            return {type: "text", anchor: this.anchor, head: this.head}
        }

        static fromJSON(e, t) {
            if (typeof t.anchor != "number" || typeof t.head != "number") throw new RangeError("Invalid input for TextSelection.fromJSON");
            return new C(e.resolve(t.anchor), e.resolve(t.head))
        }

        static create(e, t, r = t) {
            let i = e.resolve(t);
            return new this(i, r == t ? i : e.resolve(r))
        }

        static between(e, t, r) {
            let i = e.pos - t.pos;
            if ((!r || i) && (r = i >= 0 ? 1 : -1), !t.parent.inlineContent) {
                let s = S.findFrom(t, r, !0) || S.findFrom(t, -r, !0);
                if (s) t = s.$head; else return S.near(t, r)
            }
            return e.parent.inlineContent || (i == 0 ? e = t : (e = (S.findFrom(e, -r, !0) || S.findFrom(e, r, !0)).$anchor, e.pos < t.pos != i < 0 && (e = t))), new C(e, t)
        }
    }

    S.jsonID("text", C);

    class Qt {
        constructor(e, t) {
            this.anchor = e, this.head = t
        }

        map(e) {
            return new Qt(e.map(this.anchor), e.map(this.head))
        }

        resolve(e) {
            return C.between(e.resolve(this.anchor), e.resolve(this.head))
        }
    }

    class k extends S {
        constructor(e) {
            let t = e.nodeAfter, r = e.node(0).resolve(e.pos + t.nodeSize);
            super(e, r), this.node = t
        }

        map(e, t) {
            let {deleted: r, pos: i} = t.mapResult(this.anchor), s = e.resolve(i);
            return r ? S.near(s) : new k(s)
        }

        content() {
            return new x(y.from(this.node), 0, 0)
        }

        eq(e) {
            return e instanceof k && e.anchor == this.anchor
        }

        toJSON() {
            return {type: "node", anchor: this.anchor}
        }

        getBookmark() {
            return new Bn(this.anchor)
        }

        static fromJSON(e, t) {
            if (typeof t.anchor != "number") throw new RangeError("Invalid input for NodeSelection.fromJSON");
            return new k(e.resolve(t.anchor))
        }

        static create(e, t) {
            return new k(e.resolve(t))
        }

        static isSelectable(e) {
            return !e.isText && e.type.spec.selectable !== !1
        }
    }

    k.prototype.visible = !1, S.jsonID("node", k);

    class Bn {
        constructor(e) {
            this.anchor = e
        }

        map(e) {
            let {deleted: t, pos: r} = e.mapResult(this.anchor);
            return t ? new Qt(r, r) : new Bn(r)
        }

        resolve(e) {
            let t = e.resolve(this.anchor), r = t.nodeAfter;
            return r && k.isSelectable(r) ? new k(t) : S.near(t)
        }
    }

    class _ extends S {
        constructor(e) {
            super(e.resolve(0), e.resolve(e.content.size))
        }

        replace(e, t = x.empty) {
            if (t == x.empty) {
                e.delete(0, e.doc.content.size);
                let r = S.atStart(e.doc);
                r.eq(e.selection) || e.setSelection(r)
            } else super.replace(e, t)
        }

        toJSON() {
            return {type: "all"}
        }

        static fromJSON(e) {
            return new _(e)
        }

        map(e) {
            return new _(e)
        }

        eq(e) {
            return e instanceof _
        }

        getBookmark() {
            return Bl
        }
    }

    S.jsonID("all", _);
    const Bl = {
        map() {
            return this
        }, resolve(n) {
            return new _(n)
        }
    };

    function it(n, e, t, r, i, s = !1) {
        if (e.inlineContent) return C.create(n, t);
        for (let o = r - (i > 0 ? 0 : 1); i > 0 ? o < e.childCount : o >= 0; o += i) {
            let l = e.child(o);
            if (l.isAtom) {
                if (!s && k.isSelectable(l)) return k.create(n, t - (i < 0 ? l.nodeSize : 0))
            } else {
                let a = it(n, l, t + i, i < 0 ? l.childCount : 0, i, s);
                if (a) return a
            }
            t += l.nodeSize * i
        }
        return null
    }

    function ki(n, e, t) {
        let r = n.steps.length - 1;
        if (r < e) return;
        let i = n.steps[r];
        if (!(i instanceof H || i instanceof P)) return;
        let s = n.mapping.maps[r], o;
        s.forEach((l, a, c, f) => {
            o == null && (o = f)
        }), n.setSelection(S.near(n.doc.resolve(o), t))
    }

    const Si = 1, en = 2, Ci = 4;

    class Pl extends gi {
        constructor(e) {
            super(e.doc), this.curSelectionFor = 0, this.updated = 0, this.meta = Object.create(null), this.time = Date.now(), this.curSelection = e.selection, this.storedMarks = e.storedMarks
        }

        get selection() {
            return this.curSelectionFor < this.steps.length && (this.curSelection = this.curSelection.map(this.doc, this.mapping.slice(this.curSelectionFor)), this.curSelectionFor = this.steps.length), this.curSelection
        }

        setSelection(e) {
            if (e.$from.doc != this.doc) throw new RangeError("Selection passed to setSelection must point at the current document");
            return this.curSelection = e, this.curSelectionFor = this.steps.length, this.updated = (this.updated | Si) & ~en, this.storedMarks = null, this
        }

        get selectionSet() {
            return (this.updated & Si) > 0
        }

        setStoredMarks(e) {
            return this.storedMarks = e, this.updated |= en, this
        }

        ensureMarks(e) {
            return O.sameSet(this.storedMarks || this.selection.$from.marks(), e) || this.setStoredMarks(e), this
        }

        addStoredMark(e) {
            return this.ensureMarks(e.addToSet(this.storedMarks || this.selection.$head.marks()))
        }

        removeStoredMark(e) {
            return this.ensureMarks(e.removeFromSet(this.storedMarks || this.selection.$head.marks()))
        }

        get storedMarksSet() {
            return (this.updated & en) > 0
        }

        addStep(e, t) {
            super.addStep(e, t), this.updated = this.updated & ~en, this.storedMarks = null
        }

        setTime(e) {
            return this.time = e, this
        }

        replaceSelection(e) {
            return this.selection.replace(this, e), this
        }

        replaceSelectionWith(e, t = !0) {
            let r = this.selection;
            return t && (e = e.mark(this.storedMarks || (r.empty ? r.$from.marks() : r.$from.marksAcross(r.$to) || O.none))), r.replaceWith(this, e), this
        }

        deleteSelection() {
            return this.selection.replace(this), this
        }

        insertText(e, t, r) {
            let i = this.doc.type.schema;
            if (t == null) return e ? this.replaceSelectionWith(i.text(e), !0) : this.deleteSelection();
            {
                if (r == null && (r = t), r = r ?? t, !e) return this.deleteRange(t, r);
                let s = this.storedMarks;
                if (!s) {
                    let o = this.doc.resolve(t);
                    s = r == t ? o.marks() : o.marksAcross(this.doc.resolve(r))
                }
                return this.replaceRangeWith(t, r, i.text(e, s)), this.selection.empty || this.setSelection(S.near(this.selection.$to)), this
            }
        }

        setMeta(e, t) {
            return this.meta[typeof e == "string" ? e : e.key] = t, this
        }

        getMeta(e) {
            return this.meta[typeof e == "string" ? e : e.key]
        }

        get isGeneric() {
            for (let e in this.meta) return !1;
            return !0
        }

        scrollIntoView() {
            return this.updated |= Ci, this
        }

        get scrolledIntoView() {
            return (this.updated & Ci) > 0
        }
    }

    function wi(n, e) {
        return !e || !n ? n : n.bind(e)
    }

    class St {
        constructor(e, t, r) {
            this.name = e, this.init = wi(t.init, r), this.apply = wi(t.apply, r)
        }
    }

    const Vl = [new St("doc", {
        init(n) {
            return n.doc || n.schema.topNodeType.createAndFill()
        }, apply(n) {
            return n.doc
        }
    }), new St("selection", {
        init(n, e) {
            return n.selection || S.atStart(e.doc)
        }, apply(n) {
            return n.selection
        }
    }), new St("storedMarks", {
        init(n) {
            return n.storedMarks || null
        }, apply(n, e, t, r) {
            return r.selection.$cursor ? n.storedMarks : null
        }
    }), new St("scrollToSelection", {
        init() {
            return 0
        }, apply(n, e) {
            return n.scrolledIntoView ? e + 1 : e
        }
    })];

    class Pn {
        constructor(e, t) {
            this.schema = e, this.plugins = [], this.pluginsByKey = Object.create(null), this.fields = Vl.slice(), t && t.forEach(r => {
                if (this.pluginsByKey[r.key]) throw new RangeError("Adding different instances of a keyed plugin (" + r.key + ")");
                this.plugins.push(r), this.pluginsByKey[r.key] = r, r.spec.state && this.fields.push(new St(r.key, r.spec.state, r))
            })
        }
    }

    class st {
        constructor(e) {
            this.config = e
        }

        get schema() {
            return this.config.schema
        }

        get plugins() {
            return this.config.plugins
        }

        apply(e) {
            return this.applyTransaction(e).state
        }

        filterTransaction(e, t = -1) {
            for (let r = 0; r < this.config.plugins.length; r++) if (r != t) {
                let i = this.config.plugins[r];
                if (i.spec.filterTransaction && !i.spec.filterTransaction.call(i, e, this)) return !1
            }
            return !0
        }

        applyTransaction(e) {
            if (!this.filterTransaction(e)) return {state: this, transactions: []};
            let t = [e], r = this.applyInner(e), i = null;
            for (; ;) {
                let s = !1;
                for (let o = 0; o < this.config.plugins.length; o++) {
                    let l = this.config.plugins[o];
                    if (l.spec.appendTransaction) {
                        let a = i ? i[o].n : 0, c = i ? i[o].state : this,
                            f = a < t.length && l.spec.appendTransaction.call(l, a ? t.slice(a) : t, c, r);
                        if (f && r.filterTransaction(f, o)) {
                            if (f.setMeta("appendedTransaction", e), !i) {
                                i = [];
                                for (let h = 0; h < this.config.plugins.length; h++) i.push(h < o ? {
                                    state: r,
                                    n: t.length
                                } : {state: this, n: 0})
                            }
                            t.push(f), r = r.applyInner(f), s = !0
                        }
                        i && (i[o] = {state: r, n: t.length})
                    }
                }
                if (!s) return {state: r, transactions: t}
            }
        }

        applyInner(e) {
            if (!e.before.eq(this.doc)) throw new RangeError("Applying a mismatched transaction");
            let t = new st(this.config), r = this.config.fields;
            for (let i = 0; i < r.length; i++) {
                let s = r[i];
                t[s.name] = s.apply(e, this[s.name], this, t)
            }
            return t
        }

        get tr() {
            return new Pl(this)
        }

        static create(e) {
            let t = new Pn(e.doc ? e.doc.type.schema : e.schema, e.plugins), r = new st(t);
            for (let i = 0; i < t.fields.length; i++) r[t.fields[i].name] = t.fields[i].init(e, r);
            return r
        }

        reconfigure(e) {
            let t = new Pn(this.schema, e.plugins), r = t.fields, i = new st(t);
            for (let s = 0; s < r.length; s++) {
                let o = r[s].name;
                i[o] = this.hasOwnProperty(o) ? this[o] : r[s].init(e, i)
            }
            return i
        }

        toJSON(e) {
            let t = {doc: this.doc.toJSON(), selection: this.selection.toJSON()};
            if (this.storedMarks && (t.storedMarks = this.storedMarks.map(r => r.toJSON())), e && typeof e == "object") for (let r in e) {
                if (r == "doc" || r == "selection") throw new RangeError("The JSON fields `doc` and `selection` are reserved");
                let i = e[r], s = i.spec.state;
                s && s.toJSON && (t[r] = s.toJSON.call(i, this[i.key]))
            }
            return t
        }

        static fromJSON(e, t, r) {
            if (!t) throw new RangeError("Invalid input for EditorState.fromJSON");
            if (!e.schema) throw new RangeError("Required config field 'schema' missing");
            let i = new Pn(e.schema, e.plugins), s = new st(i);
            return i.fields.forEach(o => {
                if (o.name == "doc") s.doc = Fe.fromJSON(e.schema, t.doc); else if (o.name == "selection") s.selection = S.fromJSON(s.doc, t.selection); else if (o.name == "storedMarks") t.storedMarks && (s.storedMarks = t.storedMarks.map(e.schema.markFromJSON)); else {
                    if (r) for (let l in r) {
                        let a = r[l], c = a.spec.state;
                        if (a.key == o.name && c && c.fromJSON && Object.prototype.hasOwnProperty.call(t, l)) {
                            s[o.name] = c.fromJSON.call(a, e, t[l], s);
                            return
                        }
                    }
                    s[o.name] = o.init(e, s)
                }
            }), s
        }
    }

    function Mi(n, e, t) {
        for (let r in n) {
            let i = n[r];
            i instanceof Function ? i = i.bind(e) : r == "handleDOMEvents" && (i = Mi(i, e, {})), t[r] = i
        }
        return t
    }

    class ot {
        constructor(e) {
            this.spec = e, this.props = {}, e.props && Mi(e.props, this, this.props), this.key = e.key ? e.key.key : Oi("plugin")
        }

        getState(e) {
            return e[this.key]
        }
    }

    const Vn = Object.create(null);

    function Oi(n) {
        return n in Vn ? n + "$" + ++Vn[n] : (Vn[n] = 0, n + "$")
    }

    class Ct {
        constructor(e = "key") {
            this.key = Oi(e)
        }

        get(e) {
            return e.config.pluginsByKey[this.key]
        }

        getState(e) {
            return e[this.key]
        }
    }

    const Ni = (n, e) => n.selection.empty ? !1 : (e && e(n.tr.deleteSelection().scrollIntoView()), !0);

    function Fl(n, e) {
        let {$cursor: t} = n.selection;
        return !t || (e ? !e.endOfTextblock("backward", n) : t.parentOffset > 0) ? null : t
    }

    const Ll = (n, e, t) => {
        let r = Fl(n, t);
        if (!r) return !1;
        let i = Ti(r);
        if (!i) {
            let o = r.blockRange(), l = o && Yt(o);
            return l == null ? !1 : (e && e(n.tr.lift(o, l).scrollIntoView()), !0)
        }
        let s = i.nodeBefore;
        if (vi(n, i, e, -1)) return !0;
        if (r.parent.content.size == 0 && (lt(s, "end") || k.isSelectable(s))) for (let o = r.depth; ; o--) {
            let l = Rn(n.doc, r.before(o), r.after(o), x.empty);
            if (l && l.slice.size < l.to - l.from) {
                if (e) {
                    let a = n.tr.step(l);
                    a.setSelection(lt(s, "end") ? S.findFrom(a.doc.resolve(a.mapping.map(i.pos, -1)), -1) : k.create(a.doc, i.pos - s.nodeSize)), e(a.scrollIntoView())
                }
                return !0
            }
            if (o == 1 || r.node(o - 1).childCount > 1) break
        }
        return s.isAtom && i.depth == r.depth - 1 ? (e && e(n.tr.delete(i.pos - s.nodeSize, i.pos).scrollIntoView()), !0) : !1
    };

    function lt(n, e, t = !1) {
        for (let r = n; r; r = e == "start" ? r.firstChild : r.lastChild) {
            if (r.isTextblock) return !0;
            if (t && r.childCount != 1) return !1
        }
        return !1
    }

    const Hl = (n, e, t) => {
        let {$head: r, empty: i} = n.selection, s = r;
        if (!i) return !1;
        if (r.parent.isTextblock) {
            if (t ? !t.endOfTextblock("backward", n) : r.parentOffset > 0) return !1;
            s = Ti(r)
        }
        let o = s && s.nodeBefore;
        return !o || !k.isSelectable(o) ? !1 : (e && e(n.tr.setSelection(k.create(n.doc, s.pos - o.nodeSize)).scrollIntoView()), !0)
    };

    function Ti(n) {
        if (!n.parent.type.spec.isolating) for (let e = n.depth - 1; e >= 0; e--) {
            if (n.index(e) > 0) return n.doc.resolve(n.before(e + 1));
            if (n.node(e).type.spec.isolating) break
        }
        return null
    }

    function $l(n, e) {
        let {$cursor: t} = n.selection;
        return !t || (e ? !e.endOfTextblock("forward", n) : t.parentOffset < t.parent.content.size) ? null : t
    }

    const Wl = (n, e, t) => {
        let r = $l(n, t);
        if (!r) return !1;
        let i = Ai(r);
        if (!i) return !1;
        let s = i.nodeAfter;
        if (vi(n, i, e, 1)) return !0;
        if (r.parent.content.size == 0 && (lt(s, "start") || k.isSelectable(s))) {
            let o = Rn(n.doc, r.before(), r.after(), x.empty);
            if (o && o.slice.size < o.to - o.from) {
                if (e) {
                    let l = n.tr.step(o);
                    l.setSelection(lt(s, "start") ? S.findFrom(l.doc.resolve(l.mapping.map(i.pos)), 1) : k.create(l.doc, l.mapping.map(i.pos))), e(l.scrollIntoView())
                }
                return !0
            }
        }
        return s.isAtom && i.depth == r.depth - 1 ? (e && e(n.tr.delete(i.pos, i.pos + s.nodeSize).scrollIntoView()), !0) : !1
    }, Jl = (n, e, t) => {
        let {$head: r, empty: i} = n.selection, s = r;
        if (!i) return !1;
        if (r.parent.isTextblock) {
            if (t ? !t.endOfTextblock("forward", n) : r.parentOffset < r.parent.content.size) return !1;
            s = Ai(r)
        }
        let o = s && s.nodeAfter;
        return !o || !k.isSelectable(o) ? !1 : (e && e(n.tr.setSelection(k.create(n.doc, s.pos)).scrollIntoView()), !0)
    };

    function Ai(n) {
        if (!n.parent.type.spec.isolating) for (let e = n.depth - 1; e >= 0; e--) {
            let t = n.node(e);
            if (n.index(e) + 1 < t.childCount) return n.doc.resolve(n.after(e + 1));
            if (t.type.spec.isolating) break
        }
        return null
    }

    const ql = (n, e) => {
        let {$head: t, $anchor: r} = n.selection;
        return !t.parent.type.spec.code || !t.sameParent(r) ? !1 : (e && e(n.tr.insertText(`
`).scrollIntoView()), !0)
    };

    function Fn(n) {
        for (let e = 0; e < n.edgeCount; e++) {
            let {type: t} = n.edge(e);
            if (t.isTextblock && !t.hasRequiredAttrs()) return t
        }
        return null
    }

    const Di = (n, e) => {
        let {$head: t, $anchor: r} = n.selection;
        if (!t.parent.type.spec.code || !t.sameParent(r)) return !1;
        let i = t.node(-1), s = t.indexAfter(-1), o = Fn(i.contentMatchAt(s));
        if (!o || !i.canReplaceWith(s, s, o)) return !1;
        if (e) {
            let l = t.after(), a = n.tr.replaceWith(l, l, o.createAndFill());
            a.setSelection(S.near(a.doc.resolve(l), 1)), e(a.scrollIntoView())
        }
        return !0
    }, Kl = (n, e) => {
        let t = n.selection, {$from: r, $to: i} = t;
        if (t instanceof _ || r.parent.inlineContent || i.parent.inlineContent) return !1;
        let s = Fn(i.parent.contentMatchAt(i.indexAfter()));
        if (!s || !s.isTextblock) return !1;
        if (e) {
            let o = (!r.parentOffset && i.index() < i.parent.childCount ? r : i).pos,
                l = n.tr.insert(o, s.createAndFill());
            l.setSelection(C.create(l.doc, o + 1)), e(l.scrollIntoView())
        }
        return !0
    }, Ei = (n, e) => {
        let {$cursor: t} = n.selection;
        if (!t || t.parent.content.size) return !1;
        if (t.depth > 1 && t.after() != t.end(-1)) {
            let s = t.before();
            if (tt(n.doc, s)) return e && e(n.tr.split(s).scrollIntoView()), !0
        }
        let r = t.blockRange(), i = r && Yt(r);
        return i == null ? !1 : (e && e(n.tr.lift(r, i).scrollIntoView()), !0)
    };

    function Ri(n) {
        return (e, t) => {
            let {$from: r, $to: i} = e.selection;
            if (e.selection instanceof k && e.selection.node.isBlock) return !r.parentOffset || !tt(e.doc, r.pos) ? !1 : (t && t(e.tr.split(r.pos).scrollIntoView()), !0);
            if (!r.depth) return !1;
            let s = [], o, l, a = !1, c = !1;
            for (let u = r.depth; ; u--) if (r.node(u).isBlock) {
                a = r.end(u) == r.pos + (r.depth - u), c = r.start(u) == r.pos - (r.depth - u), l = Fn(r.node(u - 1).contentMatchAt(r.indexAfter(u - 1)));
                let m = n && n(i.parent, a, r);
                s.unshift(m || (a && l ? {type: l} : null)), o = u;
                break
            } else {
                if (u == 1) return !1;
                s.unshift(null)
            }
            let f = e.tr;
            (e.selection instanceof C || e.selection instanceof _) && f.deleteSelection();
            let h = f.mapping.map(r.pos), d = tt(f.doc, h, s.length, s);
            if (d || (s[0] = l ? {type: l} : null, d = tt(f.doc, h, s.length, s)), f.split(h, s.length, s), !a && c && r.node(o).type != l) {
                let u = f.mapping.map(r.before(o)), p = f.doc.resolve(u);
                l && r.node(o - 1).canReplaceWith(p.index(), p.index() + 1, l) && f.setNodeMarkup(f.mapping.map(r.before(o)), l)
            }
            return t && t(f.scrollIntoView()), !0
        }
    }

    const jl = Ri(), Ii = (n, e) => (e && e(n.tr.setSelection(new _(n.doc))), !0);

    function Ul(n, e, t) {
        let r = e.nodeBefore, i = e.nodeAfter, s = e.index();
        return !r || !i || !r.type.compatibleContent(i.type) ? !1 : !r.content.size && e.parent.canReplace(s - 1, s) ? (t && t(n.tr.delete(e.pos - r.nodeSize, e.pos).scrollIntoView()), !0) : !e.parent.canReplace(s, s + 1) || !(i.isTextblock || Zt(n.doc, e.pos)) ? !1 : (t && t(n.tr.join(e.pos).scrollIntoView()), !0)
    }

    function vi(n, e, t, r) {
        let i = e.nodeBefore, s = e.nodeAfter, o, l, a = i.type.spec.isolating || s.type.spec.isolating;
        if (!a && Ul(n, e, t)) return !0;
        let c = !a && e.parent.canReplace(e.index(), e.index() + 1);
        if (c && (o = (l = i.contentMatchAt(i.childCount)).findWrapping(s.type)) && l.matchType(o[0] || s.type).validEnd) {
            if (t) {
                let u = e.pos + s.nodeSize, p = y.empty;
                for (let b = o.length - 1; b >= 0; b--) p = y.from(o[b].create(null, p));
                p = y.from(i.copy(p));
                let m = n.tr.step(new P(e.pos - 1, u, e.pos, u, new x(p, 1, 0), o.length, !0)),
                    g = m.doc.resolve(u + 2 * o.length);
                g.nodeAfter && g.nodeAfter.type == i.type && Zt(m.doc, g.pos) && m.join(g.pos), t(m.scrollIntoView())
            }
            return !0
        }
        let f = s.type.spec.isolating || r > 0 && a ? null : S.findFrom(e, 1), h = f && f.$from.blockRange(f.$to),
            d = h && Yt(h);
        if (d != null && d >= e.depth) return t && t(n.tr.lift(h, d).scrollIntoView()), !0;
        if (c && lt(s, "start", !0) && lt(i, "end")) {
            let u = i, p = [];
            for (; p.push(u), !u.isTextblock;) u = u.lastChild;
            let m = s, g = 1;
            for (; !m.isTextblock; m = m.firstChild) g++;
            if (u.canReplace(u.childCount, u.childCount, m.content)) {
                if (t) {
                    let b = y.empty;
                    for (let N = p.length - 1; N >= 0; N--) b = y.from(p[N].copy(b));
                    let w = n.tr.step(new P(e.pos - p.length, e.pos + s.nodeSize, e.pos + g, e.pos + s.nodeSize - g, new x(b, p.length, 0), 0, !0));
                    t(w.scrollIntoView())
                }
                return !0
            }
        }
        return !1
    }

    function zi(n) {
        return function (e, t) {
            let r = e.selection, i = n < 0 ? r.$from : r.$to, s = i.depth;
            for (; i.node(s).isInline;) {
                if (!s) return !1;
                s--
            }
            return i.node(s).isTextblock ? (t && t(e.tr.setSelection(C.create(e.doc, n < 0 ? i.start(s) : i.end(s)))), !0) : !1
        }
    }

    const Gl = zi(-1), _l = zi(1);

    function Xl(n, e = null) {
        return function (t, r) {
            let i = !1;
            for (let s = 0; s < t.selection.ranges.length && !i; s++) {
                let {$from: {pos: o}, $to: {pos: l}} = t.selection.ranges[s];
                t.doc.nodesBetween(o, l, (a, c) => {
                    if (i) return !1;
                    if (!(!a.isTextblock || a.hasMarkup(n, e))) if (a.type == n) i = !0; else {
                        let f = t.doc.resolve(c), h = f.index();
                        i = f.parent.canReplaceWith(h, h + 1, n)
                    }
                })
            }
            if (!i) return !1;
            if (r) {
                let s = t.tr;
                for (let o = 0; o < t.selection.ranges.length; o++) {
                    let {$from: {pos: l}, $to: {pos: a}} = t.selection.ranges[o];
                    s.setBlockType(l, a, n, e)
                }
                r(s.scrollIntoView())
            }
            return !0
        }
    }

    function Yl(n, e, t, r) {
        for (let i = 0; i < e.length; i++) {
            let {$from: s, $to: o} = e[i], l = s.depth == 0 ? n.inlineContent && n.type.allowsMarkType(t) : !1;
            if (n.nodesBetween(s.pos, o.pos, (a, c) => {
                if (l || !r) return !1;
                l = a.inlineContent && a.type.allowsMarkType(t)
            }), l) return !0
        }
        return !1
    }

    function $e(n, e = null, t) {
        let r = t !== !1;
        return function (i, s) {
            let {empty: o, $cursor: l, ranges: a} = i.selection;
            if (o && !l || !Yl(i.doc, a, n, r)) return !1;
            if (s) if (l) n.isInSet(i.storedMarks || l.marks()) ? s(i.tr.removeStoredMark(n)) : s(i.tr.addStoredMark(n.create(e))); else {
                let c, f = i.tr;
                c = !a.some(h => i.doc.rangeHasMark(h.$from.pos, h.$to.pos, n));
                for (let h = 0; h < a.length; h++) {
                    let {$from: d, $to: u} = a[h];
                    if (!c) f.removeMark(d.pos, u.pos, n); else {
                        let p = d.pos, m = u.pos, g = d.nodeAfter, b = u.nodeBefore,
                            w = g && g.isText ? /^\s*/.exec(g.text)[0].length : 0,
                            N = b && b.isText ? /\s*$/.exec(b.text)[0].length : 0;
                        p + w < m && (p += w, m -= N), f.addMark(p, m, n.create(e))
                    }
                }
                s(f.scrollIntoView())
            }
            return !0
        }
    }

    function wt(...n) {
        return function (e, t, r) {
            for (let i = 0; i < n.length; i++) if (n[i](e, t, r)) return !0;
            return !1
        }
    }

    let Ln = wt(Ni, Ll, Hl), Bi = wt(Ni, Wl, Jl);
    const fe = {
        Enter: wt(ql, Kl, Ei, jl),
        "Mod-Enter": Di,
        Backspace: Ln,
        "Mod-Backspace": Ln,
        "Shift-Backspace": Ln,
        Delete: Bi,
        "Mod-Delete": Bi,
        "Mod-a": Ii
    }, Pi = {
        "Ctrl-h": fe.Backspace,
        "Alt-Backspace": fe["Mod-Backspace"],
        "Ctrl-d": fe.Delete,
        "Ctrl-Alt-Backspace": fe["Mod-Delete"],
        "Alt-Delete": fe["Mod-Delete"],
        "Alt-d": fe["Mod-Delete"],
        "Ctrl-a": Gl,
        "Ctrl-e": _l
    };
    for (let n in fe) Pi[n] = fe[n];
    const Zl = (typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : typeof os < "u" && os.platform ? os.platform() == "darwin" : !1) ? Pi : fe;
    var tn = 200, I = function () {
    };
    I.prototype.append = function (e) {
        return e.length ? (e = I.from(e), !this.length && e || e.length < tn && this.leafAppend(e) || this.length < tn && e.leafPrepend(this) || this.appendInner(e)) : this
    }, I.prototype.prepend = function (e) {
        return e.length ? I.from(e).append(this) : this
    }, I.prototype.appendInner = function (e) {
        return new Ql(this, e)
    }, I.prototype.slice = function (e, t) {
        return e === void 0 && (e = 0), t === void 0 && (t = this.length), e >= t ? I.empty : this.sliceInner(Math.max(0, e), Math.min(this.length, t))
    }, I.prototype.get = function (e) {
        if (!(e < 0 || e >= this.length)) return this.getInner(e)
    }, I.prototype.forEach = function (e, t, r) {
        t === void 0 && (t = 0), r === void 0 && (r = this.length), t <= r ? this.forEachInner(e, t, r, 0) : this.forEachInvertedInner(e, t, r, 0)
    }, I.prototype.map = function (e, t, r) {
        t === void 0 && (t = 0), r === void 0 && (r = this.length);
        var i = [];
        return this.forEach(function (s, o) {
            return i.push(e(s, o))
        }, t, r), i
    }, I.from = function (e) {
        return e instanceof I ? e : e && e.length ? new Vi(e) : I.empty
    };
    var Vi = function (n) {
        function e(r) {
            n.call(this), this.values = r
        }

        n && (e.__proto__ = n), e.prototype = Object.create(n && n.prototype), e.prototype.constructor = e;
        var t = {length: {configurable: !0}, depth: {configurable: !0}};
        return e.prototype.flatten = function () {
            return this.values
        }, e.prototype.sliceInner = function (i, s) {
            return i == 0 && s == this.length ? this : new e(this.values.slice(i, s))
        }, e.prototype.getInner = function (i) {
            return this.values[i]
        }, e.prototype.forEachInner = function (i, s, o, l) {
            for (var a = s; a < o; a++) if (i(this.values[a], l + a) === !1) return !1
        }, e.prototype.forEachInvertedInner = function (i, s, o, l) {
            for (var a = s - 1; a >= o; a--) if (i(this.values[a], l + a) === !1) return !1
        }, e.prototype.leafAppend = function (i) {
            if (this.length + i.length <= tn) return new e(this.values.concat(i.flatten()))
        }, e.prototype.leafPrepend = function (i) {
            if (this.length + i.length <= tn) return new e(i.flatten().concat(this.values))
        }, t.length.get = function () {
            return this.values.length
        }, t.depth.get = function () {
            return 0
        }, Object.defineProperties(e.prototype, t), e
    }(I);
    I.empty = new Vi([]);
    var Ql = function (n) {
        function e(t, r) {
            n.call(this), this.left = t, this.right = r, this.length = t.length + r.length, this.depth = Math.max(t.depth, r.depth) + 1
        }

        return n && (e.__proto__ = n), e.prototype = Object.create(n && n.prototype), e.prototype.constructor = e, e.prototype.flatten = function () {
            return this.left.flatten().concat(this.right.flatten())
        }, e.prototype.getInner = function (r) {
            return r < this.left.length ? this.left.get(r) : this.right.get(r - this.left.length)
        }, e.prototype.forEachInner = function (r, i, s, o) {
            var l = this.left.length;
            if (i < l && this.left.forEachInner(r, i, Math.min(s, l), o) === !1 || s > l && this.right.forEachInner(r, Math.max(i - l, 0), Math.min(this.length, s) - l, o + l) === !1) return !1
        }, e.prototype.forEachInvertedInner = function (r, i, s, o) {
            var l = this.left.length;
            if (i > l && this.right.forEachInvertedInner(r, i - l, Math.max(s, l) - l, o + l) === !1 || s < l && this.left.forEachInvertedInner(r, Math.min(i, l), s, o) === !1) return !1
        }, e.prototype.sliceInner = function (r, i) {
            if (r == 0 && i == this.length) return this;
            var s = this.left.length;
            return i <= s ? this.left.slice(r, i) : r >= s ? this.right.slice(r - s, i - s) : this.left.slice(r, s).append(this.right.slice(0, i - s))
        }, e.prototype.leafAppend = function (r) {
            var i = this.right.leafAppend(r);
            if (i) return new e(this.left, i)
        }, e.prototype.leafPrepend = function (r) {
            var i = this.left.leafPrepend(r);
            if (i) return new e(i, this.right)
        }, e.prototype.appendInner = function (r) {
            return this.left.depth >= Math.max(this.right.depth, r.depth) + 1 ? new e(this.left, new e(this.right, r)) : new e(this, r)
        }, e
    }(I);
    const ea = 500;

    class te {
        constructor(e, t) {
            this.items = e, this.eventCount = t
        }

        popEvent(e, t) {
            if (this.eventCount == 0) return null;
            let r = this.items.length;
            for (; ; r--) if (this.items.get(r - 1).selection) {
                --r;
                break
            }
            let i, s;
            t && (i = this.remapping(r, this.items.length), s = i.maps.length);
            let o = e.tr, l, a, c = [], f = [];
            return this.items.forEach((h, d) => {
                if (!h.step) {
                    i || (i = this.remapping(r, d + 1), s = i.maps.length), s--, f.push(h);
                    return
                }
                if (i) {
                    f.push(new oe(h.map));
                    let u = h.step.map(i.slice(s)), p;
                    u && o.maybeStep(u).doc && (p = o.mapping.maps[o.mapping.maps.length - 1], c.push(new oe(p, void 0, void 0, c.length + f.length))), s--, p && i.appendMap(p, s)
                } else o.maybeStep(h.step);
                if (h.selection) return l = i ? h.selection.map(i.slice(s)) : h.selection, a = new te(this.items.slice(0, r).append(f.reverse().concat(c)), this.eventCount - 1), !1
            }, this.items.length, 0), {remaining: a, transform: o, selection: l}
        }

        addTransform(e, t, r, i) {
            let s = [], o = this.eventCount, l = this.items, a = !i && l.length ? l.get(l.length - 1) : null;
            for (let f = 0; f < e.steps.length; f++) {
                let h = e.steps[f].invert(e.docs[f]), d = new oe(e.mapping.maps[f], h, t), u;
                (u = a && a.merge(d)) && (d = u, f ? s.pop() : l = l.slice(0, l.length - 1)), s.push(d), t && (o++, t = void 0), i || (a = d)
            }
            let c = o - r.depth;
            return c > na && (l = ta(l, c), o -= c), new te(l.append(s), o)
        }

        remapping(e, t) {
            let r = new Qe;
            return this.items.forEach((i, s) => {
                let o = i.mirrorOffset != null && s - i.mirrorOffset >= e ? r.maps.length - i.mirrorOffset : void 0;
                r.appendMap(i.map, o)
            }, e, t), r
        }

        addMaps(e) {
            return this.eventCount == 0 ? this : new te(this.items.append(e.map(t => new oe(t))), this.eventCount)
        }

        rebased(e, t) {
            if (!this.eventCount) return this;
            let r = [], i = Math.max(0, this.items.length - t), s = e.mapping, o = e.steps.length, l = this.eventCount;
            this.items.forEach(d => {
                d.selection && l--
            }, i);
            let a = t;
            this.items.forEach(d => {
                let u = s.getMirror(--a);
                if (u == null) return;
                o = Math.min(o, u);
                let p = s.maps[u];
                if (d.step) {
                    let m = e.steps[u].invert(e.docs[u]), g = d.selection && d.selection.map(s.slice(a + 1, u));
                    g && l++, r.push(new oe(p, m, g))
                } else r.push(new oe(p))
            }, i);
            let c = [];
            for (let d = t; d < o; d++) c.push(new oe(s.maps[d]));
            let f = this.items.slice(0, i).append(c).append(r), h = new te(f, l);
            return h.emptyItemCount() > ea && (h = h.compress(this.items.length - r.length)), h
        }

        emptyItemCount() {
            let e = 0;
            return this.items.forEach(t => {
                t.step || e++
            }), e
        }

        compress(e = this.items.length) {
            let t = this.remapping(0, e), r = t.maps.length, i = [], s = 0;
            return this.items.forEach((o, l) => {
                if (l >= e) i.push(o), o.selection && s++; else if (o.step) {
                    let a = o.step.map(t.slice(r)), c = a && a.getMap();
                    if (r--, c && t.appendMap(c, r), a) {
                        let f = o.selection && o.selection.map(t.slice(r));
                        f && s++;
                        let h = new oe(c.invert(), a, f), d, u = i.length - 1;
                        (d = i.length && i[u].merge(h)) ? i[u] = d : i.push(h)
                    }
                } else o.map && r--
            }, this.items.length, 0), new te(I.from(i.reverse()), s)
        }
    }

    te.empty = new te(I.empty, 0);

    function ta(n, e) {
        let t;
        return n.forEach((r, i) => {
            if (r.selection && e-- == 0) return t = i, !1
        }), n.slice(t)
    }

    class oe {
        constructor(e, t, r, i) {
            this.map = e, this.step = t, this.selection = r, this.mirrorOffset = i
        }

        merge(e) {
            if (this.step && e.step && !e.selection) {
                let t = e.step.merge(this.step);
                if (t) return new oe(t.getMap().invert(), t, this.selection)
            }
        }
    }

    class Se {
        constructor(e, t, r, i, s) {
            this.done = e, this.undone = t, this.prevRanges = r, this.prevTime = i, this.prevComposition = s
        }
    }

    const na = 20;

    function ra(n, e, t, r) {
        let i = t.getMeta(We), s;
        if (i) return i.historyState;
        t.getMeta(oa) && (n = new Se(n.done, n.undone, null, 0, -1));
        let o = t.getMeta("appendedTransaction");
        if (t.steps.length == 0) return n;
        if (o && o.getMeta(We)) return o.getMeta(We).redo ? new Se(n.done.addTransform(t, void 0, r, nn(e)), n.undone, Fi(t.mapping.maps), n.prevTime, n.prevComposition) : new Se(n.done, n.undone.addTransform(t, void 0, r, nn(e)), null, n.prevTime, n.prevComposition);
        if (t.getMeta("addToHistory") !== !1 && !(o && o.getMeta("addToHistory") === !1)) {
            let l = t.getMeta("composition"),
                a = n.prevTime == 0 || !o && n.prevComposition != l && (n.prevTime < (t.time || 0) - r.newGroupDelay || !ia(t, n.prevRanges)),
                c = o ? Hn(n.prevRanges, t.mapping) : Fi(t.mapping.maps);
            return new Se(n.done.addTransform(t, a ? e.selection.getBookmark() : void 0, r, nn(e)), te.empty, c, t.time, l ?? n.prevComposition)
        } else return (s = t.getMeta("rebased")) ? new Se(n.done.rebased(t, s), n.undone.rebased(t, s), Hn(n.prevRanges, t.mapping), n.prevTime, n.prevComposition) : new Se(n.done.addMaps(t.mapping.maps), n.undone.addMaps(t.mapping.maps), Hn(n.prevRanges, t.mapping), n.prevTime, n.prevComposition)
    }

    function ia(n, e) {
        if (!e) return !1;
        if (!n.docChanged) return !0;
        let t = !1;
        return n.mapping.maps[0].forEach((r, i) => {
            for (let s = 0; s < e.length; s += 2) r <= e[s + 1] && i >= e[s] && (t = !0)
        }), t
    }

    function Fi(n) {
        let e = [];
        for (let t = n.length - 1; t >= 0 && e.length == 0; t--) n[t].forEach((r, i, s, o) => e.push(s, o));
        return e
    }

    function Hn(n, e) {
        if (!n) return null;
        let t = [];
        for (let r = 0; r < n.length; r += 2) {
            let i = e.map(n[r], 1), s = e.map(n[r + 1], -1);
            i <= s && t.push(i, s)
        }
        return t
    }

    function sa(n, e, t) {
        let r = nn(e), i = We.get(e).spec.config, s = (t ? n.undone : n.done).popEvent(e, r);
        if (!s) return null;
        let o = s.selection.resolve(s.transform.doc),
            l = (t ? n.done : n.undone).addTransform(s.transform, e.selection.getBookmark(), i, r),
            a = new Se(t ? l : s.remaining, t ? s.remaining : l, null, 0, -1);
        return s.transform.setSelection(o).setMeta(We, {redo: t, historyState: a})
    }

    let $n = !1, Li = null;

    function nn(n) {
        let e = n.plugins;
        if (Li != e) {
            $n = !1, Li = e;
            for (let t = 0; t < e.length; t++) if (e[t].spec.historyPreserveItems) {
                $n = !0;
                break
            }
        }
        return $n
    }

    const We = new Ct("history"), oa = new Ct("closeHistory");

    function la(n = {}) {
        return n = {depth: n.depth || 100, newGroupDelay: n.newGroupDelay || 500}, new ot({
            key: We, state: {
                init() {
                    return new Se(te.empty, te.empty, null, 0, -1)
                }, apply(e, t, r) {
                    return ra(t, r, e, n)
                }
            }, config: n, props: {
                handleDOMEvents: {
                    beforeinput(e, t) {
                        let r = t.inputType, i = r == "historyUndo" ? $i : r == "historyRedo" ? Wn : null;
                        return i ? (t.preventDefault(), i(e.state, e.dispatch)) : !1
                    }
                }
            }
        })
    }

    function Hi(n, e) {
        return (t, r) => {
            let i = We.getState(t);
            if (!i || (n ? i.undone : i.done).eventCount == 0) return !1;
            if (r) {
                let s = sa(i, t, n);
                s && r(e ? s.scrollIntoView() : s)
            }
            return !0
        }
    }

    const $i = Hi(!1, !0), Wn = Hi(!0, !0);
    for (var Ce = {
        8: "Backspace",
        9: "Tab",
        10: "Enter",
        12: "NumLock",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        44: "PrintScreen",
        45: "Insert",
        46: "Delete",
        59: ";",
        61: "=",
        91: "Meta",
        92: "Meta",
        106: "*",
        107: "+",
        108: ",",
        109: "-",
        110: ".",
        111: "/",
        144: "NumLock",
        145: "ScrollLock",
        160: "Shift",
        161: "Shift",
        162: "Control",
        163: "Control",
        164: "Alt",
        165: "Alt",
        173: "-",
        186: ";",
        187: "=",
        188: ",",
        189: "-",
        190: ".",
        191: "/",
        192: "`",
        219: "[",
        220: "\\",
        221: "]",
        222: "'"
    }, rn = {
        48: ")",
        49: "!",
        50: "@",
        51: "#",
        52: "$",
        53: "%",
        54: "^",
        55: "&",
        56: "*",
        57: "(",
        59: ":",
        61: "+",
        173: "_",
        186: ":",
        187: "+",
        188: "<",
        189: "_",
        190: ">",
        191: "?",
        192: "~",
        219: "{",
        220: "|",
        221: "}",
        222: '"'
    }, aa = typeof navigator < "u" && /Mac/.test(navigator.platform), ca = typeof navigator < "u" && /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent), V = 0; V < 10; V++) Ce[48 + V] = Ce[96 + V] = String(V);
    for (var V = 1; V <= 24; V++) Ce[V + 111] = "F" + V;
    for (var V = 65; V <= 90; V++) Ce[V] = String.fromCharCode(V + 32), rn[V] = String.fromCharCode(V);
    for (var Jn in Ce) rn.hasOwnProperty(Jn) || (rn[Jn] = Ce[Jn]);

    function fa(n) {
        var e = aa && n.metaKey && n.shiftKey && !n.ctrlKey && !n.altKey || ca && n.shiftKey && n.key && n.key.length == 1 || n.key == "Unidentified",
            t = !e && n.key || (n.shiftKey ? rn : Ce)[n.keyCode] || n.key || "Unidentified";
        return t == "Esc" && (t = "Escape"), t == "Del" && (t = "Delete"), t == "Left" && (t = "ArrowLeft"), t == "Up" && (t = "ArrowUp"), t == "Right" && (t = "ArrowRight"), t == "Down" && (t = "ArrowDown"), t
    }

    const ha = typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : !1;

    function da(n) {
        let e = n.split(/-(?!$)/), t = e[e.length - 1];
        t == "Space" && (t = " ");
        let r, i, s, o;
        for (let l = 0; l < e.length - 1; l++) {
            let a = e[l];
            if (/^(cmd|meta|m)$/i.test(a)) o = !0; else if (/^a(lt)?$/i.test(a)) r = !0; else if (/^(c|ctrl|control)$/i.test(a)) i = !0; else if (/^s(hift)?$/i.test(a)) s = !0; else if (/^mod$/i.test(a)) ha ? o = !0 : i = !0; else throw new Error("Unrecognized modifier name: " + a)
        }
        return r && (t = "Alt-" + t), i && (t = "Ctrl-" + t), o && (t = "Meta-" + t), s && (t = "Shift-" + t), t
    }

    function ua(n) {
        let e = Object.create(null);
        for (let t in n) e[da(t)] = n[t];
        return e
    }

    function qn(n, e, t = !0) {
        return e.altKey && (n = "Alt-" + n), e.ctrlKey && (n = "Ctrl-" + n), e.metaKey && (n = "Meta-" + n), t && e.shiftKey && (n = "Shift-" + n), n
    }

    function Kn(n) {
        return new ot({props: {handleKeyDown: Wi(n)}})
    }

    function Wi(n) {
        let e = ua(n);
        return function (t, r) {
            let i = fa(r), s, o = e[qn(i, r)];
            if (o && o(t.state, t.dispatch, t)) return !0;
            if (i.length == 1 && i != " ") {
                if (r.shiftKey) {
                    let l = e[qn(i, r, !1)];
                    if (l && l(t.state, t.dispatch, t)) return !0
                }
                if ((r.shiftKey || r.altKey || r.metaKey || i.charCodeAt(0) > 127) && (s = Ce[r.keyCode]) && s != i) {
                    let l = e[qn(s, r)];
                    if (l && l(t.state, t.dispatch, t)) return !0
                }
            }
            return !1
        }
    }

    function Ji(n, e = null) {
        return function (t, r) {
            let {$from: i, $to: s} = t.selection, o = i.blockRange(s), l = !1, a = o;
            if (!o) return !1;
            if (o.depth >= 2 && i.node(o.depth - 1).type.compatibleContent(n) && o.startIndex == 0) {
                if (i.index(o.depth - 1) == 0) return !1;
                let f = t.doc.resolve(o.start - 2);
                a = new Jt(f, f, o.depth), o.endIndex < o.parent.childCount && (o = new Jt(i, t.doc.resolve(s.end(o.depth)), o.depth)), l = !0
            }
            let c = ai(a, n, e, o);
            return c ? (r && r(pa(t.tr, o, c, l, n).scrollIntoView()), !0) : !1
        }
    }

    function pa(n, e, t, r, i) {
        let s = y.empty;
        for (let f = t.length - 1; f >= 0; f--) s = y.from(t[f].type.create(t[f].attrs, s));
        n.step(new P(e.start - (r ? 2 : 0), e.end, e.start, e.end, new x(s, 0, 0), t.length, !0));
        let o = 0;
        for (let f = 0; f < t.length; f++) t[f].type == i && (o = f + 1);
        let l = t.length - o, a = e.start + t.length - (r ? 2 : 0), c = e.parent;
        for (let f = e.startIndex, h = e.endIndex, d = !0; f < h; f++, d = !1) !d && tt(n.doc, a, l) && (n.split(a, l), a += 2 * l), a += c.child(f).nodeSize;
        return n
    }

    function ma(n, e) {
        return function (t, r) {
            let {$from: i, $to: s, node: o} = t.selection;
            if (o && o.isBlock || i.depth < 2 || !i.sameParent(s)) return !1;
            let l = i.node(-1);
            if (l.type != n) return !1;
            if (i.parent.content.size == 0 && i.node(-1).childCount == i.indexAfter(-1)) {
                if (i.depth == 3 || i.node(-3).type != n || i.index(-2) != i.node(-2).childCount - 1) return !1;
                if (r) {
                    let h = y.empty, d = i.index(-1) ? 1 : i.index(-2) ? 2 : 3;
                    for (let b = i.depth - d; b >= i.depth - 3; b--) h = y.from(i.node(b).copy(h));
                    let u = i.indexAfter(-1) < i.node(-2).childCount ? 1 : i.indexAfter(-2) < i.node(-3).childCount ? 2 : 3;
                    h = h.append(y.from(n.createAndFill()));
                    let p = i.before(i.depth - (d - 1)), m = t.tr.replace(p, i.after(-u), new x(h, 4 - d, 0)), g = -1;
                    m.doc.nodesBetween(p, m.doc.content.size, (b, w) => {
                        if (g > -1) return !1;
                        b.isTextblock && b.content.size == 0 && (g = w + 1)
                    }), g > -1 && m.setSelection(S.near(m.doc.resolve(g))), r(m.scrollIntoView())
                }
                return !0
            }
            let a = s.pos == i.end() ? l.contentMatchAt(0).defaultType : null, c = t.tr.delete(i.pos, s.pos),
                f = a ? [null, {type: a}] : void 0;
            return tt(c.doc, i.pos, 2, f) ? (r && r(c.split(i.pos, 2, f).scrollIntoView()), !0) : !1
        }
    }

    function jn(n) {
        return function (e, t) {
            let {$from: r, $to: i} = e.selection, s = r.blockRange(i, o => o.childCount > 0 && o.firstChild.type == n);
            return s ? t ? r.node(s.depth - 1).type == n ? ga(e, t, n, s) : ya(e, t, s) : !0 : !1
        }
    }

    function ga(n, e, t, r) {
        let i = n.tr, s = r.end, o = r.$to.end(r.depth);
        s < o && (i.step(new P(s - 1, o, s, o, new x(y.from(t.create(null, r.parent.copy())), 1, 0), 1, !0)), r = new Jt(i.doc.resolve(r.$from.pos), i.doc.resolve(o), r.depth));
        const l = Yt(r);
        if (l == null) return !1;
        i.lift(r, l);
        let a = i.mapping.map(s, -1) - 1;
        return Zt(i.doc, a) && i.join(a), e(i.scrollIntoView()), !0
    }

    function ya(n, e, t) {
        let r = n.tr, i = t.parent;
        for (let u = t.end, p = t.endIndex - 1, m = t.startIndex; p > m; p--) u -= i.child(p).nodeSize, r.delete(u - 1, u + 1);
        let s = r.doc.resolve(t.start), o = s.nodeAfter;
        if (r.mapping.map(t.end) != t.start + s.nodeAfter.nodeSize) return !1;
        let l = t.startIndex == 0, a = t.endIndex == i.childCount, c = s.node(-1), f = s.index(-1);
        if (!c.canReplace(f + (l ? 0 : 1), f + 1, o.content.append(a ? y.empty : y.from(i)))) return !1;
        let h = s.pos, d = h + o.nodeSize;
        return r.step(new P(h - (l ? 1 : 0), d + (a ? 1 : 0), h + 1, d - 1, new x((l ? y.empty : y.from(i.copy(y.empty))).append(a ? y.empty : y.from(i.copy(y.empty))), l ? 0 : 1, a ? 0 : 1), l ? 0 : 1)), e(r.scrollIntoView()), !0
    }

    function ba(n) {
        return function (e, t) {
            let {$from: r, $to: i} = e.selection, s = r.blockRange(i, c => c.childCount > 0 && c.firstChild.type == n);
            if (!s) return !1;
            let o = s.startIndex;
            if (o == 0) return !1;
            let l = s.parent, a = l.child(o - 1);
            if (a.type != n) return !1;
            if (t) {
                let c = a.lastChild && a.lastChild.type == l.type, f = y.from(c ? n.create() : null),
                    h = new x(y.from(n.create(null, y.from(l.type.create(null, f)))), c ? 3 : 1, 0), d = s.start,
                    u = s.end;
                t(e.tr.step(new P(d - (c ? 3 : 1), u, d, u, h, 1, !0)).scrollIntoView())
            }
            return !0
        }
    }

    const F = function (n) {
        for (var e = 0; ; e++) if (n = n.previousSibling, !n) return e
    }, Mt = function (n) {
        let e = n.assignedSlot || n.parentNode;
        return e && e.nodeType == 11 ? e.host : e
    };
    let Un = null;
    const he = function (n, e, t) {
        let r = Un || (Un = document.createRange());
        return r.setEnd(n, t ?? n.nodeValue.length), r.setStart(n, e || 0), r
    }, xa = function () {
        Un = null
    }, Je = function (n, e, t, r) {
        return t && (qi(n, e, t, r, -1) || qi(n, e, t, r, 1))
    }, ka = /^(img|br|input|textarea|hr)$/i;

    function qi(n, e, t, r, i) {
        for (; ;) {
            if (n == t && e == r) return !0;
            if (e == (i < 0 ? 0 : Y(n))) {
                let s = n.parentNode;
                if (!s || s.nodeType != 1 || Ot(n) || ka.test(n.nodeName) || n.contentEditable == "false") return !1;
                e = F(n) + (i < 0 ? 0 : 1), n = s
            } else if (n.nodeType == 1) {
                if (n = n.childNodes[e + (i < 0 ? -1 : 0)], n.contentEditable == "false") return !1;
                e = i < 0 ? Y(n) : 0
            } else return !1
        }
    }

    function Y(n) {
        return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length
    }

    function Sa(n, e) {
        for (; ;) {
            if (n.nodeType == 3 && e) return n;
            if (n.nodeType == 1 && e > 0) {
                if (n.contentEditable == "false") return null;
                n = n.childNodes[e - 1], e = Y(n)
            } else if (n.parentNode && !Ot(n)) e = F(n), n = n.parentNode; else return null
        }
    }

    function Ca(n, e) {
        for (; ;) {
            if (n.nodeType == 3 && e < n.nodeValue.length) return n;
            if (n.nodeType == 1 && e < n.childNodes.length) {
                if (n.contentEditable == "false") return null;
                n = n.childNodes[e], e = 0
            } else if (n.parentNode && !Ot(n)) e = F(n) + 1, n = n.parentNode; else return null
        }
    }

    function wa(n, e, t) {
        for (let r = e == 0, i = e == Y(n); r || i;) {
            if (n == t) return !0;
            let s = F(n);
            if (n = n.parentNode, !n) return !1;
            r = r && s == 0, i = i && s == Y(n)
        }
    }

    function Ot(n) {
        let e;
        for (let t = n; t && !(e = t.pmViewDesc); t = t.parentNode) ;
        return e && e.node && e.node.isBlock && (e.dom == n || e.contentDOM == n)
    }

    const sn = function (n) {
        return n.focusNode && Je(n.focusNode, n.focusOffset, n.anchorNode, n.anchorOffset)
    };

    function qe(n, e) {
        let t = document.createEvent("Event");
        return t.initEvent("keydown", !0, !0), t.keyCode = n, t.key = t.code = e, t
    }

    function Ma(n) {
        let e = n.activeElement;
        for (; e && e.shadowRoot;) e = e.shadowRoot.activeElement;
        return e
    }

    function Oa(n, e, t) {
        if (n.caretPositionFromPoint) try {
            let r = n.caretPositionFromPoint(e, t);
            if (r) return {node: r.offsetNode, offset: Math.min(Y(r.offsetNode), r.offset)}
        } catch {
        }
        if (n.caretRangeFromPoint) {
            let r = n.caretRangeFromPoint(e, t);
            if (r) return {node: r.startContainer, offset: Math.min(Y(r.startContainer), r.startOffset)}
        }
    }

    const le = typeof navigator < "u" ? navigator : null, Ki = typeof document < "u" ? document : null,
        we = le && le.userAgent || "", Gn = /Edge\/(\d+)/.exec(we), ji = /MSIE \d/.exec(we),
        _n = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(we), j = !!(ji || _n || Gn),
        Me = ji ? document.documentMode : _n ? +_n[1] : Gn ? +Gn[1] : 0, ne = !j && /gecko\/(\d+)/i.test(we);
    ne && +(/Firefox\/(\d+)/.exec(we) || [0, 0])[1];
    const Xn = !j && /Chrome\/(\d+)/.exec(we), $ = !!Xn, Ui = Xn ? +Xn[1] : 0,
        J = !j && !!le && /Apple Computer/.test(le.vendor),
        at = J && (/Mobile\/\w+/.test(we) || !!le && le.maxTouchPoints > 2),
        Z = at || (le ? /Mac/.test(le.platform) : !1), Na = le ? /Win/.test(le.platform) : !1,
        re = /Android \d/.test(we), Nt = !!Ki && "webkitFontSmoothing" in Ki.documentElement.style,
        Ta = Nt ? +(/\bAppleWebKit\/(\d+)/.exec(navigator.userAgent) || [0, 0])[1] : 0;

    function Aa(n) {
        let e = n.defaultView && n.defaultView.visualViewport;
        return e ? {left: 0, right: e.width, top: 0, bottom: e.height} : {
            left: 0,
            right: n.documentElement.clientWidth,
            top: 0,
            bottom: n.documentElement.clientHeight
        }
    }

    function de(n, e) {
        return typeof n == "number" ? n : n[e]
    }

    function Da(n) {
        let e = n.getBoundingClientRect(), t = e.width / n.offsetWidth || 1, r = e.height / n.offsetHeight || 1;
        return {left: e.left, right: e.left + n.clientWidth * t, top: e.top, bottom: e.top + n.clientHeight * r}
    }

    function Gi(n, e, t) {
        let r = n.someProp("scrollThreshold") || 0, i = n.someProp("scrollMargin") || 5, s = n.dom.ownerDocument;
        for (let o = t || n.dom; o; o = Mt(o)) {
            if (o.nodeType != 1) continue;
            let l = o, a = l == s.body, c = a ? Aa(s) : Da(l), f = 0, h = 0;
            if (e.top < c.top + de(r, "top") ? h = -(c.top - e.top + de(i, "top")) : e.bottom > c.bottom - de(r, "bottom") && (h = e.bottom - e.top > c.bottom - c.top ? e.top + de(i, "top") - c.top : e.bottom - c.bottom + de(i, "bottom")), e.left < c.left + de(r, "left") ? f = -(c.left - e.left + de(i, "left")) : e.right > c.right - de(r, "right") && (f = e.right - c.right + de(i, "right")), f || h) if (a) s.defaultView.scrollBy(f, h); else {
                let d = l.scrollLeft, u = l.scrollTop;
                h && (l.scrollTop += h), f && (l.scrollLeft += f);
                let p = l.scrollLeft - d, m = l.scrollTop - u;
                e = {left: e.left - p, top: e.top - m, right: e.right - p, bottom: e.bottom - m}
            }
            if (a || /^(fixed|sticky)$/.test(getComputedStyle(o).position)) break
        }
    }

    function Ea(n) {
        let e = n.dom.getBoundingClientRect(), t = Math.max(0, e.top), r, i;
        for (let s = (e.left + e.right) / 2, o = t + 1; o < Math.min(innerHeight, e.bottom); o += 5) {
            let l = n.root.elementFromPoint(s, o);
            if (!l || l == n.dom || !n.dom.contains(l)) continue;
            let a = l.getBoundingClientRect();
            if (a.top >= t - 20) {
                r = l, i = a.top;
                break
            }
        }
        return {refDOM: r, refTop: i, stack: _i(n.dom)}
    }

    function _i(n) {
        let e = [], t = n.ownerDocument;
        for (let r = n; r && (e.push({dom: r, top: r.scrollTop, left: r.scrollLeft}), n != t); r = Mt(r)) ;
        return e
    }

    function Ra({refDOM: n, refTop: e, stack: t}) {
        let r = n ? n.getBoundingClientRect().top : 0;
        Xi(t, r == 0 ? 0 : r - e)
    }

    function Xi(n, e) {
        for (let t = 0; t < n.length; t++) {
            let {dom: r, top: i, left: s} = n[t];
            r.scrollTop != i + e && (r.scrollTop = i + e), r.scrollLeft != s && (r.scrollLeft = s)
        }
    }

    let ct = null;

    function Ia(n) {
        if (n.setActive) return n.setActive();
        if (ct) return n.focus(ct);
        let e = _i(n);
        n.focus(ct == null ? {
            get preventScroll() {
                return ct = {preventScroll: !0}, !0
            }
        } : void 0), ct || (ct = !1, Xi(e, 0))
    }

    function Yi(n, e) {
        let t, r = 2e8, i, s = 0, o = e.top, l = e.top, a, c;
        for (let f = n.firstChild, h = 0; f; f = f.nextSibling, h++) {
            let d;
            if (f.nodeType == 1) d = f.getClientRects(); else if (f.nodeType == 3) d = he(f).getClientRects(); else continue;
            for (let u = 0; u < d.length; u++) {
                let p = d[u];
                if (p.top <= o && p.bottom >= l) {
                    o = Math.max(p.bottom, o), l = Math.min(p.top, l);
                    let m = p.left > e.left ? p.left - e.left : p.right < e.left ? e.left - p.right : 0;
                    if (m < r) {
                        t = f, r = m, i = m && t.nodeType == 3 ? {
                            left: p.right < e.left ? p.right : p.left,
                            top: e.top
                        } : e, f.nodeType == 1 && m && (s = h + (e.left >= (p.left + p.right) / 2 ? 1 : 0));
                        continue
                    }
                } else p.top > e.top && !a && p.left <= e.left && p.right >= e.left && (a = f, c = {
                    left: Math.max(p.left, Math.min(p.right, e.left)),
                    top: p.top
                });
                !t && (e.left >= p.right && e.top >= p.top || e.left >= p.left && e.top >= p.bottom) && (s = h + 1)
            }
        }
        return !t && a && (t = a, i = c, r = 0), t && t.nodeType == 3 ? va(t, i) : !t || r && t.nodeType == 1 ? {
            node: n,
            offset: s
        } : Yi(t, i)
    }

    function va(n, e) {
        let t = n.nodeValue.length, r = document.createRange();
        for (let i = 0; i < t; i++) {
            r.setEnd(n, i + 1), r.setStart(n, i);
            let s = Oe(r, 1);
            if (s.top != s.bottom && Yn(e, s)) return {node: n, offset: i + (e.left >= (s.left + s.right) / 2 ? 1 : 0)}
        }
        return {node: n, offset: 0}
    }

    function Yn(n, e) {
        return n.left >= e.left - 1 && n.left <= e.right + 1 && n.top >= e.top - 1 && n.top <= e.bottom + 1
    }

    function za(n, e) {
        let t = n.parentNode;
        return t && /^li$/i.test(t.nodeName) && e.left < n.getBoundingClientRect().left ? t : n
    }

    function Ba(n, e, t) {
        let {node: r, offset: i} = Yi(e, t), s = -1;
        if (r.nodeType == 1 && !r.firstChild) {
            let o = r.getBoundingClientRect();
            s = o.left != o.right && t.left > (o.left + o.right) / 2 ? 1 : -1
        }
        return n.docView.posFromDOM(r, i, s)
    }

    function Pa(n, e, t, r) {
        let i = -1;
        for (let s = e, o = !1; s != n.dom;) {
            let l = n.docView.nearestDesc(s, !0);
            if (!l) return null;
            if (l.dom.nodeType == 1 && (l.node.isBlock && l.parent || !l.contentDOM)) {
                let a = l.dom.getBoundingClientRect();
                if (l.node.isBlock && l.parent && (!o && a.left > r.left || a.top > r.top ? i = l.posBefore : (!o && a.right < r.left || a.bottom < r.top) && (i = l.posAfter), o = !0), !l.contentDOM && i < 0 && !l.node.isText) return (l.node.isBlock ? r.top < (a.top + a.bottom) / 2 : r.left < (a.left + a.right) / 2) ? l.posBefore : l.posAfter
            }
            s = l.dom.parentNode
        }
        return i > -1 ? i : n.docView.posFromDOM(e, t, -1)
    }

    function Zi(n, e, t) {
        let r = n.childNodes.length;
        if (r && t.top < t.bottom) for (let i = Math.max(0, Math.min(r - 1, Math.floor(r * (e.top - t.top) / (t.bottom - t.top)) - 2)), s = i; ;) {
            let o = n.childNodes[s];
            if (o.nodeType == 1) {
                let l = o.getClientRects();
                for (let a = 0; a < l.length; a++) {
                    let c = l[a];
                    if (Yn(e, c)) return Zi(o, e, c)
                }
            }
            if ((s = (s + 1) % r) == i) break
        }
        return n
    }

    function Va(n, e) {
        let t = n.dom.ownerDocument, r, i = 0, s = Oa(t, e.left, e.top);
        s && ({node: r, offset: i} = s);
        let o = (n.root.elementFromPoint ? n.root : t).elementFromPoint(e.left, e.top), l;
        if (!o || !n.dom.contains(o.nodeType != 1 ? o.parentNode : o)) {
            let c = n.dom.getBoundingClientRect();
            if (!Yn(e, c) || (o = Zi(n.dom, e, c), !o)) return null
        }
        if (J) for (let c = o; r && c; c = Mt(c)) c.draggable && (r = void 0);
        if (o = za(o, e), r) {
            if (ne && r.nodeType == 1 && (i = Math.min(i, r.childNodes.length), i < r.childNodes.length)) {
                let f = r.childNodes[i], h;
                f.nodeName == "IMG" && (h = f.getBoundingClientRect()).right <= e.left && h.bottom > e.top && i++
            }
            let c;
            Nt && i && r.nodeType == 1 && (c = r.childNodes[i - 1]).nodeType == 1 && c.contentEditable == "false" && c.getBoundingClientRect().top >= e.top && i--, r == n.dom && i == r.childNodes.length - 1 && r.lastChild.nodeType == 1 && e.top > r.lastChild.getBoundingClientRect().bottom ? l = n.state.doc.content.size : (i == 0 || r.nodeType != 1 || r.childNodes[i - 1].nodeName != "BR") && (l = Pa(n, r, i, e))
        }
        l == null && (l = Ba(n, o, e));
        let a = n.docView.nearestDesc(o, !0);
        return {pos: l, inside: a ? a.posAtStart - a.border : -1}
    }

    function Qi(n) {
        return n.top < n.bottom || n.left < n.right
    }

    function Oe(n, e) {
        let t = n.getClientRects();
        if (t.length) {
            let r = t[e < 0 ? 0 : t.length - 1];
            if (Qi(r)) return r
        }
        return Array.prototype.find.call(t, Qi) || n.getBoundingClientRect()
    }

    const Fa = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/;

    function es(n, e, t) {
        let {node: r, offset: i, atom: s} = n.docView.domFromPos(e, t < 0 ? -1 : 1), o = Nt || ne;
        if (r.nodeType == 3) if (o && (Fa.test(r.nodeValue) || (t < 0 ? !i : i == r.nodeValue.length))) {
            let a = Oe(he(r, i, i), t);
            if (ne && i && /\s/.test(r.nodeValue[i - 1]) && i < r.nodeValue.length) {
                let c = Oe(he(r, i - 1, i - 1), -1);
                if (c.top == a.top) {
                    let f = Oe(he(r, i, i + 1), -1);
                    if (f.top != a.top) return Tt(f, f.left < c.left)
                }
            }
            return a
        } else {
            let a = i, c = i, f = t < 0 ? 1 : -1;
            return t < 0 && !i ? (c++, f = -1) : t >= 0 && i == r.nodeValue.length ? (a--, f = 1) : t < 0 ? a-- : c++, Tt(Oe(he(r, a, c), f), f < 0)
        }
        if (!n.state.doc.resolve(e - (s || 0)).parent.inlineContent) {
            if (s == null && i && (t < 0 || i == Y(r))) {
                let a = r.childNodes[i - 1];
                if (a.nodeType == 1) return Zn(a.getBoundingClientRect(), !1)
            }
            if (s == null && i < Y(r)) {
                let a = r.childNodes[i];
                if (a.nodeType == 1) return Zn(a.getBoundingClientRect(), !0)
            }
            return Zn(r.getBoundingClientRect(), t >= 0)
        }
        if (s == null && i && (t < 0 || i == Y(r))) {
            let a = r.childNodes[i - 1],
                c = a.nodeType == 3 ? he(a, Y(a) - (o ? 0 : 1)) : a.nodeType == 1 && (a.nodeName != "BR" || !a.nextSibling) ? a : null;
            if (c) return Tt(Oe(c, 1), !1)
        }
        if (s == null && i < Y(r)) {
            let a = r.childNodes[i];
            for (; a.pmViewDesc && a.pmViewDesc.ignoreForCoords;) a = a.nextSibling;
            let c = a ? a.nodeType == 3 ? he(a, 0, o ? 0 : 1) : a.nodeType == 1 ? a : null : null;
            if (c) return Tt(Oe(c, -1), !0)
        }
        return Tt(Oe(r.nodeType == 3 ? he(r) : r, -t), t >= 0)
    }

    function Tt(n, e) {
        if (n.width == 0) return n;
        let t = e ? n.left : n.right;
        return {top: n.top, bottom: n.bottom, left: t, right: t}
    }

    function Zn(n, e) {
        if (n.height == 0) return n;
        let t = e ? n.top : n.bottom;
        return {top: t, bottom: t, left: n.left, right: n.right}
    }

    function ts(n, e, t) {
        let r = n.state, i = n.root.activeElement;
        r != e && n.updateState(e), i != n.dom && n.focus();
        try {
            return t()
        } finally {
            r != e && n.updateState(r), i != n.dom && i && i.focus()
        }
    }

    function La(n, e, t) {
        let r = e.selection, i = t == "up" ? r.$from : r.$to;
        return ts(n, e, () => {
            let {node: s} = n.docView.domFromPos(i.pos, t == "up" ? -1 : 1);
            for (; ;) {
                let l = n.docView.nearestDesc(s, !0);
                if (!l) break;
                if (l.node.isBlock) {
                    s = l.contentDOM || l.dom;
                    break
                }
                s = l.dom.parentNode
            }
            let o = es(n, i.pos, 1);
            for (let l = s.firstChild; l; l = l.nextSibling) {
                let a;
                if (l.nodeType == 1) a = l.getClientRects(); else if (l.nodeType == 3) a = he(l, 0, l.nodeValue.length).getClientRects(); else continue;
                for (let c = 0; c < a.length; c++) {
                    let f = a[c];
                    if (f.bottom > f.top + 1 && (t == "up" ? o.top - f.top > (f.bottom - o.top) * 2 : f.bottom - o.bottom > (o.bottom - f.top) * 2)) return !1
                }
            }
            return !0
        })
    }

    const Ha = /[\u0590-\u08ac]/;

    function $a(n, e, t) {
        let {$head: r} = e.selection;
        if (!r.parent.isTextblock) return !1;
        let i = r.parentOffset, s = !i, o = i == r.parent.content.size, l = n.domSelection();
        return l ? !Ha.test(r.parent.textContent) || !l.modify ? t == "left" || t == "backward" ? s : o : ts(n, e, () => {
            let {focusNode: a, focusOffset: c, anchorNode: f, anchorOffset: h} = n.domSelectionRange(),
                d = l.caretBidiLevel;
            l.modify("move", t, "character");
            let u = r.depth ? n.docView.domAfterPos(r.before()) : n.dom, {
                focusNode: p,
                focusOffset: m
            } = n.domSelectionRange(), g = p && !u.contains(p.nodeType == 1 ? p : p.parentNode) || a == p && c == m;
            try {
                l.collapse(f, h), a && (a != f || c != h) && l.extend && l.extend(a, c)
            } catch {
            }
            return d != null && (l.caretBidiLevel = d), g
        }) : r.pos == r.start() || r.pos == r.end()
    }

    let ns = null, rs = null, is = !1;

    function Wa(n, e, t) {
        return ns == e && rs == t ? is : (ns = e, rs = t, is = t == "up" || t == "down" ? La(n, e, t) : $a(n, e, t))
    }

    const Q = 0, ss = 1, Ke = 2, ae = 3;

    class At {
        constructor(e, t, r, i) {
            this.parent = e, this.children = t, this.dom = r, this.contentDOM = i, this.dirty = Q, r.pmViewDesc = this
        }

        matchesWidget(e) {
            return !1
        }

        matchesMark(e) {
            return !1
        }

        matchesNode(e, t, r) {
            return !1
        }

        matchesHack(e) {
            return !1
        }

        parseRule() {
            return null
        }

        stopEvent(e) {
            return !1
        }

        get size() {
            let e = 0;
            for (let t = 0; t < this.children.length; t++) e += this.children[t].size;
            return e
        }

        get border() {
            return 0
        }

        destroy() {
            this.parent = void 0, this.dom.pmViewDesc == this && (this.dom.pmViewDesc = void 0);
            for (let e = 0; e < this.children.length; e++) this.children[e].destroy()
        }

        posBeforeChild(e) {
            for (let t = 0, r = this.posAtStart; ; t++) {
                let i = this.children[t];
                if (i == e) return r;
                r += i.size
            }
        }

        get posBefore() {
            return this.parent.posBeforeChild(this)
        }

        get posAtStart() {
            return this.parent ? this.parent.posBeforeChild(this) + this.border : 0
        }

        get posAfter() {
            return this.posBefore + this.size
        }

        get posAtEnd() {
            return this.posAtStart + this.size - 2 * this.border
        }

        localPosFromDOM(e, t, r) {
            if (this.contentDOM && this.contentDOM.contains(e.nodeType == 1 ? e : e.parentNode)) if (r < 0) {
                let s, o;
                if (e == this.contentDOM) s = e.childNodes[t - 1]; else {
                    for (; e.parentNode != this.contentDOM;) e = e.parentNode;
                    s = e.previousSibling
                }
                for (; s && !((o = s.pmViewDesc) && o.parent == this);) s = s.previousSibling;
                return s ? this.posBeforeChild(o) + o.size : this.posAtStart
            } else {
                let s, o;
                if (e == this.contentDOM) s = e.childNodes[t]; else {
                    for (; e.parentNode != this.contentDOM;) e = e.parentNode;
                    s = e.nextSibling
                }
                for (; s && !((o = s.pmViewDesc) && o.parent == this);) s = s.nextSibling;
                return s ? this.posBeforeChild(o) : this.posAtEnd
            }
            let i;
            if (e == this.dom && this.contentDOM) i = t > F(this.contentDOM); else if (this.contentDOM && this.contentDOM != this.dom && this.dom.contains(this.contentDOM)) i = e.compareDocumentPosition(this.contentDOM) & 2; else if (this.dom.firstChild) {
                if (t == 0) for (let s = e; ; s = s.parentNode) {
                    if (s == this.dom) {
                        i = !1;
                        break
                    }
                    if (s.previousSibling) break
                }
                if (i == null && t == e.childNodes.length) for (let s = e; ; s = s.parentNode) {
                    if (s == this.dom) {
                        i = !0;
                        break
                    }
                    if (s.nextSibling) break
                }
            }
            return i ?? r > 0 ? this.posAtEnd : this.posAtStart
        }

        nearestDesc(e, t = !1) {
            for (let r = !0, i = e; i; i = i.parentNode) {
                let s = this.getDesc(i), o;
                if (s && (!t || s.node)) if (r && (o = s.nodeDOM) && !(o.nodeType == 1 ? o.contains(e.nodeType == 1 ? e : e.parentNode) : o == e)) r = !1; else return s
            }
        }

        getDesc(e) {
            let t = e.pmViewDesc;
            for (let r = t; r; r = r.parent) if (r == this) return t
        }

        posFromDOM(e, t, r) {
            for (let i = e; i; i = i.parentNode) {
                let s = this.getDesc(i);
                if (s) return s.localPosFromDOM(e, t, r)
            }
            return -1
        }

        descAt(e) {
            for (let t = 0, r = 0; t < this.children.length; t++) {
                let i = this.children[t], s = r + i.size;
                if (r == e && s != r) {
                    for (; !i.border && i.children.length;) i = i.children[0];
                    return i
                }
                if (e < s) return i.descAt(e - r - i.border);
                r = s
            }
        }

        domFromPos(e, t) {
            if (!this.contentDOM) return {node: this.dom, offset: 0, atom: e + 1};
            let r = 0, i = 0;
            for (let s = 0; r < this.children.length; r++) {
                let o = this.children[r], l = s + o.size;
                if (l > e || o instanceof cs) {
                    i = e - s;
                    break
                }
                s = l
            }
            if (i) return this.children[r].domFromPos(i - this.children[r].border, t);
            for (let s; r && !(s = this.children[r - 1]).size && s instanceof ls && s.side >= 0; r--) ;
            if (t <= 0) {
                let s, o = !0;
                for (; s = r ? this.children[r - 1] : null, !(!s || s.dom.parentNode == this.contentDOM); r--, o = !1) ;
                return s && t && o && !s.border && !s.domAtom ? s.domFromPos(s.size, t) : {
                    node: this.contentDOM,
                    offset: s ? F(s.dom) + 1 : 0
                }
            } else {
                let s, o = !0;
                for (; s = r < this.children.length ? this.children[r] : null, !(!s || s.dom.parentNode == this.contentDOM); r++, o = !1) ;
                return s && o && !s.border && !s.domAtom ? s.domFromPos(0, t) : {
                    node: this.contentDOM,
                    offset: s ? F(s.dom) : this.contentDOM.childNodes.length
                }
            }
        }

        parseRange(e, t, r = 0) {
            if (this.children.length == 0) return {
                node: this.contentDOM,
                from: e,
                to: t,
                fromOffset: 0,
                toOffset: this.contentDOM.childNodes.length
            };
            let i = -1, s = -1;
            for (let o = r, l = 0; ; l++) {
                let a = this.children[l], c = o + a.size;
                if (i == -1 && e <= c) {
                    let f = o + a.border;
                    if (e >= f && t <= c - a.border && a.node && a.contentDOM && this.contentDOM.contains(a.contentDOM)) return a.parseRange(e, t, f);
                    e = o;
                    for (let h = l; h > 0; h--) {
                        let d = this.children[h - 1];
                        if (d.size && d.dom.parentNode == this.contentDOM && !d.emptyChildAt(1)) {
                            i = F(d.dom) + 1;
                            break
                        }
                        e -= d.size
                    }
                    i == -1 && (i = 0)
                }
                if (i > -1 && (c > t || l == this.children.length - 1)) {
                    t = c;
                    for (let f = l + 1; f < this.children.length; f++) {
                        let h = this.children[f];
                        if (h.size && h.dom.parentNode == this.contentDOM && !h.emptyChildAt(-1)) {
                            s = F(h.dom);
                            break
                        }
                        t += h.size
                    }
                    s == -1 && (s = this.contentDOM.childNodes.length);
                    break
                }
                o = c
            }
            return {node: this.contentDOM, from: e, to: t, fromOffset: i, toOffset: s}
        }

        emptyChildAt(e) {
            if (this.border || !this.contentDOM || !this.children.length) return !1;
            let t = this.children[e < 0 ? 0 : this.children.length - 1];
            return t.size == 0 || t.emptyChildAt(e)
        }

        domAfterPos(e) {
            let {node: t, offset: r} = this.domFromPos(e, 0);
            if (t.nodeType != 1 || r == t.childNodes.length) throw new RangeError("No node after pos " + e);
            return t.childNodes[r]
        }

        setSelection(e, t, r, i = !1) {
            let s = Math.min(e, t), o = Math.max(e, t);
            for (let u = 0, p = 0; u < this.children.length; u++) {
                let m = this.children[u], g = p + m.size;
                if (s > p && o < g) return m.setSelection(e - p - m.border, t - p - m.border, r, i);
                p = g
            }
            let l = this.domFromPos(e, e ? -1 : 1), a = t == e ? l : this.domFromPos(t, t ? -1 : 1),
                c = r.root.getSelection(), f = r.domSelectionRange(), h = !1;
            if ((ne || J) && e == t) {
                let {node: u, offset: p} = l;
                if (u.nodeType == 3) {
                    if (h = !!(p && u.nodeValue[p - 1] == `
`), h && p == u.nodeValue.length) for (let m = u, g; m; m = m.parentNode) {
                        if (g = m.nextSibling) {
                            g.nodeName == "BR" && (l = a = {node: g.parentNode, offset: F(g) + 1});
                            break
                        }
                        let b = m.pmViewDesc;
                        if (b && b.node && b.node.isBlock) break
                    }
                } else {
                    let m = u.childNodes[p - 1];
                    h = m && (m.nodeName == "BR" || m.contentEditable == "false")
                }
            }
            if (ne && f.focusNode && f.focusNode != a.node && f.focusNode.nodeType == 1) {
                let u = f.focusNode.childNodes[f.focusOffset];
                u && u.contentEditable == "false" && (i = !0)
            }
            if (!(i || h && J) && Je(l.node, l.offset, f.anchorNode, f.anchorOffset) && Je(a.node, a.offset, f.focusNode, f.focusOffset)) return;
            let d = !1;
            if ((c.extend || e == t) && !h) {
                c.collapse(l.node, l.offset);
                try {
                    e != t && c.extend(a.node, a.offset), d = !0
                } catch {
                }
            }
            if (!d) {
                if (e > t) {
                    let p = l;
                    l = a, a = p
                }
                let u = document.createRange();
                u.setEnd(a.node, a.offset), u.setStart(l.node, l.offset), c.removeAllRanges(), c.addRange(u)
            }
        }

        ignoreMutation(e) {
            return !this.contentDOM && e.type != "selection"
        }

        get contentLost() {
            return this.contentDOM && this.contentDOM != this.dom && !this.dom.contains(this.contentDOM)
        }

        markDirty(e, t) {
            for (let r = 0, i = 0; i < this.children.length; i++) {
                let s = this.children[i], o = r + s.size;
                if (r == o ? e <= o && t >= r : e < o && t > r) {
                    let l = r + s.border, a = o - s.border;
                    if (e >= l && t <= a) {
                        this.dirty = e == r || t == o ? Ke : ss, e == l && t == a && (s.contentLost || s.dom.parentNode != this.contentDOM) ? s.dirty = ae : s.markDirty(e - l, t - l);
                        return
                    } else s.dirty = s.dom == s.contentDOM && s.dom.parentNode == this.contentDOM && !s.children.length ? Ke : ae
                }
                r = o
            }
            this.dirty = Ke
        }

        markParentsDirty() {
            let e = 1;
            for (let t = this.parent; t; t = t.parent, e++) {
                let r = e == 1 ? Ke : ss;
                t.dirty < r && (t.dirty = r)
            }
        }

        get domAtom() {
            return !1
        }

        get ignoreForCoords() {
            return !1
        }

        isText(e) {
            return !1
        }
    }

    class ls extends At {
        constructor(e, t, r, i) {
            let s, o = t.type.toDOM;
            if (typeof o == "function" && (o = o(r, () => {
                if (!s) return i;
                if (s.parent) return s.parent.posBeforeChild(s)
            })), !t.type.spec.raw) {
                if (o.nodeType != 1) {
                    let l = document.createElement("span");
                    l.appendChild(o), o = l
                }
                o.contentEditable = "false", o.classList.add("ProseMirror-widget")
            }
            super(e, [], o, null), this.widget = t, this.widget = t, s = this
        }

        matchesWidget(e) {
            return this.dirty == Q && e.type.eq(this.widget.type)
        }

        parseRule() {
            return {ignore: !0}
        }

        stopEvent(e) {
            let t = this.widget.spec.stopEvent;
            return t ? t(e) : !1
        }

        ignoreMutation(e) {
            return e.type != "selection" || this.widget.spec.ignoreSelection
        }

        destroy() {
            this.widget.type.destroy(this.dom), super.destroy()
        }

        get domAtom() {
            return !0
        }

        get side() {
            return this.widget.type.side
        }
    }

    class Ja extends At {
        constructor(e, t, r, i) {
            super(e, [], t, null), this.textDOM = r, this.text = i
        }

        get size() {
            return this.text.length
        }

        localPosFromDOM(e, t) {
            return e != this.textDOM ? this.posAtStart + (t ? this.size : 0) : this.posAtStart + t
        }

        domFromPos(e) {
            return {node: this.textDOM, offset: e}
        }

        ignoreMutation(e) {
            return e.type === "characterData" && e.target.nodeValue == e.oldValue
        }
    }

    class je extends At {
        constructor(e, t, r, i, s) {
            super(e, [], r, i), this.mark = t, this.spec = s
        }

        static create(e, t, r, i) {
            let s = i.nodeViews[t.type.name], o = s && s(t, i, r);
            return (!o || !o.dom) && (o = He.renderSpec(document, t.type.spec.toDOM(t, r), null, t.attrs)), new je(e, t, o.dom, o.contentDOM || o.dom, o)
        }

        parseRule() {
            return this.dirty & ae || this.mark.type.spec.reparseInView ? null : {
                mark: this.mark.type.name,
                attrs: this.mark.attrs,
                contentElement: this.contentDOM
            }
        }

        matchesMark(e) {
            return this.dirty != ae && this.mark.eq(e)
        }

        markDirty(e, t) {
            if (super.markDirty(e, t), this.dirty != Q) {
                let r = this.parent;
                for (; !r.node;) r = r.parent;
                r.dirty < this.dirty && (r.dirty = this.dirty), this.dirty = Q
            }
        }

        slice(e, t, r) {
            let i = je.create(this.parent, this.mark, !0, r), s = this.children, o = this.size;
            t < o && (s = er(s, t, o, r)), e > 0 && (s = er(s, 0, e, r));
            for (let l = 0; l < s.length; l++) s[l].parent = i;
            return i.children = s, i
        }

        ignoreMutation(e) {
            return this.spec.ignoreMutation ? this.spec.ignoreMutation(e) : super.ignoreMutation(e)
        }

        destroy() {
            this.spec.destroy && this.spec.destroy(), super.destroy()
        }
    }

    class Ne extends At {
        constructor(e, t, r, i, s, o, l, a, c) {
            super(e, [], s, o), this.node = t, this.outerDeco = r, this.innerDeco = i, this.nodeDOM = l
        }

        static create(e, t, r, i, s, o) {
            let l = s.nodeViews[t.type.name], a, c = l && l(t, s, () => {
                if (!a) return o;
                if (a.parent) return a.parent.posBeforeChild(a)
            }, r, i), f = c && c.dom, h = c && c.contentDOM;
            if (t.isText) {
                if (!f) f = document.createTextNode(t.text); else if (f.nodeType != 3) throw new RangeError("Text must be rendered as a DOM text node")
            } else f || ({dom: f, contentDOM: h} = He.renderSpec(document, t.type.spec.toDOM(t), null, t.attrs));
            !h && !t.isText && f.nodeName != "BR" && (f.hasAttribute("contenteditable") || (f.contentEditable = "false"), t.type.spec.draggable && (f.draggable = !0));
            let d = f;
            return f = ds(f, r, t), c ? a = new qa(e, t, r, i, f, h || null, d, c, s, o + 1) : t.isText ? new on(e, t, r, i, f, d, s) : new Ne(e, t, r, i, f, h || null, d, s, o + 1)
        }

        parseRule() {
            if (this.node.type.spec.reparseInView) return null;
            let e = {node: this.node.type.name, attrs: this.node.attrs};
            if (this.node.type.whitespace == "pre" && (e.preserveWhitespace = "full"), !this.contentDOM) e.getContent = () => this.node.content; else if (!this.contentLost) e.contentElement = this.contentDOM; else {
                for (let t = this.children.length - 1; t >= 0; t--) {
                    let r = this.children[t];
                    if (this.dom.contains(r.dom.parentNode)) {
                        e.contentElement = r.dom.parentNode;
                        break
                    }
                }
                e.contentElement || (e.getContent = () => y.empty)
            }
            return e
        }

        matchesNode(e, t, r) {
            return this.dirty == Q && e.eq(this.node) && ln(t, this.outerDeco) && r.eq(this.innerDeco)
        }

        get size() {
            return this.node.nodeSize
        }

        get border() {
            return this.node.isLeaf ? 0 : 1
        }

        updateChildren(e, t) {
            let r = this.node.inlineContent, i = t, s = e.composing ? this.localCompositionInfo(e, t) : null,
                o = s && s.pos > -1 ? s : null, l = s && s.pos < 0, a = new ja(this, o && o.node, e);
            _a(this.node, this.innerDeco, (c, f, h) => {
                c.spec.marks ? a.syncToMarks(c.spec.marks, r, e) : c.type.side >= 0 && !h && a.syncToMarks(f == this.node.childCount ? O.none : this.node.child(f).marks, r, e), a.placeWidget(c, e, i)
            }, (c, f, h, d) => {
                a.syncToMarks(c.marks, r, e);
                let u;
                a.findNodeMatch(c, f, h, d) || l && e.state.selection.from > i && e.state.selection.to < i + c.nodeSize && (u = a.findIndexWithChild(s.node)) > -1 && a.updateNodeAt(c, f, h, u, e) || a.updateNextNode(c, f, h, e, d, i) || a.addNode(c, f, h, e, i), i += c.nodeSize
            }), a.syncToMarks([], r, e), this.node.isTextblock && a.addTextblockHacks(), a.destroyRest(), (a.changed || this.dirty == Ke) && (o && this.protectLocalComposition(e, o), fs(this.contentDOM, this.children, e), at && Xa(this.dom))
        }

        localCompositionInfo(e, t) {
            let {from: r, to: i} = e.state.selection;
            if (!(e.state.selection instanceof C) || r < t || i > t + this.node.content.size) return null;
            let s = e.input.compositionNode;
            if (!s || !this.dom.contains(s.parentNode)) return null;
            if (this.node.inlineContent) {
                let o = s.nodeValue, l = Ya(this.node.content, o, r - t, i - t);
                return l < 0 ? null : {node: s, pos: l, text: o}
            } else return {node: s, pos: -1, text: ""}
        }

        protectLocalComposition(e, {node: t, pos: r, text: i}) {
            if (this.getDesc(t)) return;
            let s = t;
            for (; s.parentNode != this.contentDOM; s = s.parentNode) {
                for (; s.previousSibling;) s.parentNode.removeChild(s.previousSibling);
                for (; s.nextSibling;) s.parentNode.removeChild(s.nextSibling);
                s.pmViewDesc && (s.pmViewDesc = void 0)
            }
            let o = new Ja(this, s, t, i);
            e.input.compositionNodes.push(o), this.children = er(this.children, r, r + i.length, e, o)
        }

        update(e, t, r, i) {
            return this.dirty == ae || !e.sameMarkup(this.node) ? !1 : (this.updateInner(e, t, r, i), !0)
        }

        updateInner(e, t, r, i) {
            this.updateOuterDeco(t), this.node = e, this.innerDeco = r, this.contentDOM && this.updateChildren(i, this.posAtStart), this.dirty = Q
        }

        updateOuterDeco(e) {
            if (ln(e, this.outerDeco)) return;
            let t = this.nodeDOM.nodeType != 1, r = this.dom;
            this.dom = hs(this.dom, this.nodeDOM, Qn(this.outerDeco, this.node, t), Qn(e, this.node, t)), this.dom != r && (r.pmViewDesc = void 0, this.dom.pmViewDesc = this), this.outerDeco = e
        }

        selectNode() {
            this.nodeDOM.nodeType == 1 && this.nodeDOM.classList.add("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && (this.dom.draggable = !0)
        }

        deselectNode() {
            this.nodeDOM.nodeType == 1 && (this.nodeDOM.classList.remove("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && this.dom.removeAttribute("draggable"))
        }

        get domAtom() {
            return this.node.isAtom
        }
    }

    function as(n, e, t, r, i) {
        ds(r, e, n);
        let s = new Ne(void 0, n, e, t, r, r, r, i, 0);
        return s.contentDOM && s.updateChildren(i, 0), s
    }

    class on extends Ne {
        constructor(e, t, r, i, s, o, l) {
            super(e, t, r, i, s, null, o, l, 0)
        }

        parseRule() {
            let e = this.nodeDOM.parentNode;
            for (; e && e != this.dom && !e.pmIsDeco;) e = e.parentNode;
            return {skip: e || !0}
        }

        update(e, t, r, i) {
            return this.dirty == ae || this.dirty != Q && !this.inParent() || !e.sameMarkup(this.node) ? !1 : (this.updateOuterDeco(t), (this.dirty != Q || e.text != this.node.text) && e.text != this.nodeDOM.nodeValue && (this.nodeDOM.nodeValue = e.text, i.trackWrites == this.nodeDOM && (i.trackWrites = null)), this.node = e, this.dirty = Q, !0)
        }

        inParent() {
            let e = this.parent.contentDOM;
            for (let t = this.nodeDOM; t; t = t.parentNode) if (t == e) return !0;
            return !1
        }

        domFromPos(e) {
            return {node: this.nodeDOM, offset: e}
        }

        localPosFromDOM(e, t, r) {
            return e == this.nodeDOM ? this.posAtStart + Math.min(t, this.node.text.length) : super.localPosFromDOM(e, t, r)
        }

        ignoreMutation(e) {
            return e.type != "characterData" && e.type != "selection"
        }

        slice(e, t, r) {
            let i = this.node.cut(e, t), s = document.createTextNode(i.text);
            return new on(this.parent, i, this.outerDeco, this.innerDeco, s, s, r)
        }

        markDirty(e, t) {
            super.markDirty(e, t), this.dom != this.nodeDOM && (e == 0 || t == this.nodeDOM.nodeValue.length) && (this.dirty = ae)
        }

        get domAtom() {
            return !1
        }

        isText(e) {
            return this.node.text == e
        }
    }

    class cs extends At {
        parseRule() {
            return {ignore: !0}
        }

        matchesHack(e) {
            return this.dirty == Q && this.dom.nodeName == e
        }

        get domAtom() {
            return !0
        }

        get ignoreForCoords() {
            return this.dom.nodeName == "IMG"
        }
    }

    class qa extends Ne {
        constructor(e, t, r, i, s, o, l, a, c, f) {
            super(e, t, r, i, s, o, l, c, f), this.spec = a
        }

        update(e, t, r, i) {
            if (this.dirty == ae) return !1;
            if (this.spec.update && (this.node.type == e.type || this.spec.multiType)) {
                let s = this.spec.update(e, t, r);
                return s && this.updateInner(e, t, r, i), s
            } else return !this.contentDOM && !e.isLeaf ? !1 : super.update(e, t, r, i)
        }

        selectNode() {
            this.spec.selectNode ? this.spec.selectNode() : super.selectNode()
        }

        deselectNode() {
            this.spec.deselectNode ? this.spec.deselectNode() : super.deselectNode()
        }

        setSelection(e, t, r, i) {
            this.spec.setSelection ? this.spec.setSelection(e, t, r.root) : super.setSelection(e, t, r, i)
        }

        destroy() {
            this.spec.destroy && this.spec.destroy(), super.destroy()
        }

        stopEvent(e) {
            return this.spec.stopEvent ? this.spec.stopEvent(e) : !1
        }

        ignoreMutation(e) {
            return this.spec.ignoreMutation ? this.spec.ignoreMutation(e) : super.ignoreMutation(e)
        }
    }

    function fs(n, e, t) {
        let r = n.firstChild, i = !1;
        for (let s = 0; s < e.length; s++) {
            let o = e[s], l = o.dom;
            if (l.parentNode == n) {
                for (; l != r;) r = us(r), i = !0;
                r = r.nextSibling
            } else i = !0, n.insertBefore(l, r);
            if (o instanceof je) {
                let a = r ? r.previousSibling : n.lastChild;
                fs(o.contentDOM, o.children, t), r = a ? a.nextSibling : n.firstChild
            }
        }
        for (; r;) r = us(r), i = !0;
        i && t.trackWrites == n && (t.trackWrites = null)
    }

    const Dt = function (n) {
        n && (this.nodeName = n)
    };
    Dt.prototype = Object.create(null);
    const Ue = [new Dt];

    function Qn(n, e, t) {
        if (n.length == 0) return Ue;
        let r = t ? Ue[0] : new Dt, i = [r];
        for (let s = 0; s < n.length; s++) {
            let o = n[s].type.attrs;
            if (o) {
                o.nodeName && i.push(r = new Dt(o.nodeName));
                for (let l in o) {
                    let a = o[l];
                    a != null && (t && i.length == 1 && i.push(r = new Dt(e.isInline ? "span" : "div")), l == "class" ? r.class = (r.class ? r.class + " " : "") + a : l == "style" ? r.style = (r.style ? r.style + ";" : "") + a : l != "nodeName" && (r[l] = a))
                }
            }
        }
        return i
    }

    function hs(n, e, t, r) {
        if (t == Ue && r == Ue) return e;
        let i = e;
        for (let s = 0; s < r.length; s++) {
            let o = r[s], l = t[s];
            if (s) {
                let a;
                l && l.nodeName == o.nodeName && i != n && (a = i.parentNode) && a.nodeName.toLowerCase() == o.nodeName || (a = document.createElement(o.nodeName), a.pmIsDeco = !0, a.appendChild(i), l = Ue[0]), i = a
            }
            Ka(i, l || Ue[0], o)
        }
        return i
    }

    function Ka(n, e, t) {
        for (let r in e) r != "class" && r != "style" && r != "nodeName" && !(r in t) && n.removeAttribute(r);
        for (let r in t) r != "class" && r != "style" && r != "nodeName" && t[r] != e[r] && n.setAttribute(r, t[r]);
        if (e.class != t.class) {
            let r = e.class ? e.class.split(" ").filter(Boolean) : [],
                i = t.class ? t.class.split(" ").filter(Boolean) : [];
            for (let s = 0; s < r.length; s++) i.indexOf(r[s]) == -1 && n.classList.remove(r[s]);
            for (let s = 0; s < i.length; s++) r.indexOf(i[s]) == -1 && n.classList.add(i[s]);
            n.classList.length == 0 && n.removeAttribute("class")
        }
        if (e.style != t.style) {
            if (e.style) {
                let r = /\s*([\w\-\xa1-\uffff]+)\s*:(?:"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\(.*?\)|[^;])*/g, i;
                for (; i = r.exec(e.style);) n.style.removeProperty(i[1])
            }
            t.style && (n.style.cssText += t.style)
        }
    }

    function ds(n, e, t) {
        return hs(n, n, Ue, Qn(e, t, n.nodeType != 1))
    }

    function ln(n, e) {
        if (n.length != e.length) return !1;
        for (let t = 0; t < n.length; t++) if (!n[t].type.eq(e[t].type)) return !1;
        return !0
    }

    function us(n) {
        let e = n.nextSibling;
        return n.parentNode.removeChild(n), e
    }

    class ja {
        constructor(e, t, r) {
            this.lock = t, this.view = r, this.index = 0, this.stack = [], this.changed = !1, this.top = e, this.preMatch = Ua(e.node.content, e)
        }

        destroyBetween(e, t) {
            if (e != t) {
                for (let r = e; r < t; r++) this.top.children[r].destroy();
                this.top.children.splice(e, t - e), this.changed = !0
            }
        }

        destroyRest() {
            this.destroyBetween(this.index, this.top.children.length)
        }

        syncToMarks(e, t, r) {
            let i = 0, s = this.stack.length >> 1, o = Math.min(s, e.length);
            for (; i < o && (i == s - 1 ? this.top : this.stack[i + 1 << 1]).matchesMark(e[i]) && e[i].type.spec.spanning !== !1;) i++;
            for (; i < s;) this.destroyRest(), this.top.dirty = Q, this.index = this.stack.pop(), this.top = this.stack.pop(), s--;
            for (; s < e.length;) {
                this.stack.push(this.top, this.index + 1);
                let l = -1;
                for (let a = this.index; a < Math.min(this.index + 3, this.top.children.length); a++) {
                    let c = this.top.children[a];
                    if (c.matchesMark(e[s]) && !this.isLocked(c.dom)) {
                        l = a;
                        break
                    }
                }
                if (l > -1) l > this.index && (this.changed = !0, this.destroyBetween(this.index, l)), this.top = this.top.children[this.index]; else {
                    let a = je.create(this.top, e[s], t, r);
                    this.top.children.splice(this.index, 0, a), this.top = a, this.changed = !0
                }
                this.index = 0, s++
            }
        }

        findNodeMatch(e, t, r, i) {
            let s = -1, o;
            if (i >= this.preMatch.index && (o = this.preMatch.matches[i - this.preMatch.index]).parent == this.top && o.matchesNode(e, t, r)) s = this.top.children.indexOf(o, this.index); else for (let l = this.index, a = Math.min(this.top.children.length, l + 5); l < a; l++) {
                let c = this.top.children[l];
                if (c.matchesNode(e, t, r) && !this.preMatch.matched.has(c)) {
                    s = l;
                    break
                }
            }
            return s < 0 ? !1 : (this.destroyBetween(this.index, s), this.index++, !0)
        }

        updateNodeAt(e, t, r, i, s) {
            let o = this.top.children[i];
            return o.dirty == ae && o.dom == o.contentDOM && (o.dirty = Ke), o.update(e, t, r, s) ? (this.destroyBetween(this.index, i), this.index++, !0) : !1
        }

        findIndexWithChild(e) {
            for (; ;) {
                let t = e.parentNode;
                if (!t) return -1;
                if (t == this.top.contentDOM) {
                    let r = e.pmViewDesc;
                    if (r) {
                        for (let i = this.index; i < this.top.children.length; i++) if (this.top.children[i] == r) return i
                    }
                    return -1
                }
                e = t
            }
        }

        updateNextNode(e, t, r, i, s, o) {
            for (let l = this.index; l < this.top.children.length; l++) {
                let a = this.top.children[l];
                if (a instanceof Ne) {
                    let c = this.preMatch.matched.get(a);
                    if (c != null && c != s) return !1;
                    let f = a.dom, h,
                        d = this.isLocked(f) && !(e.isText && a.node && a.node.isText && a.nodeDOM.nodeValue == e.text && a.dirty != ae && ln(t, a.outerDeco));
                    if (!d && a.update(e, t, r, i)) return this.destroyBetween(this.index, l), a.dom != f && (this.changed = !0), this.index++, !0;
                    if (!d && (h = this.recreateWrapper(a, e, t, r, i, o))) return this.destroyBetween(this.index, l), this.top.children[this.index] = h, h.contentDOM && (h.dirty = Ke, h.updateChildren(i, o + 1), h.dirty = Q), this.changed = !0, this.index++, !0;
                    break
                }
            }
            return !1
        }

        recreateWrapper(e, t, r, i, s, o) {
            if (e.dirty || t.isAtom || !e.children.length || !e.node.content.eq(t.content) || !ln(r, e.outerDeco) || !i.eq(e.innerDeco)) return null;
            let l = Ne.create(this.top, t, r, i, s, o);
            if (l.contentDOM) {
                l.children = e.children, e.children = [];
                for (let a of l.children) a.parent = l
            }
            return e.destroy(), l
        }

        addNode(e, t, r, i, s) {
            let o = Ne.create(this.top, e, t, r, i, s);
            o.contentDOM && o.updateChildren(i, s + 1), this.top.children.splice(this.index++, 0, o), this.changed = !0
        }

        placeWidget(e, t, r) {
            let i = this.index < this.top.children.length ? this.top.children[this.index] : null;
            if (i && i.matchesWidget(e) && (e == i.widget || !i.widget.type.toDOM.parentNode)) this.index++; else {
                let s = new ls(this.top, e, t, r);
                this.top.children.splice(this.index++, 0, s), this.changed = !0
            }
        }

        addTextblockHacks() {
            let e = this.top.children[this.index - 1], t = this.top;
            for (; e instanceof je;) t = e, e = t.children[t.children.length - 1];
            (!e || !(e instanceof on) || /\n$/.test(e.node.text) || this.view.requiresGeckoHackNode && /\s$/.test(e.node.text)) && ((J || $) && e && e.dom.contentEditable == "false" && this.addHackNode("IMG", t), this.addHackNode("BR", this.top))
        }

        addHackNode(e, t) {
            if (t == this.top && this.index < t.children.length && t.children[this.index].matchesHack(e)) this.index++; else {
                let r = document.createElement(e);
                e == "IMG" && (r.className = "ProseMirror-separator", r.alt = ""), e == "BR" && (r.className = "ProseMirror-trailingBreak");
                let i = new cs(this.top, [], r, null);
                t != this.top ? t.children.push(i) : t.children.splice(this.index++, 0, i), this.changed = !0
            }
        }

        isLocked(e) {
            return this.lock && (e == this.lock || e.nodeType == 1 && e.contains(this.lock.parentNode))
        }
    }

    function Ua(n, e) {
        let t = e, r = t.children.length, i = n.childCount, s = new Map, o = [];
        e:for (; i > 0;) {
            let l;
            for (; ;) if (r) {
                let c = t.children[r - 1];
                if (c instanceof je) t = c, r = c.children.length; else {
                    l = c, r--;
                    break
                }
            } else {
                if (t == e) break e;
                r = t.parent.children.indexOf(t), t = t.parent
            }
            let a = l.node;
            if (a) {
                if (a != n.child(i - 1)) break;
                --i, s.set(l, i), o.push(l)
            }
        }
        return {index: i, matched: s, matches: o.reverse()}
    }

    function Ga(n, e) {
        return n.type.side - e.type.side
    }

    function _a(n, e, t, r) {
        let i = e.locals(n), s = 0;
        if (i.length == 0) {
            for (let c = 0; c < n.childCount; c++) {
                let f = n.child(c);
                r(f, i, e.forChild(s, f), c), s += f.nodeSize
            }
            return
        }
        let o = 0, l = [], a = null;
        for (let c = 0; ;) {
            let f, h;
            for (; o < i.length && i[o].to == s;) {
                let g = i[o++];
                g.widget && (f ? (h || (h = [f])).push(g) : f = g)
            }
            if (f) if (h) {
                h.sort(Ga);
                for (let g = 0; g < h.length; g++) t(h[g], c, !!a)
            } else t(f, c, !!a);
            let d, u;
            if (a) u = -1, d = a, a = null; else if (c < n.childCount) u = c, d = n.child(c++); else break;
            for (let g = 0; g < l.length; g++) l[g].to <= s && l.splice(g--, 1);
            for (; o < i.length && i[o].from <= s && i[o].to > s;) l.push(i[o++]);
            let p = s + d.nodeSize;
            if (d.isText) {
                let g = p;
                o < i.length && i[o].from < g && (g = i[o].from);
                for (let b = 0; b < l.length; b++) l[b].to < g && (g = l[b].to);
                g < p && (a = d.cut(g - s), d = d.cut(0, g - s), p = g, u = -1)
            } else for (; o < i.length && i[o].to < p;) o++;
            let m = d.isInline && !d.isLeaf ? l.filter(g => !g.inline) : l.slice();
            r(d, m, e.forChild(s, d), u), s = p
        }
    }

    function Xa(n) {
        if (n.nodeName == "UL" || n.nodeName == "OL") {
            let e = n.style.cssText;
            n.style.cssText = e + "; list-style: square !important", window.getComputedStyle(n).listStyle, n.style.cssText = e
        }
    }

    function Ya(n, e, t, r) {
        for (let i = 0, s = 0; i < n.childCount && s <= r;) {
            let o = n.child(i++), l = s;
            if (s += o.nodeSize, !o.isText) continue;
            let a = o.text;
            for (; i < n.childCount;) {
                let c = n.child(i++);
                if (s += c.nodeSize, !c.isText) break;
                a += c.text
            }
            if (s >= t) {
                if (s >= r && a.slice(r - e.length - l, r - l) == e) return r - e.length;
                let c = l < r ? a.lastIndexOf(e, r - l - 1) : -1;
                if (c >= 0 && c + e.length + l >= t) return l + c;
                if (t == r && a.length >= r + e.length - l && a.slice(r - l, r - l + e.length) == e) return r
            }
        }
        return -1
    }

    function er(n, e, t, r, i) {
        let s = [];
        for (let o = 0, l = 0; o < n.length; o++) {
            let a = n[o], c = l, f = l += a.size;
            c >= t || f <= e ? s.push(a) : (c < e && s.push(a.slice(0, e - c, r)), i && (s.push(i), i = void 0), f > t && s.push(a.slice(t - c, a.size, r)))
        }
        return s
    }

    function tr(n, e = null) {
        let t = n.domSelectionRange(), r = n.state.doc;
        if (!t.focusNode) return null;
        let i = n.docView.nearestDesc(t.focusNode), s = i && i.size == 0,
            o = n.docView.posFromDOM(t.focusNode, t.focusOffset, 1);
        if (o < 0) return null;
        let l = r.resolve(o), a, c;
        if (sn(t)) {
            for (a = o; i && !i.node;) i = i.parent;
            let h = i.node;
            if (i && h.isAtom && k.isSelectable(h) && i.parent && !(h.isInline && wa(t.focusNode, t.focusOffset, i.dom))) {
                let d = i.posBefore;
                c = new k(o == d ? l : r.resolve(d))
            }
        } else {
            if (t instanceof n.dom.ownerDocument.defaultView.Selection && t.rangeCount > 1) {
                let h = o, d = o;
                for (let u = 0; u < t.rangeCount; u++) {
                    let p = t.getRangeAt(u);
                    h = Math.min(h, n.docView.posFromDOM(p.startContainer, p.startOffset, 1)), d = Math.max(d, n.docView.posFromDOM(p.endContainer, p.endOffset, -1))
                }
                if (h < 0) return null;
                [a, o] = d == n.state.selection.anchor ? [d, h] : [h, d], l = r.resolve(o)
            } else a = n.docView.posFromDOM(t.anchorNode, t.anchorOffset, 1);
            if (a < 0) return null
        }
        let f = r.resolve(a);
        if (!c) {
            let h = e == "pointer" || n.state.selection.head < l.pos && !s ? 1 : -1;
            c = rr(n, f, l, h)
        }
        return c
    }

    function ps(n) {
        return n.editable ? n.hasFocus() : Ss(n) && document.activeElement && document.activeElement.contains(n.dom)
    }

    function ue(n, e = !1) {
        let t = n.state.selection;
        if (bs(n, t), !!ps(n)) {
            if (!e && n.input.mouseDown && n.input.mouseDown.allowDefault && $) {
                let r = n.domSelectionRange(), i = n.domObserver.currentSelection;
                if (r.anchorNode && i.anchorNode && Je(r.anchorNode, r.anchorOffset, i.anchorNode, i.anchorOffset)) {
                    n.input.mouseDown.delayedSelectionSync = !0, n.domObserver.setCurSelection();
                    return
                }
            }
            if (n.domObserver.disconnectSelection(), n.cursorWrapper) Qa(n); else {
                let {anchor: r, head: i} = t, s, o;
                ms && !(t instanceof C) && (t.$from.parent.inlineContent || (s = gs(n, t.from)), !t.empty && !t.$from.parent.inlineContent && (o = gs(n, t.to))), n.docView.setSelection(r, i, n, e), ms && (s && ys(s), o && ys(o)), t.visible ? n.dom.classList.remove("ProseMirror-hideselection") : (n.dom.classList.add("ProseMirror-hideselection"), "onselectionchange" in document && Za(n))
            }
            n.domObserver.setCurSelection(), n.domObserver.connectSelection()
        }
    }

    const ms = J || $ && Ui < 63;

    function gs(n, e) {
        let {node: t, offset: r} = n.docView.domFromPos(e, 0), i = r < t.childNodes.length ? t.childNodes[r] : null,
            s = r ? t.childNodes[r - 1] : null;
        if (J && i && i.contentEditable == "false") return nr(i);
        if ((!i || i.contentEditable == "false") && (!s || s.contentEditable == "false")) {
            if (i) return nr(i);
            if (s) return nr(s)
        }
    }

    function nr(n) {
        return n.contentEditable = "true", J && n.draggable && (n.draggable = !1, n.wasDraggable = !0), n
    }

    function ys(n) {
        n.contentEditable = "false", n.wasDraggable && (n.draggable = !0, n.wasDraggable = null)
    }

    function Za(n) {
        let e = n.dom.ownerDocument;
        e.removeEventListener("selectionchange", n.input.hideSelectionGuard);
        let t = n.domSelectionRange(), r = t.anchorNode, i = t.anchorOffset;
        e.addEventListener("selectionchange", n.input.hideSelectionGuard = () => {
            (t.anchorNode != r || t.anchorOffset != i) && (e.removeEventListener("selectionchange", n.input.hideSelectionGuard), setTimeout(() => {
                (!ps(n) || n.state.selection.visible) && n.dom.classList.remove("ProseMirror-hideselection")
            }, 20))
        })
    }

    function Qa(n) {
        let e = n.domSelection(), t = document.createRange();
        if (!e) return;
        let r = n.cursorWrapper.dom, i = r.nodeName == "IMG";
        i ? t.setStart(r.parentNode, F(r) + 1) : t.setStart(r, 0), t.collapse(!0), e.removeAllRanges(), e.addRange(t), !i && !n.state.selection.visible && j && Me <= 11 && (r.disabled = !0, r.disabled = !1)
    }

    function bs(n, e) {
        if (e instanceof k) {
            let t = n.docView.descAt(e.from);
            t != n.lastSelectedViewDesc && (xs(n), t && t.selectNode(), n.lastSelectedViewDesc = t)
        } else xs(n)
    }

    function xs(n) {
        n.lastSelectedViewDesc && (n.lastSelectedViewDesc.parent && n.lastSelectedViewDesc.deselectNode(), n.lastSelectedViewDesc = void 0)
    }

    function rr(n, e, t, r) {
        return n.someProp("createSelectionBetween", i => i(n, e, t)) || C.between(e, t, r)
    }

    function ks(n) {
        return n.editable && !n.hasFocus() ? !1 : Ss(n)
    }

    function Ss(n) {
        let e = n.domSelectionRange();
        if (!e.anchorNode) return !1;
        try {
            return n.dom.contains(e.anchorNode.nodeType == 3 ? e.anchorNode.parentNode : e.anchorNode) && (n.editable || n.dom.contains(e.focusNode.nodeType == 3 ? e.focusNode.parentNode : e.focusNode))
        } catch {
            return !1
        }
    }

    function ec(n) {
        let e = n.docView.domFromPos(n.state.selection.anchor, 0), t = n.domSelectionRange();
        return Je(e.node, e.offset, t.anchorNode, t.anchorOffset)
    }

    function ir(n, e) {
        let {$anchor: t, $head: r} = n.selection, i = e > 0 ? t.max(r) : t.min(r),
            s = i.parent.inlineContent ? i.depth ? n.doc.resolve(e > 0 ? i.after() : i.before()) : null : i;
        return s && S.findFrom(s, e)
    }

    function Te(n, e) {
        return n.dispatch(n.state.tr.setSelection(e).scrollIntoView()), !0
    }

    function Cs(n, e, t) {
        let r = n.state.selection;
        if (r instanceof C) if (t.indexOf("s") > -1) {
            let {$head: i} = r, s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter;
            if (!s || s.isText || !s.isLeaf) return !1;
            let o = n.state.doc.resolve(i.pos + s.nodeSize * (e < 0 ? -1 : 1));
            return Te(n, new C(r.$anchor, o))
        } else if (r.empty) {
            if (n.endOfTextblock(e > 0 ? "forward" : "backward")) {
                let i = ir(n.state, e);
                return i && i instanceof k ? Te(n, i) : !1
            } else if (!(Z && t.indexOf("m") > -1)) {
                let i = r.$head, s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter, o;
                if (!s || s.isText) return !1;
                let l = e < 0 ? i.pos - s.nodeSize : i.pos;
                return s.isAtom || (o = n.docView.descAt(l)) && !o.contentDOM ? k.isSelectable(s) ? Te(n, new k(e < 0 ? n.state.doc.resolve(i.pos - s.nodeSize) : i)) : Nt ? Te(n, new C(n.state.doc.resolve(e < 0 ? l : l + s.nodeSize))) : !1 : !1
            }
        } else return !1; else {
            if (r instanceof k && r.node.isInline) return Te(n, new C(e > 0 ? r.$to : r.$from));
            {
                let i = ir(n.state, e);
                return i ? Te(n, i) : !1
            }
        }
    }

    function an(n) {
        return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length
    }

    function Et(n, e) {
        let t = n.pmViewDesc;
        return t && t.size == 0 && (e < 0 || n.nextSibling || n.nodeName != "BR")
    }

    function ft(n, e) {
        return e < 0 ? tc(n) : nc(n)
    }

    function tc(n) {
        let e = n.domSelectionRange(), t = e.focusNode, r = e.focusOffset;
        if (!t) return;
        let i, s, o = !1;
        for (ne && t.nodeType == 1 && r < an(t) && Et(t.childNodes[r], -1) && (o = !0); ;) if (r > 0) {
            if (t.nodeType != 1) break;
            {
                let l = t.childNodes[r - 1];
                if (Et(l, -1)) i = t, s = --r; else if (l.nodeType == 3) t = l, r = t.nodeValue.length; else break
            }
        } else {
            if (ws(t)) break;
            {
                let l = t.previousSibling;
                for (; l && Et(l, -1);) i = t.parentNode, s = F(l), l = l.previousSibling;
                if (l) t = l, r = an(t); else {
                    if (t = t.parentNode, t == n.dom) break;
                    r = 0
                }
            }
        }
        o ? sr(n, t, r) : i && sr(n, i, s)
    }

    function nc(n) {
        let e = n.domSelectionRange(), t = e.focusNode, r = e.focusOffset;
        if (!t) return;
        let i = an(t), s, o;
        for (; ;) if (r < i) {
            if (t.nodeType != 1) break;
            let l = t.childNodes[r];
            if (Et(l, 1)) s = t, o = ++r; else break
        } else {
            if (ws(t)) break;
            {
                let l = t.nextSibling;
                for (; l && Et(l, 1);) s = l.parentNode, o = F(l) + 1, l = l.nextSibling;
                if (l) t = l, r = 0, i = an(t); else {
                    if (t = t.parentNode, t == n.dom) break;
                    r = i = 0
                }
            }
        }
        s && sr(n, s, o)
    }

    function ws(n) {
        let e = n.pmViewDesc;
        return e && e.node && e.node.isBlock
    }

    function rc(n, e) {
        for (; n && e == n.childNodes.length && !Ot(n);) e = F(n) + 1, n = n.parentNode;
        for (; n && e < n.childNodes.length;) {
            let t = n.childNodes[e];
            if (t.nodeType == 3) return t;
            if (t.nodeType == 1 && t.contentEditable == "false") break;
            n = t, e = 0
        }
    }

    function ic(n, e) {
        for (; n && !e && !Ot(n);) e = F(n), n = n.parentNode;
        for (; n && e;) {
            let t = n.childNodes[e - 1];
            if (t.nodeType == 3) return t;
            if (t.nodeType == 1 && t.contentEditable == "false") break;
            n = t, e = n.childNodes.length
        }
    }

    function sr(n, e, t) {
        if (e.nodeType != 3) {
            let s, o;
            (o = rc(e, t)) ? (e = o, t = 0) : (s = ic(e, t)) && (e = s, t = s.nodeValue.length)
        }
        let r = n.domSelection();
        if (!r) return;
        if (sn(r)) {
            let s = document.createRange();
            s.setEnd(e, t), s.setStart(e, t), r.removeAllRanges(), r.addRange(s)
        } else r.extend && r.extend(e, t);
        n.domObserver.setCurSelection();
        let {state: i} = n;
        setTimeout(() => {
            n.state == i && ue(n)
        }, 50)
    }

    function Ms(n, e) {
        let t = n.state.doc.resolve(e);
        if (!($ || Na) && t.parent.inlineContent) {
            let i = n.coordsAtPos(e);
            if (e > t.start()) {
                let s = n.coordsAtPos(e - 1), o = (s.top + s.bottom) / 2;
                if (o > i.top && o < i.bottom && Math.abs(s.left - i.left) > 1) return s.left < i.left ? "ltr" : "rtl"
            }
            if (e < t.end()) {
                let s = n.coordsAtPos(e + 1), o = (s.top + s.bottom) / 2;
                if (o > i.top && o < i.bottom && Math.abs(s.left - i.left) > 1) return s.left > i.left ? "ltr" : "rtl"
            }
        }
        return getComputedStyle(n.dom).direction == "rtl" ? "rtl" : "ltr"
    }

    function Os(n, e, t) {
        let r = n.state.selection;
        if (r instanceof C && !r.empty || t.indexOf("s") > -1 || Z && t.indexOf("m") > -1) return !1;
        let {$from: i, $to: s} = r;
        if (!i.parent.inlineContent || n.endOfTextblock(e < 0 ? "up" : "down")) {
            let o = ir(n.state, e);
            if (o && o instanceof k) return Te(n, o)
        }
        if (!i.parent.inlineContent) {
            let o = e < 0 ? i : s, l = r instanceof _ ? S.near(o, e) : S.findFrom(o, e);
            return l ? Te(n, l) : !1
        }
        return !1
    }

    function Ns(n, e) {
        if (!(n.state.selection instanceof C)) return !0;
        let {$head: t, $anchor: r, empty: i} = n.state.selection;
        if (!t.sameParent(r)) return !0;
        if (!i) return !1;
        if (n.endOfTextblock(e > 0 ? "forward" : "backward")) return !0;
        let s = !t.textOffset && (e < 0 ? t.nodeBefore : t.nodeAfter);
        if (s && !s.isText) {
            let o = n.state.tr;
            return e < 0 ? o.delete(t.pos - s.nodeSize, t.pos) : o.delete(t.pos, t.pos + s.nodeSize), n.dispatch(o), !0
        }
        return !1
    }

    function Ts(n, e, t) {
        n.domObserver.stop(), e.contentEditable = t, n.domObserver.start()
    }

    function sc(n) {
        if (!J || n.state.selection.$head.parentOffset > 0) return !1;
        let {focusNode: e, focusOffset: t} = n.domSelectionRange();
        if (e && e.nodeType == 1 && t == 0 && e.firstChild && e.firstChild.contentEditable == "false") {
            let r = e.firstChild;
            Ts(n, r, "true"), setTimeout(() => Ts(n, r, "false"), 20)
        }
        return !1
    }

    function oc(n) {
        let e = "";
        return n.ctrlKey && (e += "c"), n.metaKey && (e += "m"), n.altKey && (e += "a"), n.shiftKey && (e += "s"), e
    }

    function lc(n, e) {
        let t = e.keyCode, r = oc(e);
        if (t == 8 || Z && t == 72 && r == "c") return Ns(n, -1) || ft(n, -1);
        if (t == 46 && !e.shiftKey || Z && t == 68 && r == "c") return Ns(n, 1) || ft(n, 1);
        if (t == 13 || t == 27) return !0;
        if (t == 37 || Z && t == 66 && r == "c") {
            let i = t == 37 ? Ms(n, n.state.selection.from) == "ltr" ? -1 : 1 : -1;
            return Cs(n, i, r) || ft(n, i)
        } else if (t == 39 || Z && t == 70 && r == "c") {
            let i = t == 39 ? Ms(n, n.state.selection.from) == "ltr" ? 1 : -1 : 1;
            return Cs(n, i, r) || ft(n, i)
        } else {
            if (t == 38 || Z && t == 80 && r == "c") return Os(n, -1, r) || ft(n, -1);
            if (t == 40 || Z && t == 78 && r == "c") return sc(n) || Os(n, 1, r) || ft(n, 1);
            if (r == (Z ? "m" : "c") && (t == 66 || t == 73 || t == 89 || t == 90)) return !0
        }
        return !1
    }

    function As(n, e) {
        n.someProp("transformCopied", u => {
            e = u(e, n)
        });
        let t = [], {content: r, openStart: i, openEnd: s} = e;
        for (; i > 1 && s > 1 && r.childCount == 1 && r.firstChild.childCount == 1;) {
            i--, s--;
            let u = r.firstChild;
            t.push(u.type.name, u.attrs != u.type.defaultAttrs ? u.attrs : null), r = u.content
        }
        let o = n.someProp("clipboardSerializer") || He.fromSchema(n.state.schema), l = Ps(),
            a = l.createElement("div");
        a.appendChild(o.serializeFragment(r, {document: l}));
        let c = a.firstChild, f, h = 0;
        for (; c && c.nodeType == 1 && (f = zs[c.nodeName.toLowerCase()]);) {
            for (let u = f.length - 1; u >= 0; u--) {
                let p = l.createElement(f[u]);
                for (; a.firstChild;) p.appendChild(a.firstChild);
                a.appendChild(p), h++
            }
            c = a.firstChild
        }
        c && c.nodeType == 1 && c.setAttribute("data-pm-slice", `${i} ${s}${h ? ` -${h}` : ""} ${JSON.stringify(t)}`);
        let d = n.someProp("clipboardTextSerializer", u => u(e, n)) || e.content.textBetween(0, e.content.size, `

`);
        return {dom: a, text: d, slice: e}
    }

    function Ds(n, e, t, r, i) {
        let s = i.parent.type.spec.code, o, l;
        if (!t && !e) return null;
        let a = e && (r || s || !t);
        if (a) {
            if (n.someProp("transformPastedText", d => {
                e = d(e, s || r, n)
            }), s) return e ? new x(y.from(n.state.schema.text(e.replace(/\r\n?/g, `
`))), 0, 0) : x.empty;
            let h = n.someProp("clipboardTextParser", d => d(e, i, r, n));
            if (h) l = h; else {
                let d = i.marks(), {schema: u} = n.state, p = He.fromSchema(u);
                o = document.createElement("div"), e.split(/(?:\r\n?|\n)+/).forEach(m => {
                    let g = o.appendChild(document.createElement("p"));
                    m && g.appendChild(p.serializeNode(u.text(m, d)))
                })
            }
        } else n.someProp("transformPastedHTML", h => {
            t = h(t, n)
        }), o = hc(t), Nt && dc(o);
        let c = o && o.querySelector("[data-pm-slice]"),
            f = c && /^(\d+) (\d+)(?: -(\d+))? (.*)/.exec(c.getAttribute("data-pm-slice") || "");
        if (f && f[3]) for (let h = +f[3]; h > 0; h--) {
            let d = o.firstChild;
            for (; d && d.nodeType != 1;) d = d.nextSibling;
            if (!d) break;
            o = d
        }
        if (l || (l = (n.someProp("clipboardParser") || n.someProp("domParser") || Ze.fromSchema(n.state.schema)).parseSlice(o, {
            preserveWhitespace: !!(a || f),
            context: i,
            ruleFromNode(d) {
                return d.nodeName == "BR" && !d.nextSibling && d.parentNode && !ac.test(d.parentNode.nodeName) ? {ignore: !0} : null
            }
        })), f) l = uc(vs(l, +f[1], +f[2]), f[4]); else if (l = x.maxOpen(cc(l.content, i), !0), l.openStart || l.openEnd) {
            let h = 0, d = 0;
            for (let u = l.content.firstChild; h < l.openStart && !u.type.spec.isolating; h++, u = u.firstChild) ;
            for (let u = l.content.lastChild; d < l.openEnd && !u.type.spec.isolating; d++, u = u.lastChild) ;
            l = vs(l, h, d)
        }
        return n.someProp("transformPasted", h => {
            l = h(l, n)
        }), l
    }

    const ac = /^(a|abbr|acronym|b|cite|code|del|em|i|ins|kbd|label|output|q|ruby|s|samp|span|strong|sub|sup|time|u|tt|var)$/i;

    function cc(n, e) {
        if (n.childCount < 2) return n;
        for (let t = e.depth; t >= 0; t--) {
            let i = e.node(t).contentMatchAt(e.index(t)), s, o = [];
            if (n.forEach(l => {
                if (!o) return;
                let a = i.findWrapping(l.type), c;
                if (!a) return o = null;
                if (c = o.length && s.length && Rs(a, s, l, o[o.length - 1], 0)) o[o.length - 1] = c; else {
                    o.length && (o[o.length - 1] = Is(o[o.length - 1], s.length));
                    let f = Es(l, a);
                    o.push(f), i = i.matchType(f.type), s = a
                }
            }), o) return y.from(o)
        }
        return n
    }

    function Es(n, e, t = 0) {
        for (let r = e.length - 1; r >= t; r--) n = e[r].create(null, y.from(n));
        return n
    }

    function Rs(n, e, t, r, i) {
        if (i < n.length && i < e.length && n[i] == e[i]) {
            let s = Rs(n, e, t, r.lastChild, i + 1);
            if (s) return r.copy(r.content.replaceChild(r.childCount - 1, s));
            if (r.contentMatchAt(r.childCount).matchType(i == n.length - 1 ? t.type : n[i + 1])) return r.copy(r.content.append(y.from(Es(t, n, i + 1))))
        }
    }

    function Is(n, e) {
        if (e == 0) return n;
        let t = n.content.replaceChild(n.childCount - 1, Is(n.lastChild, e - 1)),
            r = n.contentMatchAt(n.childCount).fillBefore(y.empty, !0);
        return n.copy(t.append(r))
    }

    function or(n, e, t, r, i, s) {
        let o = e < 0 ? n.firstChild : n.lastChild, l = o.content;
        return n.childCount > 1 && (s = 0), i < r - 1 && (l = or(l, e, t, r, i + 1, s)), i >= t && (l = e < 0 ? o.contentMatchAt(0).fillBefore(l, s <= i).append(l) : l.append(o.contentMatchAt(o.childCount).fillBefore(y.empty, !0))), n.replaceChild(e < 0 ? 0 : n.childCount - 1, o.copy(l))
    }

    function vs(n, e, t) {
        return e < n.openStart && (n = new x(or(n.content, -1, e, n.openStart, 0, n.openEnd), e, n.openEnd)), t < n.openEnd && (n = new x(or(n.content, 1, t, n.openEnd, 0, 0), n.openStart, t)), n
    }

    const zs = {
        thead: ["table"],
        tbody: ["table"],
        tfoot: ["table"],
        caption: ["table"],
        colgroup: ["table"],
        col: ["table", "colgroup"],
        tr: ["table", "tbody"],
        td: ["table", "tbody", "tr"],
        th: ["table", "tbody", "tr"]
    };
    let Bs = null;

    function Ps() {
        return Bs || (Bs = document.implementation.createHTMLDocument("title"))
    }

    let lr = null;

    function fc(n) {
        let e = window.trustedTypes;
        return e ? (lr || (lr = e.createPolicy("ProseMirrorClipboard", {createHTML: t => t})), lr.createHTML(n)) : n
    }

    function hc(n) {
        let e = /^(\s*<meta [^>]*>)*/.exec(n);
        e && (n = n.slice(e[0].length));
        let t = Ps().createElement("div"), r = /<([a-z][^>\s]+)/i.exec(n), i;
        if ((i = r && zs[r[1].toLowerCase()]) && (n = i.map(s => "<" + s + ">").join("") + n + i.map(s => "</" + s + ">").reverse().join("")), t.innerHTML = fc(n), i) for (let s = 0; s < i.length; s++) t = t.querySelector(i[s]) || t;
        return t
    }

    function dc(n) {
        let e = n.querySelectorAll($ ? "span:not([class]):not([style])" : "span.Apple-converted-space");
        for (let t = 0; t < e.length; t++) {
            let r = e[t];
            r.childNodes.length == 1 && r.textContent == " " && r.parentNode && r.parentNode.replaceChild(n.ownerDocument.createTextNode(" "), r)
        }
    }

    function uc(n, e) {
        if (!n.size) return n;
        let t = n.content.firstChild.type.schema, r;
        try {
            r = JSON.parse(e)
        } catch {
            return n
        }
        let {content: i, openStart: s, openEnd: o} = n;
        for (let l = r.length - 2; l >= 0; l -= 2) {
            let a = t.nodes[r[l]];
            if (!a || a.hasRequiredAttrs()) break;
            i = y.from(a.create(r[l + 1], i)), s++, o++
        }
        return new x(i, s, o)
    }

    const q = {}, K = {}, pc = {touchstart: !0, touchmove: !0};

    class mc {
        constructor() {
            this.shiftKey = !1, this.mouseDown = null, this.lastKeyCode = null, this.lastKeyCodeTime = 0, this.lastClick = {
                time: 0,
                x: 0,
                y: 0,
                type: ""
            }, this.lastSelectionOrigin = null, this.lastSelectionTime = 0, this.lastIOSEnter = 0, this.lastIOSEnterFallbackTimeout = -1, this.lastFocus = 0, this.lastTouch = 0, this.lastAndroidDelete = 0, this.composing = !1, this.compositionNode = null, this.composingTimeout = -1, this.compositionNodes = [], this.compositionEndedAt = -2e8, this.compositionID = 1, this.compositionPendingChanges = 0, this.domChangeCount = 0, this.eventHandlers = Object.create(null), this.hideSelectionGuard = null
        }
    }

    function gc(n) {
        for (let e in q) {
            let t = q[e];
            n.dom.addEventListener(e, n.input.eventHandlers[e] = r => {
                bc(n, r) && !cr(n, r) && (n.editable || !(r.type in K)) && t(n, r)
            }, pc[e] ? {passive: !0} : void 0)
        }
        J && n.dom.addEventListener("input", () => null), ar(n)
    }

    function Ae(n, e) {
        n.input.lastSelectionOrigin = e, n.input.lastSelectionTime = Date.now()
    }

    function yc(n) {
        n.domObserver.stop();
        for (let e in n.input.eventHandlers) n.dom.removeEventListener(e, n.input.eventHandlers[e]);
        clearTimeout(n.input.composingTimeout), clearTimeout(n.input.lastIOSEnterFallbackTimeout)
    }

    function ar(n) {
        n.someProp("handleDOMEvents", e => {
            for (let t in e) n.input.eventHandlers[t] || n.dom.addEventListener(t, n.input.eventHandlers[t] = r => cr(n, r))
        })
    }

    function cr(n, e) {
        return n.someProp("handleDOMEvents", t => {
            let r = t[e.type];
            return r ? r(n, e) || e.defaultPrevented : !1
        })
    }

    function bc(n, e) {
        if (!e.bubbles) return !0;
        if (e.defaultPrevented) return !1;
        for (let t = e.target; t != n.dom; t = t.parentNode) if (!t || t.nodeType == 11 || t.pmViewDesc && t.pmViewDesc.stopEvent(e)) return !1;
        return !0
    }

    function xc(n, e) {
        !cr(n, e) && q[e.type] && (n.editable || !(e.type in K)) && q[e.type](n, e)
    }

    K.keydown = (n, e) => {
        let t = e;
        if (n.input.shiftKey = t.keyCode == 16 || t.shiftKey, !Fs(n, t) && (n.input.lastKeyCode = t.keyCode, n.input.lastKeyCodeTime = Date.now(), !(re && $ && t.keyCode == 13))) if (t.keyCode != 229 && n.domObserver.forceFlush(), at && t.keyCode == 13 && !t.ctrlKey && !t.altKey && !t.metaKey) {
            let r = Date.now();
            n.input.lastIOSEnter = r, n.input.lastIOSEnterFallbackTimeout = setTimeout(() => {
                n.input.lastIOSEnter == r && (n.someProp("handleKeyDown", i => i(n, qe(13, "Enter"))), n.input.lastIOSEnter = 0)
            }, 200)
        } else n.someProp("handleKeyDown", r => r(n, t)) || lc(n, t) ? t.preventDefault() : Ae(n, "key")
    }, K.keyup = (n, e) => {
        e.keyCode == 16 && (n.input.shiftKey = !1)
    }, K.keypress = (n, e) => {
        let t = e;
        if (Fs(n, t) || !t.charCode || t.ctrlKey && !t.altKey || Z && t.metaKey) return;
        if (n.someProp("handleKeyPress", i => i(n, t))) {
            t.preventDefault();
            return
        }
        let r = n.state.selection;
        if (!(r instanceof C) || !r.$from.sameParent(r.$to)) {
            let i = String.fromCharCode(t.charCode);
            !/[\r\n]/.test(i) && !n.someProp("handleTextInput", s => s(n, r.$from.pos, r.$to.pos, i)) && n.dispatch(n.state.tr.insertText(i).scrollIntoView()), t.preventDefault()
        }
    };

    function cn(n) {
        return {left: n.clientX, top: n.clientY}
    }

    function kc(n, e) {
        let t = e.x - n.clientX, r = e.y - n.clientY;
        return t * t + r * r < 100
    }

    function fr(n, e, t, r, i) {
        if (r == -1) return !1;
        let s = n.state.doc.resolve(r);
        for (let o = s.depth + 1; o > 0; o--) if (n.someProp(e, l => o > s.depth ? l(n, t, s.nodeAfter, s.before(o), i, !0) : l(n, t, s.node(o), s.before(o), i, !1))) return !0;
        return !1
    }

    function ht(n, e, t) {
        if (n.focused || n.focus(), n.state.selection.eq(e)) return;
        let r = n.state.tr.setSelection(e);
        r.setMeta("pointer", !0), n.dispatch(r)
    }

    function Sc(n, e) {
        if (e == -1) return !1;
        let t = n.state.doc.resolve(e), r = t.nodeAfter;
        return r && r.isAtom && k.isSelectable(r) ? (ht(n, new k(t)), !0) : !1
    }

    function Cc(n, e) {
        if (e == -1) return !1;
        let t = n.state.selection, r, i;
        t instanceof k && (r = t.node);
        let s = n.state.doc.resolve(e);
        for (let o = s.depth + 1; o > 0; o--) {
            let l = o > s.depth ? s.nodeAfter : s.node(o);
            if (k.isSelectable(l)) {
                r && t.$from.depth > 0 && o >= t.$from.depth && s.before(t.$from.depth + 1) == t.$from.pos ? i = s.before(t.$from.depth) : i = s.before(o);
                break
            }
        }
        return i != null ? (ht(n, k.create(n.state.doc, i)), !0) : !1
    }

    function wc(n, e, t, r, i) {
        return fr(n, "handleClickOn", e, t, r) || n.someProp("handleClick", s => s(n, e, r)) || (i ? Cc(n, t) : Sc(n, t))
    }

    function Mc(n, e, t, r) {
        return fr(n, "handleDoubleClickOn", e, t, r) || n.someProp("handleDoubleClick", i => i(n, e, r))
    }

    function Oc(n, e, t, r) {
        return fr(n, "handleTripleClickOn", e, t, r) || n.someProp("handleTripleClick", i => i(n, e, r)) || Nc(n, t, r)
    }

    function Nc(n, e, t) {
        if (t.button != 0) return !1;
        let r = n.state.doc;
        if (e == -1) return r.inlineContent ? (ht(n, C.create(r, 0, r.content.size)), !0) : !1;
        let i = r.resolve(e);
        for (let s = i.depth + 1; s > 0; s--) {
            let o = s > i.depth ? i.nodeAfter : i.node(s), l = i.before(s);
            if (o.inlineContent) ht(n, C.create(r, l + 1, l + 1 + o.content.size)); else if (k.isSelectable(o)) ht(n, k.create(r, l)); else continue;
            return !0
        }
    }

    function hr(n) {
        return fn(n)
    }

    const Vs = Z ? "metaKey" : "ctrlKey";
    q.mousedown = (n, e) => {
        let t = e;
        n.input.shiftKey = t.shiftKey;
        let r = hr(n), i = Date.now(), s = "singleClick";
        i - n.input.lastClick.time < 500 && kc(t, n.input.lastClick) && !t[Vs] && (n.input.lastClick.type == "singleClick" ? s = "doubleClick" : n.input.lastClick.type == "doubleClick" && (s = "tripleClick")), n.input.lastClick = {
            time: i,
            x: t.clientX,
            y: t.clientY,
            type: s
        };
        let o = n.posAtCoords(cn(t));
        o && (s == "singleClick" ? (n.input.mouseDown && n.input.mouseDown.done(), n.input.mouseDown = new Tc(n, o, t, !!r)) : (s == "doubleClick" ? Mc : Oc)(n, o.pos, o.inside, t) ? t.preventDefault() : Ae(n, "pointer"))
    };

    class Tc {
        constructor(e, t, r, i) {
            this.view = e, this.pos = t, this.event = r, this.flushed = i, this.delayedSelectionSync = !1, this.mightDrag = null, this.startDoc = e.state.doc, this.selectNode = !!r[Vs], this.allowDefault = r.shiftKey;
            let s, o;
            if (t.inside > -1) s = e.state.doc.nodeAt(t.inside), o = t.inside; else {
                let f = e.state.doc.resolve(t.pos);
                s = f.parent, o = f.depth ? f.before() : 0
            }
            const l = i ? null : r.target, a = l ? e.docView.nearestDesc(l, !0) : null;
            this.target = a && a.dom.nodeType == 1 ? a.dom : null;
            let {selection: c} = e.state;
            (r.button == 0 && s.type.spec.draggable && s.type.spec.selectable !== !1 || c instanceof k && c.from <= o && c.to > o) && (this.mightDrag = {
                node: s,
                pos: o,
                addAttr: !!(this.target && !this.target.draggable),
                setUneditable: !!(this.target && ne && !this.target.hasAttribute("contentEditable"))
            }), this.target && this.mightDrag && (this.mightDrag.addAttr || this.mightDrag.setUneditable) && (this.view.domObserver.stop(), this.mightDrag.addAttr && (this.target.draggable = !0), this.mightDrag.setUneditable && setTimeout(() => {
                this.view.input.mouseDown == this && this.target.setAttribute("contentEditable", "false")
            }, 20), this.view.domObserver.start()), e.root.addEventListener("mouseup", this.up = this.up.bind(this)), e.root.addEventListener("mousemove", this.move = this.move.bind(this)), Ae(e, "pointer")
        }

        done() {
            this.view.root.removeEventListener("mouseup", this.up), this.view.root.removeEventListener("mousemove", this.move), this.mightDrag && this.target && (this.view.domObserver.stop(), this.mightDrag.addAttr && this.target.removeAttribute("draggable"), this.mightDrag.setUneditable && this.target.removeAttribute("contentEditable"), this.view.domObserver.start()), this.delayedSelectionSync && setTimeout(() => ue(this.view)), this.view.input.mouseDown = null
        }

        up(e) {
            if (this.done(), !this.view.dom.contains(e.target)) return;
            let t = this.pos;
            this.view.state.doc != this.startDoc && (t = this.view.posAtCoords(cn(e))), this.updateAllowDefault(e), this.allowDefault || !t ? Ae(this.view, "pointer") : wc(this.view, t.pos, t.inside, e, this.selectNode) ? e.preventDefault() : e.button == 0 && (this.flushed || J && this.mightDrag && !this.mightDrag.node.isAtom || $ && !this.view.state.selection.visible && Math.min(Math.abs(t.pos - this.view.state.selection.from), Math.abs(t.pos - this.view.state.selection.to)) <= 2) ? (ht(this.view, S.near(this.view.state.doc.resolve(t.pos))), e.preventDefault()) : Ae(this.view, "pointer")
        }

        move(e) {
            this.updateAllowDefault(e), Ae(this.view, "pointer"), e.buttons == 0 && this.done()
        }

        updateAllowDefault(e) {
            !this.allowDefault && (Math.abs(this.event.x - e.clientX) > 4 || Math.abs(this.event.y - e.clientY) > 4) && (this.allowDefault = !0)
        }
    }

    q.touchstart = n => {
        n.input.lastTouch = Date.now(), hr(n), Ae(n, "pointer")
    }, q.touchmove = n => {
        n.input.lastTouch = Date.now(), Ae(n, "pointer")
    }, q.contextmenu = n => hr(n);

    function Fs(n, e) {
        return n.composing ? !0 : J && Math.abs(e.timeStamp - n.input.compositionEndedAt) < 500 ? (n.input.compositionEndedAt = -2e8, !0) : !1
    }

    const Ac = re ? 5e3 : -1;
    K.compositionstart = K.compositionupdate = n => {
        if (!n.composing) {
            n.domObserver.flush();
            let {state: e} = n, t = e.selection.$to;
            if (e.selection instanceof C && (e.storedMarks || !t.textOffset && t.parentOffset && t.nodeBefore.marks.some(r => r.type.spec.inclusive === !1))) n.markCursor = n.state.storedMarks || t.marks(), fn(n, !0), n.markCursor = null; else if (fn(n, !e.selection.empty), ne && e.selection.empty && t.parentOffset && !t.textOffset && t.nodeBefore.marks.length) {
                let r = n.domSelectionRange();
                for (let i = r.focusNode, s = r.focusOffset; i && i.nodeType == 1 && s != 0;) {
                    let o = s < 0 ? i.lastChild : i.childNodes[s - 1];
                    if (!o) break;
                    if (o.nodeType == 3) {
                        let l = n.domSelection();
                        l && l.collapse(o, o.nodeValue.length);
                        break
                    } else i = o, s = -1
                }
            }
            n.input.composing = !0
        }
        Ls(n, Ac)
    }, K.compositionend = (n, e) => {
        n.composing && (n.input.composing = !1, n.input.compositionEndedAt = e.timeStamp, n.input.compositionPendingChanges = n.domObserver.pendingRecords().length ? n.input.compositionID : 0, n.input.compositionNode = null, n.input.compositionPendingChanges && Promise.resolve().then(() => n.domObserver.flush()), n.input.compositionID++, Ls(n, 20))
    };

    function Ls(n, e) {
        clearTimeout(n.input.composingTimeout), e > -1 && (n.input.composingTimeout = setTimeout(() => fn(n), e))
    }

    function Hs(n) {
        for (n.composing && (n.input.composing = !1, n.input.compositionEndedAt = Ec()); n.input.compositionNodes.length > 0;) n.input.compositionNodes.pop().markParentsDirty()
    }

    function Dc(n) {
        let e = n.domSelectionRange();
        if (!e.focusNode) return null;
        let t = Sa(e.focusNode, e.focusOffset), r = Ca(e.focusNode, e.focusOffset);
        if (t && r && t != r) {
            let i = r.pmViewDesc, s = n.domObserver.lastChangedTextNode;
            if (t == s || r == s) return s;
            if (!i || !i.isText(r.nodeValue)) return r;
            if (n.input.compositionNode == r) {
                let o = t.pmViewDesc;
                if (!(!o || !o.isText(t.nodeValue))) return r
            }
        }
        return t || r
    }

    function Ec() {
        let n = document.createEvent("Event");
        return n.initEvent("event", !0, !0), n.timeStamp
    }

    function fn(n, e = !1) {
        if (!(re && n.domObserver.flushingSoon >= 0)) {
            if (n.domObserver.forceFlush(), Hs(n), e || n.docView && n.docView.dirty) {
                let t = tr(n);
                return t && !t.eq(n.state.selection) ? n.dispatch(n.state.tr.setSelection(t)) : (n.markCursor || e) && !n.state.selection.empty ? n.dispatch(n.state.tr.deleteSelection()) : n.updateState(n.state), !0
            }
            return !1
        }
    }

    function Rc(n, e) {
        if (!n.dom.parentNode) return;
        let t = n.dom.parentNode.appendChild(document.createElement("div"));
        t.appendChild(e), t.style.cssText = "position: fixed; left: -10000px; top: 10px";
        let r = getSelection(), i = document.createRange();
        i.selectNodeContents(e), n.dom.blur(), r.removeAllRanges(), r.addRange(i), setTimeout(() => {
            t.parentNode && t.parentNode.removeChild(t), n.focus()
        }, 50)
    }

    const Rt = j && Me < 15 || at && Ta < 604;
    q.copy = K.cut = (n, e) => {
        let t = e, r = n.state.selection, i = t.type == "cut";
        if (r.empty) return;
        let s = Rt ? null : t.clipboardData, o = r.content(), {dom: l, text: a} = As(n, o);
        s ? (t.preventDefault(), s.clearData(), s.setData("text/html", l.innerHTML), s.setData("text/plain", a)) : Rc(n, l), i && n.dispatch(n.state.tr.deleteSelection().scrollIntoView().setMeta("uiEvent", "cut"))
    };

    function Ic(n) {
        return n.openStart == 0 && n.openEnd == 0 && n.content.childCount == 1 ? n.content.firstChild : null
    }

    function vc(n, e) {
        if (!n.dom.parentNode) return;
        let t = n.input.shiftKey || n.state.selection.$from.parent.type.spec.code,
            r = n.dom.parentNode.appendChild(document.createElement(t ? "textarea" : "div"));
        t || (r.contentEditable = "true"), r.style.cssText = "position: fixed; left: -10000px; top: 10px", r.focus();
        let i = n.input.shiftKey && n.input.lastKeyCode != 45;
        setTimeout(() => {
            n.focus(), r.parentNode && r.parentNode.removeChild(r), t ? It(n, r.value, null, i, e) : It(n, r.textContent, r.innerHTML, i, e)
        }, 50)
    }

    function It(n, e, t, r, i) {
        let s = Ds(n, e, t, r, n.state.selection.$from);
        if (n.someProp("handlePaste", a => a(n, i, s || x.empty))) return !0;
        if (!s) return !1;
        let o = Ic(s), l = o ? n.state.tr.replaceSelectionWith(o, r) : n.state.tr.replaceSelection(s);
        return n.dispatch(l.scrollIntoView().setMeta("paste", !0).setMeta("uiEvent", "paste")), !0
    }

    function $s(n) {
        let e = n.getData("text/plain") || n.getData("Text");
        if (e) return e;
        let t = n.getData("text/uri-list");
        return t ? t.replace(/\r?\n/g, " ") : ""
    }

    K.paste = (n, e) => {
        let t = e;
        if (n.composing && !re) return;
        let r = Rt ? null : t.clipboardData, i = n.input.shiftKey && n.input.lastKeyCode != 45;
        r && It(n, $s(r), r.getData("text/html"), i, t) ? t.preventDefault() : vc(n, t)
    };

    class Ws {
        constructor(e, t, r) {
            this.slice = e, this.move = t, this.node = r
        }
    }

    const Js = Z ? "altKey" : "ctrlKey";
    q.dragstart = (n, e) => {
        let t = e, r = n.input.mouseDown;
        if (r && r.done(), !t.dataTransfer) return;
        let i = n.state.selection, s = i.empty ? null : n.posAtCoords(cn(t)), o;
        if (!(s && s.pos >= i.from && s.pos <= (i instanceof k ? i.to - 1 : i.to))) {
            if (r && r.mightDrag) o = k.create(n.state.doc, r.mightDrag.pos); else if (t.target && t.target.nodeType == 1) {
                let h = n.docView.nearestDesc(t.target, !0);
                h && h.node.type.spec.draggable && h != n.docView && (o = k.create(n.state.doc, h.posBefore))
            }
        }
        let l = (o || n.state.selection).content(), {dom: a, text: c, slice: f} = As(n, l);
        (!t.dataTransfer.files.length || !$ || Ui > 120) && t.dataTransfer.clearData(), t.dataTransfer.setData(Rt ? "Text" : "text/html", a.innerHTML), t.dataTransfer.effectAllowed = "copyMove", Rt || t.dataTransfer.setData("text/plain", c), n.dragging = new Ws(f, !t[Js], o)
    }, q.dragend = n => {
        let e = n.dragging;
        window.setTimeout(() => {
            n.dragging == e && (n.dragging = null)
        }, 50)
    }, K.dragover = K.dragenter = (n, e) => e.preventDefault(), K.drop = (n, e) => {
        let t = e, r = n.dragging;
        if (n.dragging = null, !t.dataTransfer) return;
        let i = n.posAtCoords(cn(t));
        if (!i) return;
        let s = n.state.doc.resolve(i.pos), o = r && r.slice;
        o ? n.someProp("transformPasted", p => {
            o = p(o, n)
        }) : o = Ds(n, $s(t.dataTransfer), Rt ? null : t.dataTransfer.getData("text/html"), !1, s);
        let l = !!(r && !t[Js]);
        if (n.someProp("handleDrop", p => p(n, t, o || x.empty, l))) {
            t.preventDefault();
            return
        }
        if (!o) return;
        t.preventDefault();
        let a = o ? Al(n.state.doc, s.pos, o) : s.pos;
        a == null && (a = s.pos);
        let c = n.state.tr;
        if (l) {
            let {node: p} = r;
            p ? p.replace(c) : c.deleteSelection()
        }
        let f = c.mapping.map(a), h = o.openStart == 0 && o.openEnd == 0 && o.content.childCount == 1, d = c.doc;
        if (h ? c.replaceRangeWith(f, f, o.content.firstChild) : c.replaceRange(f, f, o), c.doc.eq(d)) return;
        let u = c.doc.resolve(f);
        if (h && k.isSelectable(o.content.firstChild) && u.nodeAfter && u.nodeAfter.sameMarkup(o.content.firstChild)) c.setSelection(new k(u)); else {
            let p = c.mapping.map(a);
            c.mapping.maps[c.mapping.maps.length - 1].forEach((m, g, b, w) => p = w), c.setSelection(rr(n, u, c.doc.resolve(p)))
        }
        n.focus(), n.dispatch(c.setMeta("uiEvent", "drop"))
    }, q.focus = n => {
        n.input.lastFocus = Date.now(), n.focused || (n.domObserver.stop(), n.dom.classList.add("ProseMirror-focused"), n.domObserver.start(), n.focused = !0, setTimeout(() => {
            n.docView && n.hasFocus() && !n.domObserver.currentSelection.eq(n.domSelectionRange()) && ue(n)
        }, 20))
    }, q.blur = (n, e) => {
        let t = e;
        n.focused && (n.domObserver.stop(), n.dom.classList.remove("ProseMirror-focused"), n.domObserver.start(), t.relatedTarget && n.dom.contains(t.relatedTarget) && n.domObserver.currentSelection.clear(), n.focused = !1)
    }, q.beforeinput = (n, e) => {
        if ($ && re && e.inputType == "deleteContentBackward") {
            n.domObserver.flushSoon();
            let {domChangeCount: r} = n.input;
            setTimeout(() => {
                if (n.input.domChangeCount != r || (n.dom.blur(), n.focus(), n.someProp("handleKeyDown", s => s(n, qe(8, "Backspace"))))) return;
                let {$cursor: i} = n.state.selection;
                i && i.pos > 0 && n.dispatch(n.state.tr.delete(i.pos - 1, i.pos).scrollIntoView())
            }, 50)
        }
    };
    for (let n in K) q[n] = K[n];

    function vt(n, e) {
        if (n == e) return !0;
        for (let t in n) if (n[t] !== e[t]) return !1;
        for (let t in e) if (!(t in n)) return !1;
        return !0
    }

    class hn {
        constructor(e, t) {
            this.toDOM = e, this.spec = t || Ge, this.side = this.spec.side || 0
        }

        map(e, t, r, i) {
            let {pos: s, deleted: o} = e.mapResult(t.from + i, this.side < 0 ? -1 : 1);
            return o ? null : new U(s - r, s - r, this)
        }

        valid() {
            return !0
        }

        eq(e) {
            return this == e || e instanceof hn && (this.spec.key && this.spec.key == e.spec.key || this.toDOM == e.toDOM && vt(this.spec, e.spec))
        }

        destroy(e) {
            this.spec.destroy && this.spec.destroy(e)
        }
    }

    class De {
        constructor(e, t) {
            this.attrs = e, this.spec = t || Ge
        }

        map(e, t, r, i) {
            let s = e.map(t.from + i, this.spec.inclusiveStart ? -1 : 1) - r,
                o = e.map(t.to + i, this.spec.inclusiveEnd ? 1 : -1) - r;
            return s >= o ? null : new U(s, o, this)
        }

        valid(e, t) {
            return t.from < t.to
        }

        eq(e) {
            return this == e || e instanceof De && vt(this.attrs, e.attrs) && vt(this.spec, e.spec)
        }

        static is(e) {
            return e.type instanceof De
        }

        destroy() {
        }
    }

    class dr {
        constructor(e, t) {
            this.attrs = e, this.spec = t || Ge
        }

        map(e, t, r, i) {
            let s = e.mapResult(t.from + i, 1);
            if (s.deleted) return null;
            let o = e.mapResult(t.to + i, -1);
            return o.deleted || o.pos <= s.pos ? null : new U(s.pos - r, o.pos - r, this)
        }

        valid(e, t) {
            let {index: r, offset: i} = e.content.findIndex(t.from), s;
            return i == t.from && !(s = e.child(r)).isText && i + s.nodeSize == t.to
        }

        eq(e) {
            return this == e || e instanceof dr && vt(this.attrs, e.attrs) && vt(this.spec, e.spec)
        }

        destroy() {
        }
    }

    class U {
        constructor(e, t, r) {
            this.from = e, this.to = t, this.type = r
        }

        copy(e, t) {
            return new U(e, t, this.type)
        }

        eq(e, t = 0) {
            return this.type.eq(e.type) && this.from + t == e.from && this.to + t == e.to
        }

        map(e, t, r) {
            return this.type.map(e, this, t, r)
        }

        static widget(e, t, r) {
            return new U(e, e, new hn(t, r))
        }

        static inline(e, t, r, i) {
            return new U(e, t, new De(r, i))
        }

        static node(e, t, r, i) {
            return new U(e, t, new dr(r, i))
        }

        get spec() {
            return this.type.spec
        }

        get inline() {
            return this.type instanceof De
        }

        get widget() {
            return this.type instanceof hn
        }
    }

    const dt = [], Ge = {};

    class A {
        constructor(e, t) {
            this.local = e.length ? e : dt, this.children = t.length ? t : dt
        }

        static create(e, t) {
            return t.length ? dn(t, e, 0, Ge) : W
        }

        find(e, t, r) {
            let i = [];
            return this.findInner(e ?? 0, t ?? 1e9, i, 0, r), i
        }

        findInner(e, t, r, i, s) {
            for (let o = 0; o < this.local.length; o++) {
                let l = this.local[o];
                l.from <= t && l.to >= e && (!s || s(l.spec)) && r.push(l.copy(l.from + i, l.to + i))
            }
            for (let o = 0; o < this.children.length; o += 3) if (this.children[o] < t && this.children[o + 1] > e) {
                let l = this.children[o] + 1;
                this.children[o + 2].findInner(e - l, t - l, r, i + l, s)
            }
        }

        map(e, t, r) {
            return this == W || e.maps.length == 0 ? this : this.mapInner(e, t, 0, 0, r || Ge)
        }

        mapInner(e, t, r, i, s) {
            let o;
            for (let l = 0; l < this.local.length; l++) {
                let a = this.local[l].map(e, r, i);
                a && a.type.valid(t, a) ? (o || (o = [])).push(a) : s.onRemove && s.onRemove(this.local[l].spec)
            }
            return this.children.length ? zc(this.children, o || [], e, t, r, i, s) : o ? new A(o.sort(_e), dt) : W
        }

        add(e, t) {
            return t.length ? this == W ? A.create(e, t) : this.addInner(e, t, 0) : this
        }

        addInner(e, t, r) {
            let i, s = 0;
            e.forEach((l, a) => {
                let c = a + r, f;
                if (f = Ks(t, l, c)) {
                    for (i || (i = this.children.slice()); s < i.length && i[s] < a;) s += 3;
                    i[s] == a ? i[s + 2] = i[s + 2].addInner(l, f, c + 1) : i.splice(s, 0, a, a + l.nodeSize, dn(f, l, c + 1, Ge)), s += 3
                }
            });
            let o = qs(s ? js(t) : t, -r);
            for (let l = 0; l < o.length; l++) o[l].type.valid(e, o[l]) || o.splice(l--, 1);
            return new A(o.length ? this.local.concat(o).sort(_e) : this.local, i || this.children)
        }

        remove(e) {
            return e.length == 0 || this == W ? this : this.removeInner(e, 0)
        }

        removeInner(e, t) {
            let r = this.children, i = this.local;
            for (let s = 0; s < r.length; s += 3) {
                let o, l = r[s] + t, a = r[s + 1] + t;
                for (let f = 0, h; f < e.length; f++) (h = e[f]) && h.from > l && h.to < a && (e[f] = null, (o || (o = [])).push(h));
                if (!o) continue;
                r == this.children && (r = this.children.slice());
                let c = r[s + 2].removeInner(o, l + 1);
                c != W ? r[s + 2] = c : (r.splice(s, 3), s -= 3)
            }
            if (i.length) {
                for (let s = 0, o; s < e.length; s++) if (o = e[s]) for (let l = 0; l < i.length; l++) i[l].eq(o, t) && (i == this.local && (i = this.local.slice()), i.splice(l--, 1))
            }
            return r == this.children && i == this.local ? this : i.length || r.length ? new A(i, r) : W
        }

        forChild(e, t) {
            if (this == W) return this;
            if (t.isLeaf) return A.empty;
            let r, i;
            for (let l = 0; l < this.children.length; l += 3) if (this.children[l] >= e) {
                this.children[l] == e && (r = this.children[l + 2]);
                break
            }
            let s = e + 1, o = s + t.content.size;
            for (let l = 0; l < this.local.length; l++) {
                let a = this.local[l];
                if (a.from < o && a.to > s && a.type instanceof De) {
                    let c = Math.max(s, a.from) - s, f = Math.min(o, a.to) - s;
                    c < f && (i || (i = [])).push(a.copy(c, f))
                }
            }
            if (i) {
                let l = new A(i.sort(_e), dt);
                return r ? new Ee([l, r]) : l
            }
            return r || W
        }

        eq(e) {
            if (this == e) return !0;
            if (!(e instanceof A) || this.local.length != e.local.length || this.children.length != e.children.length) return !1;
            for (let t = 0; t < this.local.length; t++) if (!this.local[t].eq(e.local[t])) return !1;
            for (let t = 0; t < this.children.length; t += 3) if (this.children[t] != e.children[t] || this.children[t + 1] != e.children[t + 1] || !this.children[t + 2].eq(e.children[t + 2])) return !1;
            return !0
        }

        locals(e) {
            return ur(this.localsInner(e))
        }

        localsInner(e) {
            if (this == W) return dt;
            if (e.inlineContent || !this.local.some(De.is)) return this.local;
            let t = [];
            for (let r = 0; r < this.local.length; r++) this.local[r].type instanceof De || t.push(this.local[r]);
            return t
        }

        forEachSet(e) {
            e(this)
        }
    }

    A.empty = new A([], []), A.removeOverlap = ur;
    const W = A.empty;

    class Ee {
        constructor(e) {
            this.members = e
        }

        map(e, t) {
            const r = this.members.map(i => i.map(e, t, Ge));
            return Ee.from(r)
        }

        forChild(e, t) {
            if (t.isLeaf) return A.empty;
            let r = [];
            for (let i = 0; i < this.members.length; i++) {
                let s = this.members[i].forChild(e, t);
                s != W && (s instanceof Ee ? r = r.concat(s.members) : r.push(s))
            }
            return Ee.from(r)
        }

        eq(e) {
            if (!(e instanceof Ee) || e.members.length != this.members.length) return !1;
            for (let t = 0; t < this.members.length; t++) if (!this.members[t].eq(e.members[t])) return !1;
            return !0
        }

        locals(e) {
            let t, r = !0;
            for (let i = 0; i < this.members.length; i++) {
                let s = this.members[i].localsInner(e);
                if (s.length) if (!t) t = s; else {
                    r && (t = t.slice(), r = !1);
                    for (let o = 0; o < s.length; o++) t.push(s[o])
                }
            }
            return t ? ur(r ? t : t.sort(_e)) : dt
        }

        static from(e) {
            switch (e.length) {
                case 0:
                    return W;
                case 1:
                    return e[0];
                default:
                    return new Ee(e.every(t => t instanceof A) ? e : e.reduce((t, r) => t.concat(r instanceof A ? r : r.members), []))
            }
        }

        forEachSet(e) {
            for (let t = 0; t < this.members.length; t++) this.members[t].forEachSet(e)
        }
    }

    function zc(n, e, t, r, i, s, o) {
        let l = n.slice();
        for (let c = 0, f = s; c < t.maps.length; c++) {
            let h = 0;
            t.maps[c].forEach((d, u, p, m) => {
                let g = m - p - (u - d);
                for (let b = 0; b < l.length; b += 3) {
                    let w = l[b + 1];
                    if (w < 0 || d > w + f - h) continue;
                    let N = l[b] + f - h;
                    u >= N ? l[b + 1] = d <= N ? -2 : -1 : d >= f && g && (l[b] += g, l[b + 1] += g)
                }
                h += g
            }), f = t.maps[c].map(f, -1)
        }
        let a = !1;
        for (let c = 0; c < l.length; c += 3) if (l[c + 1] < 0) {
            if (l[c + 1] == -2) {
                a = !0, l[c + 1] = -1;
                continue
            }
            let f = t.map(n[c] + s), h = f - i;
            if (h < 0 || h >= r.content.size) {
                a = !0;
                continue
            }
            let d = t.map(n[c + 1] + s, -1), u = d - i, {index: p, offset: m} = r.content.findIndex(h),
                g = r.maybeChild(p);
            if (g && m == h && m + g.nodeSize == u) {
                let b = l[c + 2].mapInner(t, g, f + 1, n[c] + s + 1, o);
                b != W ? (l[c] = h, l[c + 1] = u, l[c + 2] = b) : (l[c + 1] = -2, a = !0)
            } else a = !0
        }
        if (a) {
            let c = Bc(l, n, e, t, i, s, o), f = dn(c, r, 0, o);
            e = f.local;
            for (let h = 0; h < l.length; h += 3) l[h + 1] < 0 && (l.splice(h, 3), h -= 3);
            for (let h = 0, d = 0; h < f.children.length; h += 3) {
                let u = f.children[h];
                for (; d < l.length && l[d] < u;) d += 3;
                l.splice(d, 0, f.children[h], f.children[h + 1], f.children[h + 2])
            }
        }
        return new A(e.sort(_e), l)
    }

    function qs(n, e) {
        if (!e || !n.length) return n;
        let t = [];
        for (let r = 0; r < n.length; r++) {
            let i = n[r];
            t.push(new U(i.from + e, i.to + e, i.type))
        }
        return t
    }

    function Bc(n, e, t, r, i, s, o) {
        function l(a, c) {
            for (let f = 0; f < a.local.length; f++) {
                let h = a.local[f].map(r, i, c);
                h ? t.push(h) : o.onRemove && o.onRemove(a.local[f].spec)
            }
            for (let f = 0; f < a.children.length; f += 3) l(a.children[f + 2], a.children[f] + c + 1)
        }

        for (let a = 0; a < n.length; a += 3) n[a + 1] == -1 && l(n[a + 2], e[a] + s + 1);
        return t
    }

    function Ks(n, e, t) {
        if (e.isLeaf) return null;
        let r = t + e.nodeSize, i = null;
        for (let s = 0, o; s < n.length; s++) (o = n[s]) && o.from > t && o.to < r && ((i || (i = [])).push(o), n[s] = null);
        return i
    }

    function js(n) {
        let e = [];
        for (let t = 0; t < n.length; t++) n[t] != null && e.push(n[t]);
        return e
    }

    function dn(n, e, t, r) {
        let i = [], s = !1;
        e.forEach((l, a) => {
            let c = Ks(n, l, a + t);
            if (c) {
                s = !0;
                let f = dn(c, l, t + a + 1, r);
                f != W && i.push(a, a + l.nodeSize, f)
            }
        });
        let o = qs(s ? js(n) : n, -t).sort(_e);
        for (let l = 0; l < o.length; l++) o[l].type.valid(e, o[l]) || (r.onRemove && r.onRemove(o[l].spec), o.splice(l--, 1));
        return o.length || i.length ? new A(o, i) : W
    }

    function _e(n, e) {
        return n.from - e.from || n.to - e.to
    }

    function ur(n) {
        let e = n;
        for (let t = 0; t < e.length - 1; t++) {
            let r = e[t];
            if (r.from != r.to) for (let i = t + 1; i < e.length; i++) {
                let s = e[i];
                if (s.from == r.from) {
                    s.to != r.to && (e == n && (e = n.slice()), e[i] = s.copy(s.from, r.to), Us(e, i + 1, s.copy(r.to, s.to)));
                    continue
                } else {
                    s.from < r.to && (e == n && (e = n.slice()), e[t] = r.copy(r.from, s.from), Us(e, i, r.copy(s.from, r.to)));
                    break
                }
            }
        }
        return e
    }

    function Us(n, e, t) {
        for (; e < n.length && _e(t, n[e]) > 0;) e++;
        n.splice(e, 0, t)
    }

    function pr(n) {
        let e = [];
        return n.someProp("decorations", t => {
            let r = t(n.state);
            r && r != W && e.push(r)
        }), n.cursorWrapper && e.push(A.create(n.state.doc, [n.cursorWrapper.deco])), Ee.from(e)
    }

    const Pc = {
        childList: !0,
        characterData: !0,
        characterDataOldValue: !0,
        attributes: !0,
        attributeOldValue: !0,
        subtree: !0
    }, Vc = j && Me <= 11;

    class Fc {
        constructor() {
            this.anchorNode = null, this.anchorOffset = 0, this.focusNode = null, this.focusOffset = 0
        }

        set(e) {
            this.anchorNode = e.anchorNode, this.anchorOffset = e.anchorOffset, this.focusNode = e.focusNode, this.focusOffset = e.focusOffset
        }

        clear() {
            this.anchorNode = this.focusNode = null
        }

        eq(e) {
            return e.anchorNode == this.anchorNode && e.anchorOffset == this.anchorOffset && e.focusNode == this.focusNode && e.focusOffset == this.focusOffset
        }
    }

    class Lc {
        constructor(e, t) {
            this.view = e, this.handleDOMChange = t, this.queue = [], this.flushingSoon = -1, this.observer = null, this.currentSelection = new Fc, this.onCharData = null, this.suppressingSelectionUpdates = !1, this.lastChangedTextNode = null, this.observer = window.MutationObserver && new window.MutationObserver(r => {
                for (let i = 0; i < r.length; i++) this.queue.push(r[i]);
                j && Me <= 11 && r.some(i => i.type == "childList" && i.removedNodes.length || i.type == "characterData" && i.oldValue.length > i.target.nodeValue.length) ? this.flushSoon() : this.flush()
            }), Vc && (this.onCharData = r => {
                this.queue.push({target: r.target, type: "characterData", oldValue: r.prevValue}), this.flushSoon()
            }), this.onSelectionChange = this.onSelectionChange.bind(this)
        }

        flushSoon() {
            this.flushingSoon < 0 && (this.flushingSoon = window.setTimeout(() => {
                this.flushingSoon = -1, this.flush()
            }, 20))
        }

        forceFlush() {
            this.flushingSoon > -1 && (window.clearTimeout(this.flushingSoon), this.flushingSoon = -1, this.flush())
        }

        start() {
            this.observer && (this.observer.takeRecords(), this.observer.observe(this.view.dom, Pc)), this.onCharData && this.view.dom.addEventListener("DOMCharacterDataModified", this.onCharData), this.connectSelection()
        }

        stop() {
            if (this.observer) {
                let e = this.observer.takeRecords();
                if (e.length) {
                    for (let t = 0; t < e.length; t++) this.queue.push(e[t]);
                    window.setTimeout(() => this.flush(), 20)
                }
                this.observer.disconnect()
            }
            this.onCharData && this.view.dom.removeEventListener("DOMCharacterDataModified", this.onCharData), this.disconnectSelection()
        }

        connectSelection() {
            this.view.dom.ownerDocument.addEventListener("selectionchange", this.onSelectionChange)
        }

        disconnectSelection() {
            this.view.dom.ownerDocument.removeEventListener("selectionchange", this.onSelectionChange)
        }

        suppressSelectionUpdates() {
            this.suppressingSelectionUpdates = !0, setTimeout(() => this.suppressingSelectionUpdates = !1, 50)
        }

        onSelectionChange() {
            if (ks(this.view)) {
                if (this.suppressingSelectionUpdates) return ue(this.view);
                if (j && Me <= 11 && !this.view.state.selection.empty) {
                    let e = this.view.domSelectionRange();
                    if (e.focusNode && Je(e.focusNode, e.focusOffset, e.anchorNode, e.anchorOffset)) return this.flushSoon()
                }
                this.flush()
            }
        }

        setCurSelection() {
            this.currentSelection.set(this.view.domSelectionRange())
        }

        ignoreSelectionChange(e) {
            if (!e.focusNode) return !0;
            let t = new Set, r;
            for (let s = e.focusNode; s; s = Mt(s)) t.add(s);
            for (let s = e.anchorNode; s; s = Mt(s)) if (t.has(s)) {
                r = s;
                break
            }
            let i = r && this.view.docView.nearestDesc(r);
            if (i && i.ignoreMutation({
                type: "selection",
                target: r.nodeType == 3 ? r.parentNode : r
            })) return this.setCurSelection(), !0
        }

        pendingRecords() {
            if (this.observer) for (let e of this.observer.takeRecords()) this.queue.push(e);
            return this.queue
        }

        flush() {
            let {view: e} = this;
            if (!e.docView || this.flushingSoon > -1) return;
            let t = this.pendingRecords();
            t.length && (this.queue = []);
            let r = e.domSelectionRange(),
                i = !this.suppressingSelectionUpdates && !this.currentSelection.eq(r) && ks(e) && !this.ignoreSelectionChange(r),
                s = -1, o = -1, l = !1, a = [];
            if (e.editable) for (let f = 0; f < t.length; f++) {
                let h = this.registerMutation(t[f], a);
                h && (s = s < 0 ? h.from : Math.min(h.from, s), o = o < 0 ? h.to : Math.max(h.to, o), h.typeOver && (l = !0))
            }
            if (ne && a.length) {
                let f = a.filter(h => h.nodeName == "BR");
                if (f.length == 2) {
                    let [h, d] = f;
                    h.parentNode && h.parentNode.parentNode == d.parentNode ? d.remove() : h.remove()
                } else {
                    let {focusNode: h} = this.currentSelection;
                    for (let d of f) {
                        let u = d.parentNode;
                        u && u.nodeName == "LI" && (!h || Wc(e, h) != u) && d.remove()
                    }
                }
            }
            let c = null;
            s < 0 && i && e.input.lastFocus > Date.now() - 200 && Math.max(e.input.lastTouch, e.input.lastClick.time) < Date.now() - 300 && sn(r) && (c = tr(e)) && c.eq(S.near(e.state.doc.resolve(0), 1)) ? (e.input.lastFocus = 0, ue(e), this.currentSelection.set(r), e.scrollToSelection()) : (s > -1 || i) && (s > -1 && (e.docView.markDirty(s, o), Hc(e)), this.handleDOMChange(s, o, l, a), e.docView && e.docView.dirty ? e.updateState(e.state) : this.currentSelection.eq(r) || ue(e), this.currentSelection.set(r))
        }

        registerMutation(e, t) {
            if (t.indexOf(e.target) > -1) return null;
            let r = this.view.docView.nearestDesc(e.target);
            if (e.type == "attributes" && (r == this.view.docView || e.attributeName == "contenteditable" || e.attributeName == "style" && !e.oldValue && !e.target.getAttribute("style")) || !r || r.ignoreMutation(e)) return null;
            if (e.type == "childList") {
                for (let f = 0; f < e.addedNodes.length; f++) {
                    let h = e.addedNodes[f];
                    t.push(h), h.nodeType == 3 && (this.lastChangedTextNode = h)
                }
                if (r.contentDOM && r.contentDOM != r.dom && !r.contentDOM.contains(e.target)) return {
                    from: r.posBefore,
                    to: r.posAfter
                };
                let i = e.previousSibling, s = e.nextSibling;
                if (j && Me <= 11 && e.addedNodes.length) for (let f = 0; f < e.addedNodes.length; f++) {
                    let {previousSibling: h, nextSibling: d} = e.addedNodes[f];
                    (!h || Array.prototype.indexOf.call(e.addedNodes, h) < 0) && (i = h), (!d || Array.prototype.indexOf.call(e.addedNodes, d) < 0) && (s = d)
                }
                let o = i && i.parentNode == e.target ? F(i) + 1 : 0, l = r.localPosFromDOM(e.target, o, -1),
                    a = s && s.parentNode == e.target ? F(s) : e.target.childNodes.length,
                    c = r.localPosFromDOM(e.target, a, 1);
                return {from: l, to: c}
            } else return e.type == "attributes" ? {
                from: r.posAtStart - r.border,
                to: r.posAtEnd + r.border
            } : (this.lastChangedTextNode = e.target, {
                from: r.posAtStart,
                to: r.posAtEnd,
                typeOver: e.target.nodeValue == e.oldValue
            })
        }
    }

    let Gs = new WeakMap, _s = !1;

    function Hc(n) {
        if (!Gs.has(n) && (Gs.set(n, null), ["normal", "nowrap", "pre-line"].indexOf(getComputedStyle(n.dom).whiteSpace) !== -1)) {
            if (n.requiresGeckoHackNode = ne, _s) return;
            console.warn("ProseMirror expects the CSS white-space property to be set, preferably to 'pre-wrap'. It is recommended to load style/prosemirror.css from the prosemirror-view package."), _s = !0
        }
    }

    function Xs(n, e) {
        let t = e.startContainer, r = e.startOffset, i = e.endContainer, s = e.endOffset,
            o = n.domAtPos(n.state.selection.anchor);
        return Je(o.node, o.offset, i, s) && ([t, r, i, s] = [i, s, t, r]), {
            anchorNode: t,
            anchorOffset: r,
            focusNode: i,
            focusOffset: s
        }
    }

    function $c(n, e) {
        if (e.getComposedRanges) {
            let i = e.getComposedRanges(n.root)[0];
            if (i) return Xs(n, i)
        }
        let t;

        function r(i) {
            i.preventDefault(), i.stopImmediatePropagation(), t = i.getTargetRanges()[0]
        }

        return n.dom.addEventListener("beforeinput", r, !0), document.execCommand("indent"), n.dom.removeEventListener("beforeinput", r, !0), t ? Xs(n, t) : null
    }

    function Wc(n, e) {
        for (let t = e.parentNode; t && t != n.dom; t = t.parentNode) {
            let r = n.docView.nearestDesc(t, !0);
            if (r && r.node.isBlock) return t
        }
        return null
    }

    function Jc(n, e, t) {
        let {node: r, fromOffset: i, toOffset: s, from: o, to: l} = n.docView.parseRange(e, t),
            a = n.domSelectionRange(), c, f = a.anchorNode;
        if (f && n.dom.contains(f.nodeType == 1 ? f : f.parentNode) && (c = [{
            node: f,
            offset: a.anchorOffset
        }], sn(a) || c.push({
            node: a.focusNode,
            offset: a.focusOffset
        })), $ && n.input.lastKeyCode === 8) for (let g = s; g > i; g--) {
            let b = r.childNodes[g - 1], w = b.pmViewDesc;
            if (b.nodeName == "BR" && !w) {
                s = g;
                break
            }
            if (!w || w.size) break
        }
        let h = n.state.doc, d = n.someProp("domParser") || Ze.fromSchema(n.state.schema), u = h.resolve(o), p = null,
            m = d.parse(r, {
                topNode: u.parent,
                topMatch: u.parent.contentMatchAt(u.index()),
                topOpen: !0,
                from: i,
                to: s,
                preserveWhitespace: u.parent.type.whitespace == "pre" ? "full" : !0,
                findPositions: c,
                ruleFromNode: qc,
                context: u
            });
        if (c && c[0].pos != null) {
            let g = c[0].pos, b = c[1] && c[1].pos;
            b == null && (b = g), p = {anchor: g + o, head: b + o}
        }
        return {doc: m, sel: p, from: o, to: l}
    }

    function qc(n) {
        let e = n.pmViewDesc;
        if (e) return e.parseRule();
        if (n.nodeName == "BR" && n.parentNode) {
            if (J && /^(ul|ol)$/i.test(n.parentNode.nodeName)) {
                let t = document.createElement("div");
                return t.appendChild(document.createElement("li")), {skip: t}
            } else if (n.parentNode.lastChild == n || J && /^(tr|table)$/i.test(n.parentNode.nodeName)) return {ignore: !0}
        } else if (n.nodeName == "IMG" && n.getAttribute("mark-placeholder")) return {ignore: !0};
        return null
    }

    const Kc = /^(a|abbr|acronym|b|bd[io]|big|br|button|cite|code|data(list)?|del|dfn|em|i|ins|kbd|label|map|mark|meter|output|q|ruby|s|samp|small|span|strong|su[bp]|time|u|tt|var)$/i;

    function jc(n, e, t, r, i) {
        let s = n.input.compositionPendingChanges || (n.composing ? n.input.compositionID : 0);
        if (n.input.compositionPendingChanges = 0, e < 0) {
            let M = n.input.lastSelectionTime > Date.now() - 50 ? n.input.lastSelectionOrigin : null, Be = tr(n, M);
            if (Be && !n.state.selection.eq(Be)) {
                if ($ && re && n.input.lastKeyCode === 13 && Date.now() - 100 < n.input.lastKeyCodeTime && n.someProp("handleKeyDown", Bh => Bh(n, qe(13, "Enter")))) return;
                let Sn = n.state.tr.setSelection(Be);
                M == "pointer" ? Sn.setMeta("pointer", !0) : M == "key" && Sn.scrollIntoView(), s && Sn.setMeta("composition", s), n.dispatch(Sn)
            }
            return
        }
        let o = n.state.doc.resolve(e), l = o.sharedDepth(t);
        e = o.before(l + 1), t = n.state.doc.resolve(t).after(l + 1);
        let a = n.state.selection, c = Jc(n, e, t), f = n.state.doc, h = f.slice(c.from, c.to), d, u;
        n.input.lastKeyCode === 8 && Date.now() - 100 < n.input.lastKeyCodeTime ? (d = n.state.selection.to, u = "end") : (d = n.state.selection.from, u = "start"), n.input.lastKeyCode = null;
        let p = _c(h.content, c.doc.content, c.from, d, u);
        if (p && n.input.domChangeCount++, (at && n.input.lastIOSEnter > Date.now() - 225 || re) && i.some(M => M.nodeType == 1 && !Kc.test(M.nodeName)) && (!p || p.endA >= p.endB) && n.someProp("handleKeyDown", M => M(n, qe(13, "Enter")))) {
            n.input.lastIOSEnter = 0;
            return
        }
        if (!p) if (r && a instanceof C && !a.empty && a.$head.sameParent(a.$anchor) && !n.composing && !(c.sel && c.sel.anchor != c.sel.head)) p = {
            start: a.from,
            endA: a.to,
            endB: a.to
        }; else {
            if (c.sel) {
                let M = Ys(n, n.state.doc, c.sel);
                if (M && !M.eq(n.state.selection)) {
                    let Be = n.state.tr.setSelection(M);
                    s && Be.setMeta("composition", s), n.dispatch(Be)
                }
            }
            return
        }
        n.state.selection.from < n.state.selection.to && p.start == p.endB && n.state.selection instanceof C && (p.start > n.state.selection.from && p.start <= n.state.selection.from + 2 && n.state.selection.from >= c.from ? p.start = n.state.selection.from : p.endA < n.state.selection.to && p.endA >= n.state.selection.to - 2 && n.state.selection.to <= c.to && (p.endB += n.state.selection.to - p.endA, p.endA = n.state.selection.to)), j && Me <= 11 && p.endB == p.start + 1 && p.endA == p.start && p.start > c.from && c.doc.textBetween(p.start - c.from - 1, p.start - c.from + 1) == "  " && (p.start--, p.endA--, p.endB--);
        let m = c.doc.resolveNoCache(p.start - c.from), g = c.doc.resolveNoCache(p.endB - c.from),
            b = f.resolve(p.start), w = m.sameParent(g) && m.parent.inlineContent && b.end() >= p.endA, N;
        if ((at && n.input.lastIOSEnter > Date.now() - 225 && (!w || i.some(M => M.nodeName == "DIV" || M.nodeName == "P")) || !w && m.pos < c.doc.content.size && !m.sameParent(g) && (N = S.findFrom(c.doc.resolve(m.pos + 1), 1, !0)) && N.head == g.pos) && n.someProp("handleKeyDown", M => M(n, qe(13, "Enter")))) {
            n.input.lastIOSEnter = 0;
            return
        }
        if (n.state.selection.anchor > p.start && Gc(f, p.start, p.endA, m, g) && n.someProp("handleKeyDown", M => M(n, qe(8, "Backspace")))) {
            re && $ && n.domObserver.suppressSelectionUpdates();
            return
        }
        $ && re && p.endB == p.start && (n.input.lastAndroidDelete = Date.now()), re && !w && m.start() != g.start() && g.parentOffset == 0 && m.depth == g.depth && c.sel && c.sel.anchor == c.sel.head && c.sel.head == p.endA && (p.endB -= 2, g = c.doc.resolveNoCache(p.endB - c.from), setTimeout(() => {
            n.someProp("handleKeyDown", function (M) {
                return M(n, qe(13, "Enter"))
            })
        }, 20));
        let D = p.start, z = p.endA, B, ye, ze;
        if (w) {
            if (m.pos == g.pos) j && Me <= 11 && m.parentOffset == 0 && (n.domObserver.suppressSelectionUpdates(), setTimeout(() => ue(n), 20)), B = n.state.tr.delete(D, z), ye = f.resolve(p.start).marksAcross(f.resolve(p.endA)); else if (p.endA == p.endB && (ze = Uc(m.parent.content.cut(m.parentOffset, g.parentOffset), b.parent.content.cut(b.parentOffset, p.endA - b.start())))) B = n.state.tr, ze.type == "add" ? B.addMark(D, z, ze.mark) : B.removeMark(D, z, ze.mark); else if (m.parent.child(m.index()).isText && m.index() == g.index() - (g.textOffset ? 0 : 1)) {
                let M = m.parent.textBetween(m.parentOffset, g.parentOffset);
                if (n.someProp("handleTextInput", Be => Be(n, D, z, M))) return;
                B = n.state.tr.insertText(M, D, z)
            }
        }
        if (B || (B = n.state.tr.replace(D, z, c.doc.slice(p.start - c.from, p.endB - c.from))), c.sel) {
            let M = Ys(n, B.doc, c.sel);
            M && !($ && re && n.composing && M.empty && (p.start != p.endB || n.input.lastAndroidDelete < Date.now() - 100) && (M.head == D || M.head == B.mapping.map(z) - 1) || j && M.empty && M.head == D) && B.setSelection(M)
        }
        ye && B.ensureMarks(ye), s && B.setMeta("composition", s), n.dispatch(B.scrollIntoView())
    }

    function Ys(n, e, t) {
        return Math.max(t.anchor, t.head) > e.content.size ? null : rr(n, e.resolve(t.anchor), e.resolve(t.head))
    }

    function Uc(n, e) {
        let t = n.firstChild.marks, r = e.firstChild.marks, i = t, s = r, o, l, a;
        for (let f = 0; f < r.length; f++) i = r[f].removeFromSet(i);
        for (let f = 0; f < t.length; f++) s = t[f].removeFromSet(s);
        if (i.length == 1 && s.length == 0) l = i[0], o = "add", a = f => f.mark(l.addToSet(f.marks)); else if (i.length == 0 && s.length == 1) l = s[0], o = "remove", a = f => f.mark(l.removeFromSet(f.marks)); else return null;
        let c = [];
        for (let f = 0; f < e.childCount; f++) c.push(a(e.child(f)));
        if (y.from(c).eq(n)) return {mark: l, type: o}
    }

    function Gc(n, e, t, r, i) {
        if (t - e <= i.pos - r.pos || mr(r, !0, !1) < i.pos) return !1;
        let s = n.resolve(e);
        if (!r.parent.isTextblock) {
            let l = s.nodeAfter;
            return l != null && t == e + l.nodeSize
        }
        if (s.parentOffset < s.parent.content.size || !s.parent.isTextblock) return !1;
        let o = n.resolve(mr(s, !0, !0));
        return !o.parent.isTextblock || o.pos > t || mr(o, !0, !1) < t ? !1 : r.parent.content.cut(r.parentOffset).eq(o.parent.content)
    }

    function mr(n, e, t) {
        let r = n.depth, i = e ? n.end() : n.pos;
        for (; r > 0 && (e || n.indexAfter(r) == n.node(r).childCount);) r--, i++, e = !1;
        if (t) {
            let s = n.node(r).maybeChild(n.indexAfter(r));
            for (; s && !s.isLeaf;) s = s.firstChild, i++
        }
        return i
    }

    function _c(n, e, t, r, i) {
        let s = n.findDiffStart(e, t);
        if (s == null) return null;
        let {a: o, b: l} = n.findDiffEnd(e, t + n.size, t + e.size);
        if (i == "end") {
            let a = Math.max(0, s - Math.min(o, l));
            r -= o + a - s
        }
        if (o < s && n.size < e.size) {
            let a = r <= s && r >= o ? s - r : 0;
            s -= a, s && s < e.size && Zs(e.textBetween(s - 1, s + 1)) && (s += a ? 1 : -1), l = s + (l - o), o = s
        } else if (l < s) {
            let a = r <= s && r >= l ? s - r : 0;
            s -= a, s && s < n.size && Zs(n.textBetween(s - 1, s + 1)) && (s += a ? 1 : -1), o = s + (o - l), l = s
        }
        return {start: s, endA: o, endB: l}
    }

    function Zs(n) {
        if (n.length != 2) return !1;
        let e = n.charCodeAt(0), t = n.charCodeAt(1);
        return e >= 56320 && e <= 57343 && t >= 55296 && t <= 56319
    }

    class Xc {
        constructor(e, t) {
            this._root = null, this.focused = !1, this.trackWrites = null, this.mounted = !1, this.markCursor = null, this.cursorWrapper = null, this.lastSelectedViewDesc = void 0, this.input = new mc, this.prevDirectPlugins = [], this.pluginViews = [], this.requiresGeckoHackNode = !1, this.dragging = null, this._props = t, this.state = t.state, this.directPlugins = t.plugins || [], this.directPlugins.forEach(ro), this.dispatch = this.dispatch.bind(this), this.dom = e && e.mount || document.createElement("div"), e && (e.appendChild ? e.appendChild(this.dom) : typeof e == "function" ? e(this.dom) : e.mount && (this.mounted = !0)), this.editable = to(this), eo(this), this.nodeViews = no(this), this.docView = as(this.state.doc, Qs(this), pr(this), this.dom, this), this.domObserver = new Lc(this, (r, i, s, o) => jc(this, r, i, s, o)), this.domObserver.start(), gc(this), this.updatePluginViews()
        }

        get composing() {
            return this.input.composing
        }

        get props() {
            if (this._props.state != this.state) {
                let e = this._props;
                this._props = {};
                for (let t in e) this._props[t] = e[t];
                this._props.state = this.state
            }
            return this._props
        }

        update(e) {
            e.handleDOMEvents != this._props.handleDOMEvents && ar(this);
            let t = this._props;
            this._props = e, e.plugins && (e.plugins.forEach(ro), this.directPlugins = e.plugins), this.updateStateInner(e.state, t)
        }

        setProps(e) {
            let t = {};
            for (let r in this._props) t[r] = this._props[r];
            t.state = this.state;
            for (let r in e) t[r] = e[r];
            this.update(t)
        }

        updateState(e) {
            this.updateStateInner(e, this._props)
        }

        updateStateInner(e, t) {
            var r;
            let i = this.state, s = !1, o = !1;
            e.storedMarks && this.composing && (Hs(this), o = !0), this.state = e;
            let l = i.plugins != e.plugins || this._props.plugins != t.plugins;
            if (l || this._props.plugins != t.plugins || this._props.nodeViews != t.nodeViews) {
                let u = no(this);
                Zc(u, this.nodeViews) && (this.nodeViews = u, s = !0)
            }
            (l || t.handleDOMEvents != this._props.handleDOMEvents) && ar(this), this.editable = to(this), eo(this);
            let a = pr(this), c = Qs(this),
                f = i.plugins != e.plugins && !i.doc.eq(e.doc) ? "reset" : e.scrollToSelection > i.scrollToSelection ? "to selection" : "preserve",
                h = s || !this.docView.matchesNode(e.doc, c, a);
            (h || !e.selection.eq(i.selection)) && (o = !0);
            let d = f == "preserve" && o && this.dom.style.overflowAnchor == null && Ea(this);
            if (o) {
                this.domObserver.stop();
                let u = h && (j || $) && !this.composing && !i.selection.empty && !e.selection.empty && Yc(i.selection, e.selection);
                if (h) {
                    let p = $ ? this.trackWrites = this.domSelectionRange().focusNode : null;
                    this.composing && (this.input.compositionNode = Dc(this)), (s || !this.docView.update(e.doc, c, a, this)) && (this.docView.updateOuterDeco(c), this.docView.destroy(), this.docView = as(e.doc, c, a, this.dom, this)), p && !this.trackWrites && (u = !0)
                }
                u || !(this.input.mouseDown && this.domObserver.currentSelection.eq(this.domSelectionRange()) && ec(this)) ? ue(this, u) : (bs(this, e.selection), this.domObserver.setCurSelection()), this.domObserver.start()
            }
            this.updatePluginViews(i), !((r = this.dragging) === null || r === void 0) && r.node && !i.doc.eq(e.doc) && this.updateDraggedNode(this.dragging, i), f == "reset" ? this.dom.scrollTop = 0 : f == "to selection" ? this.scrollToSelection() : d && Ra(d)
        }

        scrollToSelection() {
            let e = this.domSelectionRange().focusNode;
            if (!this.someProp("handleScrollToSelection", t => t(this))) if (this.state.selection instanceof k) {
                let t = this.docView.domAfterPos(this.state.selection.from);
                t.nodeType == 1 && Gi(this, t.getBoundingClientRect(), e)
            } else Gi(this, this.coordsAtPos(this.state.selection.head, 1), e)
        }

        destroyPluginViews() {
            let e;
            for (; e = this.pluginViews.pop();) e.destroy && e.destroy()
        }

        updatePluginViews(e) {
            if (!e || e.plugins != this.state.plugins || this.directPlugins != this.prevDirectPlugins) {
                this.prevDirectPlugins = this.directPlugins, this.destroyPluginViews();
                for (let t = 0; t < this.directPlugins.length; t++) {
                    let r = this.directPlugins[t];
                    r.spec.view && this.pluginViews.push(r.spec.view(this))
                }
                for (let t = 0; t < this.state.plugins.length; t++) {
                    let r = this.state.plugins[t];
                    r.spec.view && this.pluginViews.push(r.spec.view(this))
                }
            } else for (let t = 0; t < this.pluginViews.length; t++) {
                let r = this.pluginViews[t];
                r.update && r.update(this, e)
            }
        }

        updateDraggedNode(e, t) {
            let r = e.node, i = -1;
            if (this.state.doc.nodeAt(r.from) == r.node) i = r.from; else {
                let s = r.from + (this.state.doc.content.size - t.doc.content.size);
                (s > 0 && this.state.doc.nodeAt(s)) == r.node && (i = s)
            }
            this.dragging = new Ws(e.slice, e.move, i < 0 ? void 0 : k.create(this.state.doc, i))
        }

        someProp(e, t) {
            let r = this._props && this._props[e], i;
            if (r != null && (i = t ? t(r) : r)) return i;
            for (let o = 0; o < this.directPlugins.length; o++) {
                let l = this.directPlugins[o].props[e];
                if (l != null && (i = t ? t(l) : l)) return i
            }
            let s = this.state.plugins;
            if (s) for (let o = 0; o < s.length; o++) {
                let l = s[o].props[e];
                if (l != null && (i = t ? t(l) : l)) return i
            }
        }

        hasFocus() {
            if (j) {
                let e = this.root.activeElement;
                if (e == this.dom) return !0;
                if (!e || !this.dom.contains(e)) return !1;
                for (; e && this.dom != e && this.dom.contains(e);) {
                    if (e.contentEditable == "false") return !1;
                    e = e.parentElement
                }
                return !0
            }
            return this.root.activeElement == this.dom
        }

        focus() {
            this.domObserver.stop(), this.editable && Ia(this.dom), ue(this), this.domObserver.start()
        }

        get root() {
            let e = this._root;
            if (e == null) {
                for (let t = this.dom.parentNode; t; t = t.parentNode) if (t.nodeType == 9 || t.nodeType == 11 && t.host) return t.getSelection || (Object.getPrototypeOf(t).getSelection = () => t.ownerDocument.getSelection()), this._root = t
            }
            return e || document
        }

        updateRoot() {
            this._root = null
        }

        posAtCoords(e) {
            return Va(this, e)
        }

        coordsAtPos(e, t = 1) {
            return es(this, e, t)
        }

        domAtPos(e, t = 0) {
            return this.docView.domFromPos(e, t)
        }

        nodeDOM(e) {
            let t = this.docView.descAt(e);
            return t ? t.nodeDOM : null
        }

        posAtDOM(e, t, r = -1) {
            let i = this.docView.posFromDOM(e, t, r);
            if (i == null) throw new RangeError("DOM position not inside the editor");
            return i
        }

        endOfTextblock(e, t) {
            return Wa(this, t || this.state, e)
        }

        pasteHTML(e, t) {
            return It(this, "", e, !1, t || new ClipboardEvent("paste"))
        }

        pasteText(e, t) {
            return It(this, e, null, !0, t || new ClipboardEvent("paste"))
        }

        destroy() {
            this.docView && (yc(this), this.destroyPluginViews(), this.mounted ? (this.docView.update(this.state.doc, [], pr(this), this), this.dom.textContent = "") : this.dom.parentNode && this.dom.parentNode.removeChild(this.dom), this.docView.destroy(), this.docView = null, xa())
        }

        get isDestroyed() {
            return this.docView == null
        }

        dispatchEvent(e) {
            return xc(this, e)
        }

        dispatch(e) {
            let t = this._props.dispatchTransaction;
            t ? t.call(this, e) : this.updateState(this.state.apply(e))
        }

        domSelectionRange() {
            let e = this.domSelection();
            return e ? J && this.root.nodeType === 11 && Ma(this.dom.ownerDocument) == this.dom && $c(this, e) || e : {
                focusNode: null,
                focusOffset: 0,
                anchorNode: null,
                anchorOffset: 0
            }
        }

        domSelection() {
            return this.root.getSelection()
        }
    }

    function Qs(n) {
        let e = Object.create(null);
        return e.class = "ProseMirror", e.contenteditable = String(n.editable), n.someProp("attributes", t => {
            if (typeof t == "function" && (t = t(n.state)), t) for (let r in t) r == "class" ? e.class += " " + t[r] : r == "style" ? e.style = (e.style ? e.style + ";" : "") + t[r] : !e[r] && r != "contenteditable" && r != "nodeName" && (e[r] = String(t[r]))
        }), e.translate || (e.translate = "no"), [U.node(0, n.state.doc.content.size, e)]
    }

    function eo(n) {
        if (n.markCursor) {
            let e = document.createElement("img");
            e.className = "ProseMirror-separator", e.setAttribute("mark-placeholder", "true"), e.setAttribute("alt", ""), n.cursorWrapper = {
                dom: e,
                deco: U.widget(n.state.selection.from, e, {raw: !0, marks: n.markCursor})
            }
        } else n.cursorWrapper = null
    }

    function to(n) {
        return !n.someProp("editable", e => e(n.state) === !1)
    }

    function Yc(n, e) {
        let t = Math.min(n.$anchor.sharedDepth(n.head), e.$anchor.sharedDepth(e.head));
        return n.$anchor.start(t) != e.$anchor.start(t)
    }

    function no(n) {
        let e = Object.create(null);

        function t(r) {
            for (let i in r) Object.prototype.hasOwnProperty.call(e, i) || (e[i] = r[i])
        }

        return n.someProp("nodeViews", t), n.someProp("markViews", t), e
    }

    function Zc(n, e) {
        let t = 0, r = 0;
        for (let i in n) {
            if (n[i] != e[i]) return !0;
            t++
        }
        for (let i in e) r++;
        return t != r
    }

    function ro(n) {
        if (n.spec.state || n.spec.filterTransaction || n.spec.appendTransaction) throw new RangeError("Plugins passed directly to the view must not have a state component")
    }

    var gr, yr;
    if (typeof WeakMap < "u") {
        let n = new WeakMap;
        gr = e => n.get(e), yr = (e, t) => (n.set(e, t), t)
    } else {
        const n = [];
        let t = 0;
        gr = r => {
            for (let i = 0; i < n.length; i += 2) if (n[i] == r) return n[i + 1]
        }, yr = (r, i) => (t == 10 && (t = 0), n[t++] = r, n[t++] = i)
    }
    var R = class {
        constructor(n, e, t, r) {
            this.width = n, this.height = e, this.map = t, this.problems = r
        }

        findCell(n) {
            for (let e = 0; e < this.map.length; e++) {
                const t = this.map[e];
                if (t != n) continue;
                const r = e % this.width, i = e / this.width | 0;
                let s = r + 1, o = i + 1;
                for (let l = 1; s < this.width && this.map[e + l] == t; l++) s++;
                for (let l = 1; o < this.height && this.map[e + this.width * l] == t; l++) o++;
                return {left: r, top: i, right: s, bottom: o}
            }
            throw new RangeError(`No cell with offset ${n} found`)
        }

        colCount(n) {
            for (let e = 0; e < this.map.length; e++) if (this.map[e] == n) return e % this.width;
            throw new RangeError(`No cell with offset ${n} found`)
        }

        nextCell(n, e, t) {
            const {left: r, right: i, top: s, bottom: o} = this.findCell(n);
            return e == "horiz" ? (t < 0 ? r == 0 : i == this.width) ? null : this.map[s * this.width + (t < 0 ? r - 1 : i)] : (t < 0 ? s == 0 : o == this.height) ? null : this.map[r + this.width * (t < 0 ? s - 1 : o)]
        }

        rectBetween(n, e) {
            const {left: t, right: r, top: i, bottom: s} = this.findCell(n), {
                left: o,
                right: l,
                top: a,
                bottom: c
            } = this.findCell(e);
            return {left: Math.min(t, o), top: Math.min(i, a), right: Math.max(r, l), bottom: Math.max(s, c)}
        }

        cellsInRect(n) {
            const e = [], t = {};
            for (let r = n.top; r < n.bottom; r++) for (let i = n.left; i < n.right; i++) {
                const s = r * this.width + i, o = this.map[s];
                t[o] || (t[o] = !0, !(i == n.left && i && this.map[s - 1] == o || r == n.top && r && this.map[s - this.width] == o) && e.push(o))
            }
            return e
        }

        positionAt(n, e, t) {
            for (let r = 0, i = 0; ; r++) {
                const s = i + t.child(r).nodeSize;
                if (r == n) {
                    let o = e + n * this.width;
                    const l = (n + 1) * this.width;
                    for (; o < l && this.map[o] < i;) o++;
                    return o == l ? s - 1 : this.map[o]
                }
                i = s
            }
        }

        static get(n) {
            return gr(n) || yr(n, Qc(n))
        }
    };

    function Qc(n) {
        if (n.type.spec.tableRole != "table") throw new RangeError("Not a table node: " + n.type.name);
        const e = ef(n), t = n.childCount, r = [];
        let i = 0, s = null;
        const o = [];
        for (let c = 0, f = e * t; c < f; c++) r[c] = 0;
        for (let c = 0, f = 0; c < t; c++) {
            const h = n.child(c);
            f++;
            for (let p = 0; ; p++) {
                for (; i < r.length && r[i] != 0;) i++;
                if (p == h.childCount) break;
                const m = h.child(p), {colspan: g, rowspan: b, colwidth: w} = m.attrs;
                for (let N = 0; N < b; N++) {
                    if (N + c >= t) {
                        (s || (s = [])).push({type: "overlong_rowspan", pos: f, n: b - N});
                        break
                    }
                    const D = i + N * e;
                    for (let z = 0; z < g; z++) {
                        r[D + z] == 0 ? r[D + z] = f : (s || (s = [])).push({
                            type: "collision",
                            row: c,
                            pos: f,
                            n: g - z
                        });
                        const B = w && w[z];
                        if (B) {
                            const ye = (D + z) % e * 2, ze = o[ye];
                            ze == null || ze != B && o[ye + 1] == 1 ? (o[ye] = B, o[ye + 1] = 1) : ze == B && o[ye + 1]++
                        }
                    }
                }
                i += g, f += m.nodeSize
            }
            const d = (c + 1) * e;
            let u = 0;
            for (; i < d;) r[i++] == 0 && u++;
            u && (s || (s = [])).push({type: "missing", row: c, n: u}), f++
        }
        const l = new R(e, t, r, s);
        let a = !1;
        for (let c = 0; !a && c < o.length; c += 2) o[c] != null && o[c + 1] < t && (a = !0);
        return a && tf(l, o, n), l
    }

    function ef(n) {
        let e = -1, t = !1;
        for (let r = 0; r < n.childCount; r++) {
            const i = n.child(r);
            let s = 0;
            if (t) for (let o = 0; o < r; o++) {
                const l = n.child(o);
                for (let a = 0; a < l.childCount; a++) {
                    const c = l.child(a);
                    o + c.attrs.rowspan > r && (s += c.attrs.colspan)
                }
            }
            for (let o = 0; o < i.childCount; o++) {
                const l = i.child(o);
                s += l.attrs.colspan, l.attrs.rowspan > 1 && (t = !0)
            }
            e == -1 ? e = s : e != s && (e = Math.max(e, s))
        }
        return e
    }

    function tf(n, e, t) {
        n.problems || (n.problems = []);
        const r = {};
        for (let i = 0; i < n.map.length; i++) {
            const s = n.map[i];
            if (r[s]) continue;
            r[s] = !0;
            const o = t.nodeAt(s);
            if (!o) throw new RangeError(`No cell with offset ${s} found`);
            let l = null;
            const a = o.attrs;
            for (let c = 0; c < a.colspan; c++) {
                const f = (i + c) % n.width, h = e[f * 2];
                h != null && (!a.colwidth || a.colwidth[c] != h) && ((l || (l = nf(a)))[c] = h)
            }
            l && n.problems.unshift({type: "colwidth mismatch", pos: s, colwidth: l})
        }
    }

    function nf(n) {
        if (n.colwidth) return n.colwidth.slice();
        const e = [];
        for (let t = 0; t < n.colspan; t++) e.push(0);
        return e
    }

    function io(n, e) {
        if (typeof n == "string") return {};
        const t = n.getAttribute("data-colwidth"),
            r = t && /^\d+(,\d+)*$/.test(t) ? t.split(",").map(o => Number(o)) : null,
            i = Number(n.getAttribute("colspan") || 1),
            s = {colspan: i, rowspan: Number(n.getAttribute("rowspan") || 1), colwidth: r && r.length == i ? r : null};
        for (const o in e) {
            const l = e[o].getFromDOM, a = l && l(n);
            a != null && (s[o] = a)
        }
        return s
    }

    function so(n, e) {
        const t = {};
        n.attrs.colspan != 1 && (t.colspan = n.attrs.colspan), n.attrs.rowspan != 1 && (t.rowspan = n.attrs.rowspan), n.attrs.colwidth && (t["data-colwidth"] = n.attrs.colwidth.join(","));
        for (const r in e) {
            const i = e[r].setDOMAttr;
            i && i(n.attrs[r], t)
        }
        return t
    }

    function rf(n) {
        const e = n.cellAttributes || {}, t = {colspan: {default: 1}, rowspan: {default: 1}, colwidth: {default: null}};
        for (const r in e) t[r] = {default: e[r].default};
        return {
            table: {
                content: "table_row+",
                tableRole: "table",
                isolating: !0,
                group: n.tableGroup,
                parseDOM: [{tag: "table"}],
                toDOM() {
                    return ["table", ["tbody", 0]]
                }
            },
            table_row: {
                content: "(table_cell | table_header)*", tableRole: "row", parseDOM: [{tag: "tr"}], toDOM() {
                    return ["tr", 0]
                }
            },
            table_cell: {
                content: n.cellContent,
                attrs: t,
                tableRole: "cell",
                isolating: !0,
                parseDOM: [{tag: "td", getAttrs: r => io(r, e)}],
                toDOM(r) {
                    return ["td", so(r, e), 0]
                }
            },
            table_header: {
                content: n.cellContent,
                attrs: t,
                tableRole: "header_cell",
                isolating: !0,
                parseDOM: [{tag: "th", getAttrs: r => io(r, e)}],
                toDOM(r) {
                    return ["th", so(r, e), 0]
                }
            }
        }
    }

    function ce(n) {
        let e = n.cached.tableNodeTypes;
        if (!e) {
            e = n.cached.tableNodeTypes = {};
            for (const t in n.nodes) {
                const r = n.nodes[t], i = r.spec.tableRole;
                i && (e[i] = r)
            }
        }
        return e
    }

    var Re = new Ct("selectingCells");

    function zt(n) {
        for (let e = n.depth - 1; e > 0; e--) if (n.node(e).type.spec.tableRole == "row") return n.node(0).resolve(n.before(e + 1));
        return null
    }

    function un(n) {
        const e = n.selection.$head;
        for (let t = e.depth; t > 0; t--) if (e.node(t).type.spec.tableRole == "row") return !0;
        return !1
    }

    function br(n) {
        const e = n.selection;
        if ("$anchorCell" in e && e.$anchorCell) return e.$anchorCell.pos > e.$headCell.pos ? e.$anchorCell : e.$headCell;
        if ("node" in e && e.node && e.node.type.spec.tableRole == "cell") return e.$anchor;
        const t = zt(e.$head) || sf(e.$head);
        if (t) return t;
        throw new RangeError(`No cell found around position ${e.head}`)
    }

    function sf(n) {
        for (let e = n.nodeAfter, t = n.pos; e; e = e.firstChild, t++) {
            const r = e.type.spec.tableRole;
            if (r == "cell" || r == "header_cell") return n.doc.resolve(t)
        }
        for (let e = n.nodeBefore, t = n.pos; e; e = e.lastChild, t--) {
            const r = e.type.spec.tableRole;
            if (r == "cell" || r == "header_cell") return n.doc.resolve(t - e.nodeSize)
        }
    }

    function xr(n) {
        return n.parent.type.spec.tableRole == "row" && !!n.nodeAfter
    }

    function of(n) {
        return n.node(0).resolve(n.pos + n.nodeAfter.nodeSize)
    }

    function kr(n, e) {
        return n.depth == e.depth && n.pos >= e.start(-1) && n.pos <= e.end(-1)
    }

    function oo(n, e, t) {
        const r = n.node(-1), i = R.get(r), s = n.start(-1), o = i.nextCell(n.pos - s, e, t);
        return o == null ? null : n.node(0).resolve(s + o)
    }

    function ut(n, e, t = 1) {
        const r = {...n, colspan: n.colspan - t};
        return r.colwidth && (r.colwidth = r.colwidth.slice(), r.colwidth.splice(e, t), r.colwidth.some(i => i > 0) || (r.colwidth = null)), r
    }

    var v = class be extends S {
        constructor(e, t = e) {
            const r = e.node(-1), i = R.get(r), s = e.start(-1), o = i.rectBetween(e.pos - s, t.pos - s), l = e.node(0),
                a = i.cellsInRect(o).filter(f => f != t.pos - s);
            a.unshift(t.pos - s);
            const c = a.map(f => {
                const h = r.nodeAt(f);
                if (!h) throw RangeError(`No cell with offset ${f} found`);
                const d = s + f + 1;
                return new yi(l.resolve(d), l.resolve(d + h.content.size))
            });
            super(c[0].$from, c[0].$to, c), this.$anchorCell = e, this.$headCell = t
        }

        map(e, t) {
            const r = e.resolve(t.map(this.$anchorCell.pos)), i = e.resolve(t.map(this.$headCell.pos));
            if (xr(r) && xr(i) && kr(r, i)) {
                const s = this.$anchorCell.node(-1) != r.node(-1);
                return s && this.isRowSelection() ? be.rowSelection(r, i) : s && this.isColSelection() ? be.colSelection(r, i) : new be(r, i)
            }
            return C.between(r, i)
        }

        content() {
            const e = this.$anchorCell.node(-1), t = R.get(e), r = this.$anchorCell.start(-1),
                i = t.rectBetween(this.$anchorCell.pos - r, this.$headCell.pos - r), s = {}, o = [];
            for (let a = i.top; a < i.bottom; a++) {
                const c = [];
                for (let f = a * t.width + i.left, h = i.left; h < i.right; h++, f++) {
                    const d = t.map[f];
                    if (s[d]) continue;
                    s[d] = !0;
                    const u = t.findCell(d);
                    let p = e.nodeAt(d);
                    if (!p) throw RangeError(`No cell with offset ${d} found`);
                    const m = i.left - u.left, g = u.right - i.right;
                    if (m > 0 || g > 0) {
                        let b = p.attrs;
                        if (m > 0 && (b = ut(b, 0, m)), g > 0 && (b = ut(b, b.colspan - g, g)), u.left < i.left) {
                            if (p = p.type.createAndFill(b), !p) throw RangeError(`Could not create cell with attrs ${JSON.stringify(b)}`)
                        } else p = p.type.create(b, p.content)
                    }
                    if (u.top < i.top || u.bottom > i.bottom) {
                        const b = {...p.attrs, rowspan: Math.min(u.bottom, i.bottom) - Math.max(u.top, i.top)};
                        u.top < i.top ? p = p.type.createAndFill(b) : p = p.type.create(b, p.content)
                    }
                    c.push(p)
                }
                o.push(e.child(a).copy(y.from(c)))
            }
            const l = this.isColSelection() && this.isRowSelection() ? e : o;
            return new x(y.from(l), 1, 1)
        }

        replace(e, t = x.empty) {
            const r = e.steps.length, i = this.ranges;
            for (let o = 0; o < i.length; o++) {
                const {$from: l, $to: a} = i[o], c = e.mapping.slice(r);
                e.replace(c.map(l.pos), c.map(a.pos), o ? x.empty : t)
            }
            const s = S.findFrom(e.doc.resolve(e.mapping.slice(r).map(this.to)), -1);
            s && e.setSelection(s)
        }

        replaceWith(e, t) {
            this.replace(e, new x(y.from(t), 0, 0))
        }

        forEachCell(e) {
            const t = this.$anchorCell.node(-1), r = R.get(t), i = this.$anchorCell.start(-1),
                s = r.cellsInRect(r.rectBetween(this.$anchorCell.pos - i, this.$headCell.pos - i));
            for (let o = 0; o < s.length; o++) e(t.nodeAt(s[o]), i + s[o])
        }

        isColSelection() {
            const e = this.$anchorCell.index(-1), t = this.$headCell.index(-1);
            if (Math.min(e, t) > 0) return !1;
            const r = e + this.$anchorCell.nodeAfter.attrs.rowspan, i = t + this.$headCell.nodeAfter.attrs.rowspan;
            return Math.max(r, i) == this.$headCell.node(-1).childCount
        }

        static colSelection(e, t = e) {
            const r = e.node(-1), i = R.get(r), s = e.start(-1), o = i.findCell(e.pos - s), l = i.findCell(t.pos - s),
                a = e.node(0);
            return o.top <= l.top ? (o.top > 0 && (e = a.resolve(s + i.map[o.left])), l.bottom < i.height && (t = a.resolve(s + i.map[i.width * (i.height - 1) + l.right - 1]))) : (l.top > 0 && (t = a.resolve(s + i.map[l.left])), o.bottom < i.height && (e = a.resolve(s + i.map[i.width * (i.height - 1) + o.right - 1]))), new be(e, t)
        }

        isRowSelection() {
            const e = this.$anchorCell.node(-1), t = R.get(e), r = this.$anchorCell.start(-1),
                i = t.colCount(this.$anchorCell.pos - r), s = t.colCount(this.$headCell.pos - r);
            if (Math.min(i, s) > 0) return !1;
            const o = i + this.$anchorCell.nodeAfter.attrs.colspan, l = s + this.$headCell.nodeAfter.attrs.colspan;
            return Math.max(o, l) == t.width
        }

        eq(e) {
            return e instanceof be && e.$anchorCell.pos == this.$anchorCell.pos && e.$headCell.pos == this.$headCell.pos
        }

        static rowSelection(e, t = e) {
            const r = e.node(-1), i = R.get(r), s = e.start(-1), o = i.findCell(e.pos - s), l = i.findCell(t.pos - s),
                a = e.node(0);
            return o.left <= l.left ? (o.left > 0 && (e = a.resolve(s + i.map[o.top * i.width])), l.right < i.width && (t = a.resolve(s + i.map[i.width * (l.top + 1) - 1]))) : (l.left > 0 && (t = a.resolve(s + i.map[l.top * i.width])), o.right < i.width && (e = a.resolve(s + i.map[i.width * (o.top + 1) - 1]))), new be(e, t)
        }

        toJSON() {
            return {type: "cell", anchor: this.$anchorCell.pos, head: this.$headCell.pos}
        }

        static fromJSON(e, t) {
            return new be(e.resolve(t.anchor), e.resolve(t.head))
        }

        static create(e, t, r = t) {
            return new be(e.resolve(t), e.resolve(r))
        }

        getBookmark() {
            return new lf(this.$anchorCell.pos, this.$headCell.pos)
        }
    };
    v.prototype.visible = !1, S.jsonID("cell", v);
    var lf = class Ho {
        constructor(e, t) {
            this.anchor = e, this.head = t
        }

        map(e) {
            return new Ho(e.map(this.anchor), e.map(this.head))
        }

        resolve(e) {
            const t = e.resolve(this.anchor), r = e.resolve(this.head);
            return t.parent.type.spec.tableRole == "row" && r.parent.type.spec.tableRole == "row" && t.index() < t.parent.childCount && r.index() < r.parent.childCount && kr(t, r) ? new v(t, r) : S.near(r, 1)
        }
    };

    function af(n) {
        if (!(n.selection instanceof v)) return null;
        const e = [];
        return n.selection.forEachCell((t, r) => {
            e.push(U.node(r, r + t.nodeSize, {class: "selectedCell"}))
        }), A.create(n.doc, e)
    }

    function cf({$from: n, $to: e}) {
        if (n.pos == e.pos || n.pos < e.pos - 6) return !1;
        let t = n.pos, r = e.pos, i = n.depth;
        for (; i >= 0 && !(n.after(i + 1) < n.end(i)); i--, t++) ;
        for (let s = e.depth; s >= 0 && !(e.before(s + 1) > e.start(s)); s--, r--) ;
        return t == r && /row|table/.test(n.node(i).type.spec.tableRole)
    }

    function ff({$from: n, $to: e}) {
        let t, r;
        for (let i = n.depth; i > 0; i--) {
            const s = n.node(i);
            if (s.type.spec.tableRole === "cell" || s.type.spec.tableRole === "header_cell") {
                t = s;
                break
            }
        }
        for (let i = e.depth; i > 0; i--) {
            const s = e.node(i);
            if (s.type.spec.tableRole === "cell" || s.type.spec.tableRole === "header_cell") {
                r = s;
                break
            }
        }
        return t !== r && e.parentOffset === 0
    }

    function hf(n, e, t) {
        const r = (e || n).selection, i = (e || n).doc;
        let s, o;
        if (r instanceof k && (o = r.node.type.spec.tableRole)) {
            if (o == "cell" || o == "header_cell") s = v.create(i, r.from); else if (o == "row") {
                const l = i.resolve(r.from + 1);
                s = v.rowSelection(l, l)
            } else if (!t) {
                const l = R.get(r.node), a = r.from + 1, c = a + l.map[l.width * l.height - 1];
                s = v.create(i, a + 1, c)
            }
        } else r instanceof C && cf(r) ? s = C.create(i, r.from) : r instanceof C && ff(r) && (s = C.create(i, r.$from.start(), r.$from.end()));
        return s && (e || (e = n.tr)).setSelection(s), e
    }

    var df = new Ct("fix-tables");

    function lo(n, e, t, r) {
        const i = n.childCount, s = e.childCount;
        e:for (let o = 0, l = 0; o < s; o++) {
            const a = e.child(o);
            for (let c = l, f = Math.min(i, o + 3); c < f; c++) if (n.child(c) == a) {
                l = c + 1, t += a.nodeSize;
                continue e
            }
            r(a, t), l < i && n.child(l).sameMarkup(a) ? lo(n.child(l), a, t + 1, r) : a.nodesBetween(0, a.content.size, r, t + 1), t += a.nodeSize
        }
    }

    function uf(n, e) {
        let t;
        const r = (i, s) => {
            i.type.spec.tableRole == "table" && (t = pf(n, i, s, t))
        };
        return e ? e.doc != n.doc && lo(e.doc, n.doc, 0, r) : n.doc.descendants(r), t
    }

    function pf(n, e, t, r) {
        const i = R.get(e);
        if (!i.problems) return r;
        r || (r = n.tr);
        const s = [];
        for (let a = 0; a < i.height; a++) s.push(0);
        for (let a = 0; a < i.problems.length; a++) {
            const c = i.problems[a];
            if (c.type == "collision") {
                const f = e.nodeAt(c.pos);
                if (!f) continue;
                const h = f.attrs;
                for (let d = 0; d < h.rowspan; d++) s[c.row + d] += c.n;
                r.setNodeMarkup(r.mapping.map(t + 1 + c.pos), null, ut(h, h.colspan - c.n, c.n))
            } else if (c.type == "missing") s[c.row] += c.n; else if (c.type == "overlong_rowspan") {
                const f = e.nodeAt(c.pos);
                if (!f) continue;
                r.setNodeMarkup(r.mapping.map(t + 1 + c.pos), null, {...f.attrs, rowspan: f.attrs.rowspan - c.n})
            } else if (c.type == "colwidth mismatch") {
                const f = e.nodeAt(c.pos);
                if (!f) continue;
                r.setNodeMarkup(r.mapping.map(t + 1 + c.pos), null, {...f.attrs, colwidth: c.colwidth})
            }
        }
        let o, l;
        for (let a = 0; a < s.length; a++) s[a] && (o == null && (o = a), l = a);
        for (let a = 0, c = t + 1; a < i.height; a++) {
            const f = e.child(a), h = c + f.nodeSize, d = s[a];
            if (d > 0) {
                let u = "cell";
                f.firstChild && (u = f.firstChild.type.spec.tableRole);
                const p = [];
                for (let g = 0; g < d; g++) {
                    const b = ce(n.schema)[u].createAndFill();
                    b && p.push(b)
                }
                const m = (a == 0 || o == a - 1) && l == a ? c + 1 : h - 1;
                r.insert(r.mapping.map(m), p)
            }
            c = h
        }
        return r.setMeta(df, {fixTables: !0})
    }

    function ao(n) {
        const e = n.selection, t = br(n), r = t.node(-1), i = t.start(-1), s = R.get(r);
        return {
            ...e instanceof v ? s.rectBetween(e.$anchorCell.pos - i, e.$headCell.pos - i) : s.findCell(t.pos - i),
            tableStart: i,
            map: s,
            table: r
        }
    }

    function mf(n) {
        return function (e, t) {
            if (!un(e)) return !1;
            if (t) {
                const r = ce(e.schema), i = ao(e), s = e.tr, o = i.map.cellsInRect(n == "column" ? {
                        left: i.left,
                        top: 0,
                        right: i.right,
                        bottom: i.map.height
                    } : n == "row" ? {left: 0, top: i.top, right: i.map.width, bottom: i.bottom} : i),
                    l = o.map(a => i.table.nodeAt(a));
                for (let a = 0; a < o.length; a++) l[a].type == r.header_cell && s.setNodeMarkup(i.tableStart + o[a], r.cell, l[a].attrs);
                if (s.steps.length == 0) for (let a = 0; a < o.length; a++) s.setNodeMarkup(i.tableStart + o[a], r.header_cell, l[a].attrs);
                t(s)
            }
            return !0
        }
    }

    function co(n, e, t) {
        const r = e.map.cellsInRect({
            left: 0,
            top: 0,
            right: n == "row" ? e.map.width : 1,
            bottom: n == "column" ? e.map.height : 1
        });
        for (let i = 0; i < r.length; i++) {
            const s = e.table.nodeAt(r[i]);
            if (s && s.type !== t.header_cell) return !1
        }
        return !0
    }

    function Sr(n, e) {
        return e = e || {useDeprecatedLogic: !1}, e.useDeprecatedLogic ? mf(n) : function (t, r) {
            if (!un(t)) return !1;
            if (r) {
                const i = ce(t.schema), s = ao(t), o = t.tr, l = co("row", s, i), a = co("column", s, i),
                    f = (n === "column" ? l : n === "row" ? a : !1) ? 1 : 0,
                    h = n == "column" ? {left: 0, top: f, right: 1, bottom: s.map.height} : n == "row" ? {
                        left: f,
                        top: 0,
                        right: s.map.width,
                        bottom: 1
                    } : s,
                    d = n == "column" ? a ? i.cell : i.header_cell : n == "row" ? l ? i.cell : i.header_cell : i.cell;
                s.map.cellsInRect(h).forEach(u => {
                    const p = u + s.tableStart, m = o.doc.nodeAt(p);
                    m && o.setNodeMarkup(p, d, m.attrs)
                }), r(o)
            }
            return !0
        }
    }

    Sr("row", {useDeprecatedLogic: !0}), Sr("column", {useDeprecatedLogic: !0}), Sr("cell", {useDeprecatedLogic: !0});

    function gf(n, e) {
        if (e < 0) {
            const t = n.nodeBefore;
            if (t) return n.pos - t.nodeSize;
            for (let r = n.index(-1) - 1, i = n.before(); r >= 0; r--) {
                const s = n.node(-1).child(r), o = s.lastChild;
                if (o) return i - 1 - o.nodeSize;
                i -= s.nodeSize
            }
        } else {
            if (n.index() < n.parent.childCount - 1) return n.pos + n.nodeAfter.nodeSize;
            const t = n.node(-1);
            for (let r = n.indexAfter(-1), i = n.after(); r < t.childCount; r++) {
                const s = t.child(r);
                if (s.childCount) return i + 1;
                i += s.nodeSize
            }
        }
        return null
    }

    function fo(n) {
        return function (e, t) {
            if (!un(e)) return !1;
            const r = gf(br(e), n);
            if (r == null) return !1;
            if (t) {
                const i = e.doc.resolve(r);
                t(e.tr.setSelection(C.between(i, of(i))).scrollIntoView())
            }
            return !0
        }
    }

    function pn(n, e) {
        const t = n.selection;
        if (!(t instanceof v)) return !1;
        if (e) {
            const r = n.tr, i = ce(n.schema).cell.createAndFill().content;
            t.forEachCell((s, o) => {
                s.content.eq(i) || r.replace(r.mapping.map(o + 1), r.mapping.map(o + s.nodeSize - 1), new x(i, 0, 0))
            }), r.docChanged && e(r)
        }
        return !0
    }

    function yf(n) {
        if (!n.size) return null;
        let {content: e, openStart: t, openEnd: r} = n;
        for (; e.childCount == 1 && (t > 0 && r > 0 || e.child(0).type.spec.tableRole == "table");) t--, r--, e = e.child(0).content;
        const i = e.child(0), s = i.type.spec.tableRole, o = i.type.schema, l = [];
        if (s == "row") for (let a = 0; a < e.childCount; a++) {
            let c = e.child(a).content;
            const f = a ? 0 : Math.max(0, t - 1), h = a < e.childCount - 1 ? 0 : Math.max(0, r - 1);
            (f || h) && (c = Cr(ce(o).row, new x(c, f, h)).content), l.push(c)
        } else if (s == "cell" || s == "header_cell") l.push(t || r ? Cr(ce(o).row, new x(e, t, r)).content : e); else return null;
        return bf(o, l)
    }

    function bf(n, e) {
        const t = [];
        for (let i = 0; i < e.length; i++) {
            const s = e[i];
            for (let o = s.childCount - 1; o >= 0; o--) {
                const {rowspan: l, colspan: a} = s.child(o).attrs;
                for (let c = i; c < i + l; c++) t[c] = (t[c] || 0) + a
            }
        }
        let r = 0;
        for (let i = 0; i < t.length; i++) r = Math.max(r, t[i]);
        for (let i = 0; i < t.length; i++) if (i >= e.length && e.push(y.empty), t[i] < r) {
            const s = ce(n).cell.createAndFill(), o = [];
            for (let l = t[i]; l < r; l++) o.push(s);
            e[i] = e[i].append(y.from(o))
        }
        return {height: e.length, width: r, rows: e}
    }

    function Cr(n, e) {
        const t = n.createAndFill();
        return new gi(t).replace(0, t.content.size, e).doc
    }

    function xf({width: n, height: e, rows: t}, r, i) {
        if (n != r) {
            const s = [], o = [];
            for (let l = 0; l < t.length; l++) {
                const a = t[l], c = [];
                for (let f = s[l] || 0, h = 0; f < r; h++) {
                    let d = a.child(h % a.childCount);
                    f + d.attrs.colspan > r && (d = d.type.createChecked(ut(d.attrs, d.attrs.colspan, f + d.attrs.colspan - r), d.content)), c.push(d), f += d.attrs.colspan;
                    for (let u = 1; u < d.attrs.rowspan; u++) s[l + u] = (s[l + u] || 0) + d.attrs.colspan
                }
                o.push(y.from(c))
            }
            t = o, n = r
        }
        if (e != i) {
            const s = [];
            for (let o = 0, l = 0; o < i; o++, l++) {
                const a = [], c = t[l % e];
                for (let f = 0; f < c.childCount; f++) {
                    let h = c.child(f);
                    o + h.attrs.rowspan > i && (h = h.type.create({
                        ...h.attrs,
                        rowspan: Math.max(1, i - h.attrs.rowspan)
                    }, h.content)), a.push(h)
                }
                s.push(y.from(a))
            }
            t = s, e = i
        }
        return {width: n, height: e, rows: t}
    }

    function kf(n, e, t, r, i, s, o) {
        const l = n.doc.type.schema, a = ce(l);
        let c, f;
        if (i > e.width) for (let h = 0, d = 0; h < e.height; h++) {
            const u = t.child(h);
            d += u.nodeSize;
            const p = [];
            let m;
            u.lastChild == null || u.lastChild.type == a.cell ? m = c || (c = a.cell.createAndFill()) : m = f || (f = a.header_cell.createAndFill());
            for (let g = e.width; g < i; g++) p.push(m);
            n.insert(n.mapping.slice(o).map(d - 1 + r), p)
        }
        if (s > e.height) {
            const h = [];
            for (let p = 0, m = (e.height - 1) * e.width; p < Math.max(e.width, i); p++) {
                const g = p >= e.width ? !1 : t.nodeAt(e.map[m + p]).type == a.header_cell;
                h.push(g ? f || (f = a.header_cell.createAndFill()) : c || (c = a.cell.createAndFill()))
            }
            const d = a.row.create(null, y.from(h)), u = [];
            for (let p = e.height; p < s; p++) u.push(d);
            n.insert(n.mapping.slice(o).map(r + t.nodeSize - 2), u)
        }
        return !!(c || f)
    }

    function ho(n, e, t, r, i, s, o, l) {
        if (o == 0 || o == e.height) return !1;
        let a = !1;
        for (let c = i; c < s; c++) {
            const f = o * e.width + c, h = e.map[f];
            if (e.map[f - e.width] == h) {
                a = !0;
                const d = t.nodeAt(h), {top: u, left: p} = e.findCell(h);
                n.setNodeMarkup(n.mapping.slice(l).map(h + r), null, {
                    ...d.attrs,
                    rowspan: o - u
                }), n.insert(n.mapping.slice(l).map(e.positionAt(o, p, t)), d.type.createAndFill({
                    ...d.attrs,
                    rowspan: u + d.attrs.rowspan - o
                })), c += d.attrs.colspan - 1
            }
        }
        return a
    }

    function uo(n, e, t, r, i, s, o, l) {
        if (o == 0 || o == e.width) return !1;
        let a = !1;
        for (let c = i; c < s; c++) {
            const f = c * e.width + o, h = e.map[f];
            if (e.map[f - 1] == h) {
                a = !0;
                const d = t.nodeAt(h), u = e.colCount(h), p = n.mapping.slice(l).map(h + r);
                n.setNodeMarkup(p, null, ut(d.attrs, o - u, d.attrs.colspan - (o - u))), n.insert(p + d.nodeSize, d.type.createAndFill(ut(d.attrs, 0, o - u))), c += d.attrs.rowspan - 1
            }
        }
        return a
    }

    function po(n, e, t, r, i) {
        let s = t ? n.doc.nodeAt(t - 1) : n.doc;
        if (!s) throw new Error("No table found");
        let o = R.get(s);
        const {top: l, left: a} = r, c = a + i.width, f = l + i.height, h = n.tr;
        let d = 0;

        function u() {
            if (s = t ? h.doc.nodeAt(t - 1) : h.doc, !s) throw new Error("No table found");
            o = R.get(s), d = h.mapping.maps.length
        }

        kf(h, o, s, t, c, f, d) && u(), ho(h, o, s, t, a, c, l, d) && u(), ho(h, o, s, t, a, c, f, d) && u(), uo(h, o, s, t, l, f, a, d) && u(), uo(h, o, s, t, l, f, c, d) && u();
        for (let p = l; p < f; p++) {
            const m = o.positionAt(p, a, s), g = o.positionAt(p, c, s);
            h.replace(h.mapping.slice(d).map(m + t), h.mapping.slice(d).map(g + t), new x(i.rows[p - l], 0, 0))
        }
        u(), h.setSelection(new v(h.doc.resolve(t + o.positionAt(l, a, s)), h.doc.resolve(t + o.positionAt(f - 1, c - 1, s)))), e(h)
    }

    var Sf = Wi({
        ArrowLeft: gn("horiz", -1),
        ArrowRight: gn("horiz", 1),
        ArrowUp: gn("vert", -1),
        ArrowDown: gn("vert", 1),
        "Shift-ArrowLeft": yn("horiz", -1),
        "Shift-ArrowRight": yn("horiz", 1),
        "Shift-ArrowUp": yn("vert", -1),
        "Shift-ArrowDown": yn("vert", 1),
        Backspace: pn,
        "Mod-Backspace": pn,
        Delete: pn,
        "Mod-Delete": pn
    });

    function mn(n, e, t) {
        return t.eq(n.selection) ? !1 : (e && e(n.tr.setSelection(t).scrollIntoView()), !0)
    }

    function gn(n, e) {
        return (t, r, i) => {
            if (!i) return !1;
            const s = t.selection;
            if (s instanceof v) return mn(t, r, S.near(s.$headCell, e));
            if (n != "horiz" && !s.empty) return !1;
            const o = mo(i, n, e);
            if (o == null) return !1;
            if (n == "horiz") return mn(t, r, S.near(t.doc.resolve(s.head + e), e));
            {
                const l = t.doc.resolve(o), a = oo(l, n, e);
                let c;
                return a ? c = S.near(a, 1) : e < 0 ? c = S.near(t.doc.resolve(l.before(-1)), -1) : c = S.near(t.doc.resolve(l.after(-1)), 1), mn(t, r, c)
            }
        }
    }

    function yn(n, e) {
        return (t, r, i) => {
            if (!i) return !1;
            const s = t.selection;
            let o;
            if (s instanceof v) o = s; else {
                const a = mo(i, n, e);
                if (a == null) return !1;
                o = new v(t.doc.resolve(a))
            }
            const l = oo(o.$headCell, n, e);
            return l ? mn(t, r, new v(o.$anchorCell, l)) : !1
        }
    }

    function Cf(n, e) {
        const t = n.state.doc, r = zt(t.resolve(e));
        return r ? (n.dispatch(n.state.tr.setSelection(new v(r))), !0) : !1
    }

    function wf(n, e, t) {
        if (!un(n.state)) return !1;
        let r = yf(t);
        const i = n.state.selection;
        if (i instanceof v) {
            r || (r = {width: 1, height: 1, rows: [y.from(Cr(ce(n.state.schema).cell, t))]});
            const s = i.$anchorCell.node(-1), o = i.$anchorCell.start(-1),
                l = R.get(s).rectBetween(i.$anchorCell.pos - o, i.$headCell.pos - o);
            return r = xf(r, l.right - l.left, l.bottom - l.top), po(n.state, n.dispatch, o, l, r), !0
        } else if (r) {
            const s = br(n.state), o = s.start(-1);
            return po(n.state, n.dispatch, o, R.get(s.node(-1)).findCell(s.pos - o), r), !0
        } else return !1
    }

    function Mf(n, e) {
        var t;
        if (e.ctrlKey || e.metaKey) return;
        const r = go(n, e.target);
        let i;
        if (e.shiftKey && n.state.selection instanceof v) s(n.state.selection.$anchorCell, e), e.preventDefault(); else if (e.shiftKey && r && (i = zt(n.state.selection.$anchor)) != null && ((t = wr(n, e)) == null ? void 0 : t.pos) != i.pos) s(i, e), e.preventDefault(); else if (!r) return;

        function s(a, c) {
            let f = wr(n, c);
            const h = Re.getState(n.state) == null;
            if (!f || !kr(a, f)) if (h) f = a; else return;
            const d = new v(a, f);
            if (h || !n.state.selection.eq(d)) {
                const u = n.state.tr.setSelection(d);
                h && u.setMeta(Re, a.pos), n.dispatch(u)
            }
        }

        function o() {
            n.root.removeEventListener("mouseup", o), n.root.removeEventListener("dragstart", o), n.root.removeEventListener("mousemove", l), Re.getState(n.state) != null && n.dispatch(n.state.tr.setMeta(Re, -1))
        }

        function l(a) {
            const c = a, f = Re.getState(n.state);
            let h;
            if (f != null) h = n.state.doc.resolve(f); else if (go(n, c.target) != r && (h = wr(n, e), !h)) return o();
            h && s(h, c)
        }

        n.root.addEventListener("mouseup", o), n.root.addEventListener("dragstart", o), n.root.addEventListener("mousemove", l)
    }

    function mo(n, e, t) {
        if (!(n.state.selection instanceof C)) return null;
        const {$head: r} = n.state.selection;
        for (let i = r.depth - 1; i >= 0; i--) {
            const s = r.node(i);
            if ((t < 0 ? r.index(i) : r.indexAfter(i)) != (t < 0 ? 0 : s.childCount)) return null;
            if (s.type.spec.tableRole == "cell" || s.type.spec.tableRole == "header_cell") {
                const l = r.before(i), a = e == "vert" ? t > 0 ? "down" : "up" : t > 0 ? "right" : "left";
                return n.endOfTextblock(a) ? l : null
            }
        }
        return null
    }

    function go(n, e) {
        for (; e && e != n.dom; e = e.parentNode) if (e.nodeName == "TD" || e.nodeName == "TH") return e;
        return null
    }

    function wr(n, e) {
        const t = n.posAtCoords({left: e.clientX, top: e.clientY});
        return t && t ? zt(n.state.doc.resolve(t.pos)) : null
    }

    var Of = class {
        constructor(n, e) {
            this.node = n, this.defaultCellMinWidth = e, this.dom = document.createElement("div"), this.dom.className = "tableWrapper", this.table = this.dom.appendChild(document.createElement("table")), this.table.style.setProperty("--default-cell-min-width", `${e}px`), this.colgroup = this.table.appendChild(document.createElement("colgroup")), Mr(n, this.colgroup, this.table, e), this.contentDOM = this.table.appendChild(document.createElement("tbody"))
        }

        update(n) {
            return n.type != this.node.type ? !1 : (this.node = n, Mr(n, this.colgroup, this.table, this.defaultCellMinWidth), !0)
        }

        ignoreMutation(n) {
            return n.type == "attributes" && (n.target == this.table || this.colgroup.contains(n.target))
        }
    };

    function Mr(n, e, t, r, i, s) {
        var o;
        let l = 0, a = !0, c = e.firstChild;
        const f = n.firstChild;
        if (f) {
            for (let h = 0, d = 0; h < f.childCount; h++) {
                const {colspan: u, colwidth: p} = f.child(h).attrs;
                for (let m = 0; m < u; m++, d++) {
                    const g = i == d ? s : p && p[m], b = g ? g + "px" : "";
                    if (l += g || r, g || (a = !1), c) c.style.width != b && (c.style.width = b), c = c.nextSibling; else {
                        const w = document.createElement("col");
                        w.style.width = b, e.appendChild(w)
                    }
                }
            }
            for (; c;) {
                const h = c.nextSibling;
                (o = c.parentNode) == null || o.removeChild(c), c = h
            }
            a ? (t.style.width = l + "px", t.style.minWidth = "") : (t.style.width = "", t.style.minWidth = l + "px")
        }
    }

    var X = new Ct("tableColumnResizing");

    function Nf({
                    handleWidth: n = 5,
                    cellMinWidth: e = 25,
                    defaultCellMinWidth: t = 100,
                    View: r = Of,
                    lastColumnResizable: i = !0
                } = {}) {
        const s = new ot({
            key: X, state: {
                init(o, l) {
                    var a, c;
                    const f = (c = (a = s.spec) == null ? void 0 : a.props) == null ? void 0 : c.nodeViews,
                        h = ce(l.schema).table.name;
                    return r && f && (f[h] = (d, u) => new r(d, t, u)), new Tf(-1, !1)
                }, apply(o, l) {
                    return l.apply(o)
                }
            }, props: {
                attributes: o => {
                    const l = X.getState(o);
                    return l && l.activeHandle > -1 ? {class: "resize-cursor"} : {}
                }, handleDOMEvents: {
                    mousemove: (o, l) => {
                        Af(o, l, n, i)
                    }, mouseleave: o => {
                        Df(o)
                    }, mousedown: (o, l) => {
                        Ef(o, l, e, t)
                    }
                }, decorations: o => {
                    const l = X.getState(o);
                    if (l && l.activeHandle > -1) return Bf(o, l.activeHandle)
                }, nodeViews: {}
            }
        });
        return s
    }

    var Tf = class Cn {
        constructor(e, t) {
            this.activeHandle = e, this.dragging = t
        }

        apply(e) {
            const t = this, r = e.getMeta(X);
            if (r && r.setHandle != null) return new Cn(r.setHandle, !1);
            if (r && r.setDragging !== void 0) return new Cn(t.activeHandle, r.setDragging);
            if (t.activeHandle > -1 && e.docChanged) {
                let i = e.mapping.map(t.activeHandle, -1);
                return xr(e.doc.resolve(i)) || (i = -1), new Cn(i, t.dragging)
            }
            return t
        }
    };

    function Af(n, e, t, r) {
        const i = X.getState(n.state);
        if (i && !i.dragging) {
            const s = If(e.target);
            let o = -1;
            if (s) {
                const {left: l, right: a} = s.getBoundingClientRect();
                e.clientX - l <= t ? o = yo(n, e, "left", t) : a - e.clientX <= t && (o = yo(n, e, "right", t))
            }
            if (o != i.activeHandle) {
                if (!r && o !== -1) {
                    const l = n.state.doc.resolve(o), a = l.node(-1), c = R.get(a), f = l.start(-1);
                    if (c.colCount(l.pos - f) + l.nodeAfter.attrs.colspan - 1 == c.width - 1) return
                }
                xo(n, o)
            }
        }
    }

    function Df(n) {
        const e = X.getState(n.state);
        e && e.activeHandle > -1 && !e.dragging && xo(n, -1)
    }

    function Ef(n, e, t, r) {
        var i;
        const s = (i = n.dom.ownerDocument.defaultView) != null ? i : window, o = X.getState(n.state);
        if (!o || o.activeHandle == -1 || o.dragging) return !1;
        const l = n.state.doc.nodeAt(o.activeHandle), a = Rf(n, o.activeHandle, l.attrs);
        n.dispatch(n.state.tr.setMeta(X, {setDragging: {startX: e.clientX, startWidth: a}}));

        function c(h) {
            s.removeEventListener("mouseup", c), s.removeEventListener("mousemove", f);
            const d = X.getState(n.state);
            d != null && d.dragging && (vf(n, d.activeHandle, bo(d.dragging, h, t)), n.dispatch(n.state.tr.setMeta(X, {setDragging: null})))
        }

        function f(h) {
            if (!h.which) return c(h);
            const d = X.getState(n.state);
            if (d && d.dragging) {
                const u = bo(d.dragging, h, t);
                ko(n, d.activeHandle, u, r)
            }
        }

        return ko(n, o.activeHandle, a, r), s.addEventListener("mouseup", c), s.addEventListener("mousemove", f), e.preventDefault(), !0
    }

    function Rf(n, e, {colspan: t, colwidth: r}) {
        const i = r && r[r.length - 1];
        if (i) return i;
        const s = n.domAtPos(e);
        let l = s.node.childNodes[s.offset].offsetWidth, a = t;
        if (r) for (let c = 0; c < t; c++) r[c] && (l -= r[c], a--);
        return l / a
    }

    function If(n) {
        for (; n && n.nodeName != "TD" && n.nodeName != "TH";) n = n.classList && n.classList.contains("ProseMirror") ? null : n.parentNode;
        return n
    }

    function yo(n, e, t, r) {
        const i = t == "right" ? -r : r, s = n.posAtCoords({left: e.clientX + i, top: e.clientY});
        if (!s) return -1;
        const {pos: o} = s, l = zt(n.state.doc.resolve(o));
        if (!l) return -1;
        if (t == "right") return l.pos;
        const a = R.get(l.node(-1)), c = l.start(-1), f = a.map.indexOf(l.pos - c);
        return f % a.width == 0 ? -1 : c + a.map[f - 1]
    }

    function bo(n, e, t) {
        const r = e.clientX - n.startX;
        return Math.max(t, n.startWidth + r)
    }

    function xo(n, e) {
        n.dispatch(n.state.tr.setMeta(X, {setHandle: e}))
    }

    function vf(n, e, t) {
        const r = n.state.doc.resolve(e), i = r.node(-1), s = R.get(i), o = r.start(-1),
            l = s.colCount(r.pos - o) + r.nodeAfter.attrs.colspan - 1, a = n.state.tr;
        for (let c = 0; c < s.height; c++) {
            const f = c * s.width + l;
            if (c && s.map[f] == s.map[f - s.width]) continue;
            const h = s.map[f], d = i.nodeAt(h).attrs, u = d.colspan == 1 ? 0 : l - s.colCount(h);
            if (d.colwidth && d.colwidth[u] == t) continue;
            const p = d.colwidth ? d.colwidth.slice() : zf(d.colspan);
            p[u] = t, a.setNodeMarkup(o + h, null, {...d, colwidth: p})
        }
        a.docChanged && n.dispatch(a)
    }

    function ko(n, e, t, r) {
        const i = n.state.doc.resolve(e), s = i.node(-1), o = i.start(-1),
            l = R.get(s).colCount(i.pos - o) + i.nodeAfter.attrs.colspan - 1;
        let a = n.domAtPos(i.start(-1)).node;
        for (; a && a.nodeName != "TABLE";) a = a.parentNode;
        a && Mr(s, a.firstChild, a, r, l, t)
    }

    function zf(n) {
        return Array(n).fill(0)
    }

    function Bf(n, e) {
        var t;
        const r = [], i = n.doc.resolve(e), s = i.node(-1);
        if (!s) return A.empty;
        const o = R.get(s), l = i.start(-1), a = o.colCount(i.pos - l) + i.nodeAfter.attrs.colspan - 1;
        for (let c = 0; c < o.height; c++) {
            const f = a + c * o.width;
            if ((a == o.width - 1 || o.map[f] != o.map[f + 1]) && (c == 0 || o.map[f] != o.map[f - o.width])) {
                const h = o.map[f], d = l + h + s.nodeAt(h).nodeSize - 1, u = document.createElement("div");
                u.className = "column-resize-handle", (t = X.getState(n)) != null && t.dragging && r.push(U.node(l + h, l + h + s.nodeAt(h).nodeSize, {class: "column-resize-dragging"})), r.push(U.widget(d, u))
            }
        }
        return A.create(n.doc, r)
    }

    function Pf({allowTableNodeSelection: n = !1} = {}) {
        return new ot({
            key: Re, state: {
                init() {
                    return null
                }, apply(e, t) {
                    const r = e.getMeta(Re);
                    if (r != null) return r == -1 ? null : r;
                    if (t == null || !e.docChanged) return t;
                    const {deleted: i, pos: s} = e.mapping.mapResult(t);
                    return i ? null : s
                }
            }, props: {
                decorations: af, handleDOMEvents: {mousedown: Mf}, createSelectionBetween(e) {
                    return Re.getState(e.state) != null ? e.state.selection : null
                }, handleTripleClick: Cf, handleKeyDown: Sf, handlePaste: wf
            }, appendTransaction(e, t, r) {
                return hf(r, uf(r, t), n)
            }
        })
    }

    const So = "app.grapesjs.com", Co = "app-stage.grapesjs.com",
        wo = [So, Co, "localhost", "127.0.0.1", ".local-credentialless.webcontainer.io", ".local.webcontainer.io", "-sandpack.codesandbox.io"],
        Vf = "license:check:start", Ff = "license:check:end", Lf = () => typeof window < "u",
        Hf = ({isDev: n, isStage: e}) => `${n ? "" : `https://${e ? Co : So}`}/api`, $f = () => {
            const n = Lf() && window.location.hostname;
            return !!n && (wo.includes(n) || wo.some(e => n.endsWith(e)))
        };

    async function Wf({path: n, baseApiUrl: e, method: t = "GET", headers: r = {}, params: i, body: s}) {
        const l = `${e || Hf({isDev: !1, isStage: !1})}${n}`,
            a = {method: t, headers: {"Content-Type": "application/json", ...r}};
        s && (a.body = JSON.stringify(s));
        const c = i ? new URLSearchParams(i).toString() : "", f = c ? `?${c}` : "", h = await fetch(`${l}${f}`, a);
        if (!h.ok) throw new Error(`HTTP error! status: ${h.status}`);
        return h.json()
    }

    var pt = (n => (n.free = "free", n.startup = "startup", n.business = "business", n.enterprise = "enterprise", n))(pt || {}),
        bn = (n => (n.toastAdd = "studio:toastAdd", n.toastRemove = "studio:toastRemove", n.dialogOpen = "studio:dialogOpen", n.dialogClose = "studio:dialogClose", n.sidebarLeftSet = "studio:sidebarLeft:set", n.sidebarLeftGet = "studio:sidebarLeft:get", n.sidebarLeftToggle = "studio:sidebarLeft:toggle", n.sidebarRightSet = "studio:sidebarRight:set", n.sidebarRightGet = "studio:sidebarRight:get", n.sidebarRightToggle = "studio:sidebarRight:toggle", n.sidebarTopSet = "studio:sidebarTop:set", n.sidebarTopGet = "studio:sidebarTop:get", n.sidebarTopToggle = "studio:sidebarTop:toggle", n.sidebarBottomSet = "studio:sidebarBottom:set", n.sidebarBottomGet = "studio:sidebarBottom:get", n.sidebarBottomToggle = "studio:sidebarBottom:toggle", n.symbolAdd = "studio:symbolAdd", n.symbolDetach = "studio:symbolDetach", n.symbolOverride = "studio:symbolOverride", n.symbolPropagateStyles = "studio:propagateStyles", n.getPagesConfig = "studio:getPagesConfig", n.setPagesConfig = "studio:setPagesConfig", n.getPageSettings = "studio:getPageSettings", n.setPageSettings = "studio:setPageSettings", n.projectFiles = "studio:projectFiles", n.canvasReload = "studio:canvasReload", n.getBlocksPanel = "studio:getBlocksPanel", n.setBlocksPanel = "studio:setBlocksPanel", n.getStateContextMenu = "studio:getStateContextMenu", n.setStateContextMenu = "studio:setStateContextMenu", n.contextMenuComponent = "studio:contextMenuComponent", n.layoutAdd = "studio:layoutAdd", n.layoutRemove = "studio:layoutRemove", n.layoutToggle = "studio:layoutToggle", n.layoutUpdate = "studio:layoutUpdate", n.layoutGet = "studio:layoutGet", n.layoutConfigGet = "studio:layoutConfigGet", n.layoutConfigSet = "studio:layoutConfigSet", n.getStateTheme = "studio:getStateTheme", n.setStateTheme = "studio:setStateTheme", n.assetProviderGet = "studio:assetProviderGet", n.assetProviderAdd = "studio:assetProviderAdd", n.assetProviderRemove = "studio:assetProviderRemove", n.fontGet = "studio:fontGet", n.fontAdd = "studio:fontAdd", n.fontRemove = "studio:fontRemove", n.fontManagerOpen = "studio:fontManagerOpen", n.menuFontLoad = "studio:menuFontLoad", n.toggleStateDataSource = "studio:toggleStateDataSource", n.getStateDataSource = "studio:getStateDataSource", n.dataSourceSetGlobalData = "studio:dataSourceSetGlobalData", n.dataSourceSetImporter = "studio:dataSourceSetImporter", n.dataSourceSetExporter = "studio:dataSourceSetExporter", n.setDragAbsolute = "studio:setDragAbsolute", n))(bn || {});
    const Mo = {[pt.free]: 0, [pt.startup]: 10, [pt.business]: 20, [pt.enterprise]: 30};

    function Jf(n) {
        const e = n;
        return e.init = t => r => n(r, t), e
    }

    const qf = n => Jf(n);

    async function Kf({editor: n, plan: e, pluginName: t, licenseKey: r, cleanup: i}) {
        let s = "", o = !1;
        const l = $f(), a = f => {
            console.warn("Cleanup plugin:", t, "Reason:", f), i()
        }, c = (f = {}) => {
            var m;
            const {error: h, sdkLicense: d} = f, u = (m = f.plan) == null ? void 0 : m.category;
            if (!(d || f.license) || h) a(h || "Invalid license"); else if (u) {
                const g = Mo[e], b = Mo[u];
                g > b && a({pluginRequiredPlan: e, licensePlan: u})
            }
        };
        n.on(Vf, f => {
            s = f == null ? void 0 : f.baseApiUrl, o = !0
        }), n.on(Ff, f => {
            c(f)
        })
    }

    async function jf(n) {
        const {licenseKey: e, pluginName: t, baseApiUrl: r} = n;
        try {
            return (await Wf({
                baseApiUrl: r,
                path: `/sdk/${e || "na"}`,
                method: "POST",
                params: {d: window.location.hostname, pn: t}
            })).result || {}
        } catch (i) {
            return console.error("Error during SDK license check:", i), !1
        }
    }

    const Bt = n => {
            const e = Object.fromEntries(Array.from(n.attributes).map(t => [t.name, t.value]));
            return delete e.draggable, e
        }, Oo = "data-gs-mrk-fs", No = "data-gs-ib", xn = "data-gs-ifrg", pe = "attrs", To = {[pe]: {default: "{}"}},
        me = {[pe]: {default: {}}}, Ao = n => ({[pe]: JSON.stringify(Bt(n))}), ge = n => ({attrs: Bt(n)}),
        Pt = n => e => [n, e.attrs.attrs, 0], Ie = n => n.attrs[pe] ? JSON.parse(n.attrs[pe]) : {}, Uf = {
            doc: {content: "block+"},
            text: {group: "inline", inline: !0},
            inlineFragment: {
                group: "block",
                content: "inline*",
                isTextBlock: !0,
                parseDOM: [{tag: `span[${xn}]`, getAttrs: ge}],
                toDOM: () => ["span", {[xn]: ""}, 0]
            },
            div: {group: "block", content: "inline*", attrs: me, parseDOM: [{tag: "div", getAttrs: ge}], toDOM: Pt("div")},
            paragraph: {
                group: "block",
                content: "inline*",
                attrs: me,
                parseDOM: [{tag: "p", getAttrs: ge}],
                toDOM: Pt("p")
            },
            orderedList: {
                group: "block",
                content: "listItem+",
                attrs: me,
                parseDOM: [{tag: "ol", getAttrs: ge}],
                toDOM: Pt("ol")
            },
            bulletList: {
                group: "block",
                content: "listItem+",
                attrs: me,
                parseDOM: [{tag: "ul", getAttrs: ge}],
                toDOM: Pt("ul")
            },
            listItem: {
                content: "block*",
                group: "block",
                attrs: me,
                parseDOM: [{tag: "li", getAttrs: ge}],
                toDOM: Pt("li"),
                defining: !0
            },
            codeBlock: {
                group: "block",
                content: "text*",
                marks: "",
                attrs: me,
                parseDOM: [{tag: "pre", getAttrs: ge}],
                toDOM: n => ["pre", n.attrs.attrs, ["code", 0]]
            },
            image: {
                inline: !0,
                group: "inline",
                selectable: !0,
                attrs: me,
                parseDOM: [{tag: "img[src]", getAttrs: ge}],
                toDOM: n => ["img", n.attrs.attrs]
            },
            inlineBreak: {
                inline: !0, group: "inline", selectable: !1, parseDOM: [{tag: `br[${No}]`}], toDOM() {
                    return ["br", {[No]: ""}]
                }
            },
            hardBreak: {
                inline: !1,
                group: "block",
                selectable: !1,
                attrs: me,
                parseDOM: [{tag: "br", getAttrs: ge}],
                toDOM: n => ["br", {...n.attrs.attrs}]
            },
            heading: {
                group: "block",
                content: "inline*",
                attrs: {level: {default: 1}, attrs: {default: {}}},
                defining: !0,
                parseDOM: Array.from({length: 6}, (n, e) => ({
                    tag: `h${e + 1}`,
                    getAttrs: t => ({level: e + 1, attrs: Bt(t)})
                })),
                toDOM({attrs: n}) {
                    const {level: e} = n;
                    return [e ? `h${e}` : "div", n.attrs, 0]
                }
            }, ...rf({
                tableGroup: "block",
                cellContent: "block+",
                cellAttributes: {
                    [pe]: {
                        default: me[pe].default, getFromDOM: Bt, setDOMAttr: (n, e) => {
                            n && Object.assign(e, n)
                        }
                    }, background: {
                        default: null, getFromDOM(n) {
                            return n.style.backgroundColor || null
                        }, setDOMAttr(n, e) {
                            n && (e.style = (e.style || "") + `background-color: ${n};`)
                        }
                    }
                }
            }),
            nonTextNode: {
                group: "block",
                content: "block*",
                attrs: {tagName: {default: "span"}, attrs: {default: {}}},
                parseDOM: [{
                    tag: "*:not(tbody)",
                    getAttrs: n => ({tagName: n.tagName.toLowerCase(), attrs: Bt(n)}),
                    priority: 0
                }],
                toDOM(n) {
                    const {tagName: e, attrs: t} = n.attrs;
                    return [e, t, 0]
                }
            }
        }, Vt = (n, e) => ({attrs: To, parseDOM: n.map(t => ({tag: t, getAttrs: Ao})), toDOM: e}), Gf = {
            strong: Vt(["strong", "b"], n => ["b", Ie(n)]),
            link: Vt(["a"], n => ["a", Ie(n), 0]),
            em: Vt(["em", "i"], n => ["em", Ie(n)]),
            underline: Vt(["u"], n => ["u", Ie(n), 0]),
            strikethrough: Vt(["s"], n => ["s", Ie(n), 0]),
            font_size: {
                attrs: {...To, size: {default: null}},
                parseDOM: [{tag: `span[${Oo}]`, getAttrs: n => ({...Ao(n), size: n.style.fontSize})}],
                toDOM(n) {
                    const {size: e} = n.attrs, t = {...Ie(n), [Oo]: !0};
                    return e && (t.style = `font-size: ${e}`), ["span", t, 0]
                }
            }
        }, Do = new rl({nodes: Uf, marks: Gf}), kn = new WeakMap, Or = new WeakMap, _f = (n, e) => {
            kn.set(n, e), Or.set(e, n)
        }, Xf = (n, e) => {
            kn.delete(n), Or.delete(e)
        }, Nr = n => kn.get(n), Yf = n => Or.get(n), Eo = n => {
            var t;
            const e = Yf(n);
            return (t = e == null ? void 0 : e.__gjsv) == null ? void 0 : t.model
        }, Zf = n => n.dispatchEvent(new CustomEvent("input"));

    function Qf(n) {
        const e = t => {
            if (t.tagName === "SPAN" && t.hasAttribute(xn)) {
                if (t.getAttribute("style")) {
                    t.removeAttribute(xn);
                    return
                }
                const r = t.parentElement;
                if (r) {
                    for (; t.firstChild;) r.insertBefore(t.firstChild, t);
                    r.removeChild(t)
                }
            } else Array.from(t.children).forEach(r => e(r))
        };
        e(n)
    }

    function eh(n, e = {}) {
        if (!e.enableOnClick) return () => {
        };
        const t = n.Components.events, r = f => n.getSelectedAll().includes(f),
            i = f => f.isInstanceOf("text") && !f.isChildOf("text"), s = f => f.isChildOf("text"),
            o = f => n.getEditing() === f, l = (f, h = {}) => {
                f.trigger("focus", h.event)
            }, a = (f, h) => {
                r(f) && i(f) && !o(f) && l(f, h)
            }, c = (f, h) => {
                if (r(f) && !i(f) && s(f)) {
                    const d = f.parents().find(u => u.isInstanceOf("text"));
                    d && (l(d, h), setTimeout(() => n.select(d), 0))
                }
            };
        return n.on(t.select, a), n.on(t.selectBefore, c), () => {
            n.off(t.select, a), n.off(t.selectBefore, c)
        }
    }

    const th = (n, e) => {
        const t = nh(n);
        return t && hh(t) ? rh(n, e) : t ? Ri(() => ({type: n.schema.nodes.div}))(n, e) : !1
    };

    function nh(n) {
        const e = n.selection.$from;
        if (e.node(e.depth).type === n.schema.nodes.inlineFragment) {
            const t = e.depth - 1;
            return e.node(t)
        }
        return e.node(e.depth)
    }

    function rh(n, e) {
        const {selection: t, schema: r, tr: i} = n;
        i.split(t.from, 1);
        const s = t.from + 1, o = i.doc.nodeAt(s), l = {...o.attrs.attrs, id: void 0}, a = o.textContent.length > 0,
            c = o.textContent.length || 0, f = o.textContent || " ", h = r.text(f),
            d = r.nodes.div.create(l, a ? h : [], []);
        return i.replaceRangeWith(s, s + c + 2, d), i.setSelection(C.create(i.doc, s + 1)), e == null || e(i.scrollIntoView()), !0
    }

    function ih(n, e, t) {
        const {state: r, dispatch: i} = n, {selection: s, tr: o} = r, l = (a, c, f) => {
            const h = {};
            return a.split(";").forEach(d => {
                const [u, p] = d.split(":").map(m => m.trim());
                u && (h[u] = p)
            }), h[c] = f, Object.entries(h).map(([d, u]) => `${d}: ${u}`).join("; ")
        };
        if (!s.empty || t) o.doc.nodesBetween(s.from, s.to, (a, c) => {
            var f, h;
            if (a.type === r.schema.nodes.image) {
                const d = l(((f = a.attrs.attrs) == null ? void 0 : f.style) || "", "float", e);
                o.setNodeMarkup(c, void 0, {...a.attrs, attrs: {...a.attrs.attrs, style: d}})
            } else if (a.type.isBlock) {
                const d = l(((h = a.attrs.attrs) == null ? void 0 : h.style) || "", "text-align", e);
                Ro(a) ? o.setBlockType(s.from, void 0, r.schema.nodes.div, {attrs: {style: d}}) : o.setNodeMarkup(c, void 0, {
                    ...a.attrs,
                    attrs: {...a.attrs.attrs, style: d}
                })
            }
        }); else {
            const a = r.doc.resolve(s.from), c = a.start(a.depth), f = r.doc.nodeAt(c);
            if (f != null && f.type.isBlock) {
                const h = l(f.attrs.style || "", "text-align", e);
                o.setNodeMarkup(c, void 0, {...f.attrs, style: h})
            }
        }
        o.docChanged && i(o.scrollIntoView())
    }

    const Ft = (n, e) => {
        const {from: t, to: r} = n.selection;
        let i = !1;
        return n.doc.nodesBetween(t, r, s => {
            if (i) return !1;
            s.marks.some(o => o.type === e) && (i = !0)
        }), i
    };

    function sh(n, e, t = "_blank") {
        const {state: r, dispatch: i} = n, {schema: s, selection: o, tr: l} = r, a = s.marks.link;
        try {
            const c = a.create({[pe]: JSON.stringify({href: e, target: t})});
            l.addMark(o.from, o.to, c), i(l.scrollIntoView())
        } catch (c) {
            console.error("Error applying link mark:", c)
        }
    }

    function oh(n, e) {
        const {state: t, dispatch: r} = n, {selection: i, tr: s} = t;
        if (i.empty) return;
        const o = t.schema.marks.font_size;
        if (!o) {
            console.error("Font size mark is not defined in the schema.");
            return
        }
        s.addMark(i.from, i.to, o.create({size: e})), r(s.scrollIntoView())
    }

    const Xe = (n, e) => {
            const {doc: t, selection: r} = n.state, i = t.resolve(r.from);
            for (let s = i.depth; s > 0; s--) {
                const o = i.node(s);
                if (e(o)) return {pos: s > 0 ? i.before(s) : 0, start: i.start(s), depth: s, node: o}
            }
        },
        lh = n => (n || "").split(";").map(e => e.split(":")).reduce((e, [t, r]) => (t = t.replace(/-./g, i => i.toUpperCase()[1]).trim(), e[t] = `${r}`.trim(), e), {});

    function ah(...n) {
        return (e, t) => {
            const r = o => {
                e = e.apply(o), t == null || t(o)
            }, i = n.pop();
            return n.reduce((o, l) => o || l(e, r), !1) && i !== void 0 && i(e, t)
        }
    }

    const ch = (n, e) => {
            const {state: t, dispatch: r} = n;
            if (e != null && e.event) {
                const {event: i} = e, s = n.posAtCoords({left: i.clientX, top: i.clientY});
                s != null && s.pos && r(t.tr.setSelection(C.create(t.doc, s.pos)))
            } else Ii(t, r);
            setTimeout(() => setTimeout(() => n.focus()))
        }, Tr = n => n.isBlock, Ro = n => n.type.name === "inlineFragment", fh = n => Tr(n) && !Ro(n),
        Io = n => n.type.name === "bulletList", vo = n => n.type.name === "orderedList",
        hh = n => n.type.name === "heading", dh = n => Io(n) || vo(n), zo = (n, e) => {
            var s, o;
            const t = (s = Xe(n, l => l.type === e)) == null ? void 0 : s.node, r = n.state.schema.nodes.listItem;
            let i;
            return t ? i = jn(r) : (o = Xe(n, dh)) != null && o.node ? i = ah(jn(r), Ji(e)) : i = Ji(e), i(n.state, n.dispatch)
        }, Bo = (n, e) => {
            const {selection: t} = n.state;
            return [...t.$from.marks(), ...t.$to.marks()].find(r => r.type.name === e)
        }, uh = n => {
            var o;
            const {view: e, prop: t, editor: r, propCSS: i} = n, s = (o = Xe(e, fh)) == null ? void 0 : o.node;
            if (s) {
                const l = s.attrs.attrs || {}, a = lh(l.style);
                if (t in a) return a[t] || "";
                if (l.id) {
                    const c = r.Components.getById(l.id);
                    return ((c == null ? void 0 : c.getStyle()) || {})[i] || ""
                }
            }
            return ""
        }, ph = n => {
            const {view: e, prop: t, markName: r, editor: i, propCSS: s} = n, o = Bo(e, r);
            if (o) {
                const l = o.attrs;
                if (l[t]) return l[t];
                if (l[pe]) {
                    const a = Ie(o).id;
                    if (a) {
                        const c = i.Components.getById(a);
                        return ((c == null ? void 0 : c.getStyle()) || {})[s] || ""
                    }
                }
            }
            return ""
        }, Po = (n, e) => {
            const {dispatch: t} = n, {nodes: r, marks: i} = n.state.schema;
            return {
                text: {
                    selected: () => {
                        const {selection: s, doc: o} = n.state;
                        return o.textBetween(s.from, s.to, " ")
                    }, replace: (s, o = {}) => {
                        const {state: l} = n, {from: a} = l.selection;
                        let c = l.tr.replaceSelectionWith(l.schema.text(s));
                        o.select && (c = c.setSelection(C.create(c.doc, a, a + s.length))), t == null || t(c)
                    }
                },
                bold: {toggle: () => $e(i.strong)(n.state, t), isActive: () => Ft(n.state, i.strong)},
                italic: {toggle: () => $e(i.em)(n.state, t), isActive: () => Ft(n.state, i.em)},
                underline: {toggle: () => $e(i.underline)(n.state, t), isActive: () => Ft(n.state, i.underline)},
                strikethrough: {
                    toggle: () => $e(i.strikethrough)(n.state, t),
                    isActive: () => Ft(n.state, i.strikethrough)
                },
                link: {
                    get: () => {
                        const s = Eo(n);
                        if (s != null && s.is("link")) return s.getAttributes();
                        {
                            const o = Bo(n, "link");
                            return o ? Ie(o) : {}
                        }
                    }, toggle: () => $e(i.link)(n.state, t), isActive: () => Ft(n.state, i.link), create: s => {
                        const o = Eo(n);
                        o != null && o.is("link") ? (o.addAttributes({
                            href: s.url,
                            target: s.target
                        }), n.focus()) : sh(n, s.url, s.target)
                    }
                },
                alignText: {
                    get: () => uh({view: n, editor: e, prop: "textAlign", propCSS: "text-align"}),
                    set: s => ih(n, s.value, !0)
                },
                fontSize: {
                    get: () => ph({view: n, editor: e, markName: "font_size", prop: "size", propCSS: "font-size"}),
                    set: s => oh(n, s.value)
                },
                image: {
                    open() {
                        const s = "assetLayout", {state: o, dispatch: l} = n, {selection: a, doc: c} = o,
                            f = c.textBetween(a.from, a.to, " "), h = {
                                id: s,
                                disablePropagation: !0,
                                placer: {type: "dialog", title: "Select image", size: "l"},
                                header: !1,
                                layout: {
                                    type: "panelAssets", onSelect: d => {
                                        const u = {alt: f, src: d.asset.getSrc()};
                                        l(o.tr.replaceSelectionWith(r.image.createAndFill({attrs: u})))
                                    }
                                }
                            };
                        e.runCommand(bn.layoutToggle, h)
                    }
                },
                heading: {
                    get: () => {
                        var o;
                        const s = (o = Xe(n, Tr)) == null ? void 0 : o.node;
                        return `${(s == null ? void 0 : s.attrs.level) || ""}`
                    }, set: ({value: s}) => {
                        var a;
                        const {state: o} = n, l = (a = Xe(n, Tr)) == null ? void 0 : a.node;
                        Xl(o.schema.nodes.heading, {
                            attrs: l == null ? void 0 : l.attrs.attrs,
                            level: s ? parseInt(s, 10) : 0
                        })(o, t)
                    }
                },
                listBullet: {
                    isActive: () => {
                        var s;
                        return !!((s = Xe(n, Io)) != null && s.node)
                    }, toggle: () => zo(n, r.bulletList)
                },
                listOrdered: {
                    isActive: () => {
                        var s;
                        return !!((s = Xe(n, vo)) != null && s.node)
                    }, toggle: () => zo(n, r.orderedList)
                }
            }
        };

    class ve {
        constructor(e, t, r = {}) {
            this.match = e, this.match = e, this.handler = typeof t == "string" ? mh(t) : t, this.undoable = r.undoable !== !1, this.inCode = r.inCode || !1
        }
    }

    function mh(n) {
        return function (e, t, r, i) {
            let s = n;
            if (t[1]) {
                let o = t[0].lastIndexOf(t[1]);
                s += t[0].slice(o + t[1].length), r += o;
                let l = r - i;
                l > 0 && (s = t[0].slice(o - l, o) + s, r = i)
            }
            return e.tr.insertText(s, r, i)
        }
    }

    const gh = 500;

    function yh({rules: n}) {
        let e = new ot({
            state: {
                init() {
                    return null
                }, apply(t, r) {
                    let i = t.getMeta(this);
                    return i || (t.selectionSet || t.docChanged ? null : r)
                }
            }, props: {
                handleTextInput(t, r, i, s) {
                    return Vo(t, r, i, s, n, e)
                }, handleDOMEvents: {
                    compositionend: t => {
                        setTimeout(() => {
                            let {$cursor: r} = t.state.selection;
                            r && Vo(t, r.pos, r.pos, "", n, e)
                        })
                    }
                }
            }, isInputRules: !0
        });
        return e
    }

    function Vo(n, e, t, r, i, s) {
        if (n.composing) return !1;
        let o = n.state, l = o.doc.resolve(e),
            a = l.parent.textBetween(Math.max(0, l.parentOffset - gh), l.parentOffset, null, "￼") + r;
        for (let c = 0; c < i.length; c++) {
            let f = i[c];
            if (l.parent.type.spec.code) {
                if (!f.inCode) continue
            } else if (f.inCode === "only") continue;
            let h = f.match.exec(a), d = h && f.handler(o, h, e - (h[0].length - r.length), t);
            if (d) return f.undoable && d.setMeta(s, {transform: d, from: e, to: t, text: r}), n.dispatch(d), !0
        }
        return !1
    }

    const bh = new ve(/--$/, "—"), xh = new ve(/\.\.\.$/, "…"),
        kh = new ve(/(?:^|[\s\{\[\(\<'"\u2018\u201C])(")$/, "“"), Sh = new ve(/"$/, "”"),
        Ch = new ve(/(?:^|[\s\{\[\(\<'"\u2018\u201C])(')$/, "‘"), wh = new ve(/'$/, "’"), Mh = [kh, Sh, Ch, wh];

    function Ar(n, e, t = null, r) {
        return new ve(n, (i, s, o, l) => {
            let a = t instanceof Function ? t(s) : t, c = i.tr.delete(o, l), f = c.doc.resolve(o), h = f.blockRange(),
                d = h && ai(h, e, a);
            if (!d) return null;
            c.wrap(h, d);
            let u = c.doc.resolve(o - 1).nodeBefore;
            return u && u.type == e && Zt(c.doc, o - 1) && (!r || r(s, u)) && c.join(o - 1), c
        })
    }

    function Fo(n, e, t = null) {
        return new ve(n, (r, i, s, o) => {
            let l = r.doc.resolve(s), a = t instanceof Function ? t(i) : t;
            return l.node(-1).canReplaceWith(l.index(-1), l.indexAfter(-1), e) ? r.tr.delete(s, o).setBlockType(s, s, e, a) : null
        })
    }

    function Oh(n) {
        return Ar(/^\s*>\s$/, n)
    }

    function Nh(n) {
        return Ar(/^(\d+)\.\s$/, n, e => ({order: +e[1]}), (e, t) => t.childCount + t.attrs.order == +e[1])
    }

    function Th(n) {
        return Ar(/^\s*([-+*])\s$/, n)
    }

    function Ah(n) {
        return Fo(/^```$/, n)
    }

    function Dh(n, e) {
        return Fo(new RegExp("^(#{1," + e + "})\\s$"), n, t => ({level: t[1].length}))
    }

    function Eh(n) {
        const e = Mh.concat(xh, bh);
        let t;
        return (t = n.nodes.blockquote) && e.push(Oh(t)), (t = n.nodes.orderedList) && e.push(Nh(t)), (t = n.nodes.bulletList) && e.push(Th(t)), (t = n.nodes.codeBlock) && e.push(Ah(t)), (t = n.nodes.heading) && e.push(Dh(t, 6)), yh({rules: e})
    }

    const Rh = "rteProseMirror", Ih = pt.free, ie = "rte:selectionchange", ee = {
        bold: '<svg viewBox="0 0 24 24"><path d="M13.5,15.5H10V12.5H13.5A1.5,1.5 0 0,1 15,14A1.5,1.5 0 0,1 13.5,15.5M10,6.5H13A1.5,1.5 0 0,1 14.5,8A1.5,1.5 0 0,1 13,9.5H10M15.6,10.79C16.57,10.11 17.25,9 17.25,8C17.25,5.74 15.5,4 13.25,4H7V18H14.04C16.14,18 17.75,16.3 17.75,14.21C17.75,12.69 16.89,11.39 15.6,10.79Z" /></svg>',
        italic: '<svg viewBox="0 0 24 24"><path d="M10,4V7H12.21L8.79,15H6V18H14V15H11.79L15.21,7H18V4H10Z" /></svg>',
        underline: '<svg viewBox="0 0 24 24"><path d="M5,21H19V19H5V21M12,17A6,6 0 0,0 18,11V3H15.5V11A3.5,3.5 0 0,1 12,14.5A3.5,3.5 0 0,1 8.5,11V3H6V11A6,6 0 0,0 12,17Z" /></svg>',
        strikethrough: '<svg viewBox="0 0 24 24"><path d="M7.2 9.8c-1.2-2.3.5-5 2.9-5.5 3.1-1 7.6.4 7.5 4.2h-3l-.1-.8c-.2-.6-.6-.9-1.2-1.1-.8-.3-2.1-.2-2.8.3C9 8.2 10.4 9.5 12 10H7.4l-.2-.2M21 13v-2H3v2h9.6l.6.2c.6.3 1.1.5 1.3 1.1.1.4.2.9 0 1.3-.2.5-.6.7-1.1.9-1.8.5-4-.2-3.9-2.4h-3c-.1 2.6 2.1 4.4 4.5 4.7 3.8.8 8.3-1.6 6.3-5.9l3.7.1Z"/></svg>',
        link: '<svg viewBox="0 0 24 24"><path d="M3.9,12C3.9,10.29 5.29,8.9 7,8.9H11V7H7A5,5 0 0,0 2,12A5,5 0 0,0 7,17H11V15.1H7C5.29,15.1 3.9,13.71 3.9,12M8,13H16V11H8V13M17,7H13V8.9H17C18.71,8.9 20.1,10.29 20.1,12C20.1,13.71 18.71,15.1 17,15.1H13V17H17A5,5 0 0,0 22,12A5,5 0 0,0 17,7Z" /></svg>',
        image: '<svg viewBox="0 0 24 24"><path d="M19,19H5V5H19M19,3H5A2,2 0 0,0 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5A2,2 0 0,0 19,3M13.96,12.29L11.21,15.83L9.25,13.47L6.5,17H17.5L13.96,12.29Z"></path></svg>',
        listBullet: '<svg viewBox="0 0 24 24"><path d="M7 5h14v2H7V5m0 8v-2h14v2H7M4 4.5A1.5 1.5 0 0 1 5.5 6 1.5 1.5 0 0 1 4 7.5 1.5 1.5 0 0 1 2.5 6 1.5 1.5 0 0 1 4 4.5m0 6A1.5 1.5 0 0 1 5.5 12 1.5 1.5 0 0 1 4 13.5 1.5 1.5 0 0 1 2.5 12 1.5 1.5 0 0 1 4 10.5M7 19v-2h14v2H7m-3-2.5A1.5 1.5 0 0 1 5.5 18 1.5 1.5 0 0 1 4 19.5 1.5 1.5 0 0 1 2.5 18 1.5 1.5 0 0 1 4 16.5Z"/></svg>',
        listOrdered: '<svg viewBox="0 0 24 24"><path d="M7 13v-2h14v2H7m0 6v-2h14v2H7M7 7V5h14v2H7M3 8V5H2V4h2v4H3m-1 9v-1h3v4H2v-1h2v-.5H3v-1h1V17H2m2.3-7a.8.8 0 0 1 .7.8c0 .1 0 .3-.2.5L3 13h2v1H2v-1l2-2H2v-1h2.3Z"/></svg>',
        alignTextLeft: '<svg viewBox="0 0 24 24"><path d="M3,3H21V5H3V3M3,7H15V9H3V7M3,11H21V13H3V11M3,15H15V17H3V15M3,19H21V21H3V19Z" /></svg>',
        alignTextCenter: '<svg viewBox="0 0 24 24"><path d="M3,3H21V5H3V3M7,7H17V9H7V7M3,11H21V13H3V11M7,15H17V17H7V15M3,19H21V21H3V19Z" /></svg>',
        alignTextRight: '<svg viewBox="0 0 24 24"><path d="M3,3H21V5H3V3M9,7H21V9H9V7M3,11H21V13H3V11M9,15H21V17H9V15M3,19H21V21H3V19Z" /></svg>',
        alignTextJustify: '<svg viewBox="0 0 24 24"><path d="M3,3H21V5H3V3M3,7H21V9H3V7M3,11H21V13H3V11M3,15H21V17H3V15M3,19H21V21H3V19Z" /></svg>'
    }, vh = (n, e) => {
        var a;
        const {editor: t, el: r} = n, i = kn.get(r), s = Po(i, t), o = {
                separator: {
                    type: "column",
                    style: {borderRightWidth: "1px", borderRightStyle: "solid", alignSelf: "stretch", margin: 3}
                },
                bold: {
                    id: "bold", icon: ee.bold, size: "s", type: "button", editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({active: s.bold.isActive()})
                        }
                    }, onClick: ({setState: c}) => {
                        s.bold.toggle(), c({active: s.bold.isActive()})
                    }
                },
                italic: {
                    id: "italic", icon: ee.italic, size: "s", type: "button", editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({active: s.italic.isActive()})
                        }
                    }, onClick: ({setState: c}) => {
                        s.italic.toggle(), c({active: s.italic.isActive()})
                    }
                },
                underline: {
                    id: "underline",
                    icon: ee.underline,
                    size: "s",
                    type: "button",
                    editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({active: s.underline.isActive()})
                        }
                    },
                    onClick: ({setState: c}) => {
                        s.underline.toggle(), c({active: s.underline.isActive()})
                    }
                },
                strikethrough: {
                    id: "strikethrough",
                    icon: ee.strikethrough,
                    size: "s",
                    type: "button",
                    editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({active: s.strikethrough.isActive()})
                        }
                    },
                    onClick: ({setState: c}) => {
                        s.strikethrough.toggle(), c({active: s.strikethrough.isActive()})
                    }
                },
                image: {id: "image", icon: ee.image, size: "s", type: "button", onClick: () => s.image.open()},
                link: {
                    id: "link", icon: ee.link, size: "s", type: "button", editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({active: s.link.isActive(), disabled: i.state.selection.empty})
                        }
                    }, onClick: ({event: c}) => {
                        const f = c.currentTarget || c.target, {
                                x: h,
                                y: d,
                                width: u,
                                height: p
                            } = f.getBoundingClientRect(), m = "linkLayout", g = () => t.runCommand(bn.layoutRemove, {id: m}),
                            b = s.link.get(), w = {
                                id: m,
                                style: {width: 240},
                                disablePropagation: !0,
                                placer: {type: "popover", closeOnClickAway: !0, x: h, y: d, w: u, h: p},
                                header: {label: "Link"},
                                layout: {
                                    type: "column",
                                    as: "form",
                                    style: {padding: "0 10px 15px", gap: 10},
                                    onSubmit: N => {
                                        N.preventDefault();
                                        const D = new FormData(N.currentTarget);
                                        s.link.create({url: D.get("url"), target: D.get("target")}), g()
                                    },
                                    children: [{
                                        type: "inputField",
                                        name: "url",
                                        label: "URL",
                                        placeholder: "eg. https://google.com",
                                        required: !0,
                                        value: (b == null ? void 0 : b.href) || "",
                                        onChange: ({value: N, setState: D}) => D({value: N})
                                    }, {
                                        type: "selectField",
                                        name: "target",
                                        label: "Open link in",
                                        emptyState: "Current window",
                                        value: (b == null ? void 0 : b.target) || "",
                                        options: [{id: "", label: "Current window"}, {id: "_blank", label: "New window"}],
                                        onChange: ({value: N, setState: D}) => D({value: N})
                                    }, {
                                        type: "row",
                                        style: {gap: 10, justifyContent: "end"},
                                        children: [s.link.isActive() && {
                                            type: "button",
                                            label: "Clear",
                                            buttonType: "button",
                                            onClick: () => {
                                                s.link.toggle(), g()
                                            }
                                        }, {type: "button", variant: "primary", label: "Submit", buttonType: "submit"}]
                                    }]
                                }
                            };
                        t.runCommand(bn.layoutToggle, w)
                    }
                },
                alignText: {
                    id: "alignText",
                    type: "buttonGroupField",
                    size: "s",
                    value: "",
                    options: [{id: "left", icon: ee.alignTextLeft}, {id: "center", icon: ee.alignTextCenter}, {
                        id: "right",
                        icon: ee.alignTextRight
                    }, {id: "justify", icon: ee.alignTextJustify}],
                    editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({value: s.alignText.get()})
                        }
                    },
                    onChange: ({value: c, setState: f}) => {
                        f({value: c}), s.alignText.set({value: c})
                    }
                },
                listBullet: {
                    id: "listBullet",
                    icon: ee.listBullet,
                    size: "s",
                    type: "button",
                    editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({active: s.listBullet.isActive()})
                        }
                    },
                    onClick: ({setState: c}) => {
                        s.listBullet.toggle(), c({active: s.listBullet.isActive()})
                    }
                },
                listOrdered: {
                    id: "listOrdered",
                    icon: ee.listOrdered,
                    size: "s",
                    type: "button",
                    editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({active: s.listOrdered.isActive()})
                        }
                    },
                    onClick: ({setState: c}) => {
                        s.listOrdered.toggle(), c({active: s.listOrdered.isActive()})
                    }
                },
                heading: {
                    id: "heading",
                    type: "selectField",
                    size: "s",
                    value: "",
                    emptyState: "Heading",
                    options: [{id: "", label: "Normal"}, {id: "1", label: "Heading 1"}, {
                        id: "2",
                        label: "Heading 2"
                    }, {id: "3", label: "Heading 3"}, {id: "4", label: "Heading 4"}, {
                        id: "5",
                        label: "Heading 5"
                    }, {id: "6", label: "Heading 6"}],
                    editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({value: s.heading.get()})
                        }
                    },
                    onChange: ({value: c, setState: f}) => {
                        f({value: c}), s.heading.set({value: c}), i.focus()
                    }
                },
                fontSize: {
                    id: "fontSize",
                    type: "selectField",
                    size: "s",
                    value: "",
                    emptyState: "Font size",
                    options: [{id: "8pt", label: "8pt"}, {id: "10pt", label: "10pt"}, {
                        id: "12pt",
                        label: "12pt"
                    }, {id: "14pt", label: "14pt"}, {id: "18pt", label: "18pt"}, {id: "24pt", label: "24pt"}, {
                        id: "36pt",
                        label: "36pt"
                    }],
                    editorEvents: {
                        [ie]: ({setState: c}) => {
                            c({value: s.fontSize.get()})
                        }
                    },
                    onChange: ({value: c, setState: f}) => {
                        f({value: c}), s.fontSize.set({value: c}), i.focus()
                    }
                }
            },
            l = [o.bold, o.italic, o.underline, o.strikethrough, o.image, o.link, o.listBullet, o.listOrdered, o.alignText, o.heading, o.fontSize];
        return ((a = e.toolbar) == null ? void 0 : a.call(e, {
            ...n,
            commands: s,
            layouts: o,
            proseMirror: {view: i},
            items: l
        })) || l
    };

    class zh {
        constructor(e, t, r) {
            this.editor = r, this.node = e, this.dom = document.createElement("img"), this.view = t, Object.keys(e.attrs.attrs).forEach(i => {
                this.dom.setAttribute(i, e.attrs.attrs[i])
            }), this.dom.addEventListener("dblclick", i => this.handleDoubleClick(i))
        }

        handleDoubleClick(e) {
            const {editor: t, view: r} = this;
            Po(r, t).image.open(), e.preventDefault()
        }

        update(e) {
            return e.type !== this.node.type ? !1 : (this.node = e, Object.keys(e.attrs.attrs).forEach(t => {
                this.dom.setAttribute(t, e.attrs.attrs[t])
            }), !0)
        }

        selectNode() {
            this.dom.style.outline = "2px solid #ffca6f"
        }

        deselectNode() {
            this.dom.style.outline = ""
        }
    }

    return qf(function (n, e = {}) {
        const t = {plugins: o => o.plugins, ...e}, r = (o, l) => {
            var p, m;
            const a = ((p = t.schema) == null ? void 0 : p.call(t, {editor: n, schema: Do})) || Do, {
                nodes: c,
                marks: f
            } = a, h = Ze.fromSchema(a).parse(o), d = st.create({
                doc: h,
                schema: a,
                plugins: (m = t.plugins) == null ? void 0 : m.call(t, {
                    editor: n,
                    Plugin: ot,
                    plugins: [Nf(), Pf(), Eh(a), la(), Kn({
                        Tab: fo(1),
                        "Shift-Tab": fo(-1)
                    }), Kn({
                        Enter: wt(Ei, ma(c.listItem), th),
                        "Shift-Enter": wt(Di, (g, b) => (b && b(g.tr.replaceSelectionWith(c.inlineBreak.create()).scrollIntoView()), !0)),
                        "Mod-z": $i,
                        "Mod-y": Wn,
                        "Mod-Shift-z": Wn,
                        "Mod-b": $e(f.strong),
                        "Mod-i": $e(f.em),
                        "Shift-Tab": jn(c.listItem),
                        Tab: ba(c.listItem)
                    }), Kn(Zl)]
                })
            }), u = new Xc({mount: o}, {
                state: d, dispatchTransaction(g) {
                    var z;
                    const {state: b} = u, w = b.apply(g), N = !b.doc.eq(w.doc);
                    u.updateState(w);
                    const D = !b.selection.eq(w.selection);
                    N && (Zf(((z = l == null ? void 0 : l.view) == null ? void 0 : z.el) || o), u.focus()), (D || N) && n.trigger(ie)
                }
            });
            return o.__rteView = u, u.setProps({
                nodeViews: {
                    image(g) {
                        return new zh(g, u, n)
                    }
                }
            }), u
        }, i = o => vh(o, t);
        n.setCustomRte({
            toolbar: i, parseContent: !0, async enable(o, l, a) {
                const c = Nr(o);
                if (c) return c;
                const f = r(o, a);
                return _f(o, f), ch(f, a), f
            }, disable(o) {
                const l = Nr(o);
                if (l) return Xf(o, l), l.destroy(), {forceSync: !0}
            }, getContent(o) {
                const l = Nr(o);
                if (l) {
                    const {schema: a, doc: c} = l.state, f = document.createElement("div"),
                        h = He.fromSchema(a).serializeFragment(c.content);
                    return h.childNodes.forEach(d => {
                        d.nodeType === Node.ELEMENT_NODE && d.innerHTML === "" && (d.innerHTML = "<br/>")
                    }), f.appendChild(h), Qf(f), o.classList.remove("ProseMirror-focused"), f.innerHTML
                }
                return o.innerHTML
            }
        });
        const s = eh(n, t);
        Kf({
            editor: n, licenseKey: t.licenseKey, plan: Ih, pluginName: Rh, cleanup: () => {
                n.RichTextEditor.customRte = void 0, s()
            }
        })
    })
});
