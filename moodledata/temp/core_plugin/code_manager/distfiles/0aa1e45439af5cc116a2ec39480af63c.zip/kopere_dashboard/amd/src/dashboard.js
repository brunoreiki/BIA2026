define(["jquery", 'core/ajax', 'core/notification'], function ($, ajax, notification) {
    return {
        start: function () {
            $.getJSON(M.cfg.wwwroot + "/local/kopere_dashboard/view-ajax.php", {
                classname: "dashboard",
                method: "monitor"
            }, function (data) {
                $("#dashboard-moodleinfo").html(data.html);
            });

            $.getJSON(M.cfg.wwwroot + "/local/kopere_dashboard/view-ajax.php", {
                classname: "dashboard",
                method: "last_grades"
            }, function (data) {
                $("#dashboard-last_grades").html(data.html);
            });

            $.getJSON(M.cfg.wwwroot + "/local/kopere_dashboard/view-ajax.php", {
                classname: "dashboard",
                method: "last_enroll"
            }, function (data) {
                $("#dashboard-last_enroll").html(data.html);
            });
        },
    };
});
