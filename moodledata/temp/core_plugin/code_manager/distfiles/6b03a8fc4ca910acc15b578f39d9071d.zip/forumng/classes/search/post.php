<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Search area class for document posts
 *
 * @package mod_forumng
 * @copyright 2017 The Open University
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace mod_forumng\search;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->dirroot . '/mod/forumng/mod_forumng.php');

/**
 * Search area class for document posts
 *
 * @package mod_forumng
 * @copyright 2017 The Open University
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class post extends \core_search\base_mod {

    /**
     * File area relate to Moodle file table.
     */
    const FILEAREA = [
        'ATTACHMENT' => 'attachment',
        'MESSAGE' => 'message'
    ];

    /** @var array Relevant context levels (module context) */
    protected static $levels = [CONTEXT_MODULE];

    /**
     * Calls function which returns required data for indexing forumng posts.
     *
     * @param int $modifiedfrom
     * @return \moodle_recordset|null
     */
    public function get_recordset_by_timestamp($modifiedfrom = 0) {
        return $this->get_document_recordset($modifiedfrom);
    }

    /**
     * Returns recordset containing required data for indexing forumng posts.
     *
     * @param int $modifiedfrom
     * @param \context|null $context
     * @return \moodle_recordset|null
     */
    public function get_document_recordset($modifiedfrom = 0, \context $context = null) {
        global $DB;

        list ($contextjoin, $contextparams) = $this->get_context_restriction_sql(
                $context, 'forumng', 'f');
        if ($contextjoin === null) {
            return null;
        }

        $sql = "SELECT f.id, f.course,
                       fp.id as forumpostid, fp.discussionid, fp.parentpostid, fp.userid, fp.created,
                       fp.modified as postmodified, fp.deleted,
                       fp.deleteuserid, fp.important, fp.mailstate, fp.oldversion, fp.edituserid, fp.subject, fp.message,
                       fp.messageformat, fp.attachments, fp.asmoderator,
                       fd.modified as discussionmodified, GREATEST(fp.modified, fd.modified) as modifyorder,
                       fd.groupid as groupid, fpd.subject as discussionsubject
                  FROM {forumng_posts} fp
                  JOIN {forumng_discussions} fd ON fp.discussionid = fd.id
                  JOIN {forumng} f ON fd.forumngid = f.id
                  JOIN {forumng_posts} fpd on fpd.id = fd.postid
          $contextjoin
                 WHERE MODIFYCOND
                   AND fp.deleted = 0
                   AND fd.deleted = 0
                   AND fp.oldversion = 0";

        // If we do the query with 'fp.modified >= ? OR fd.modified >= ?' then the database doesn't
        // use the modified index and it runs slowly, because of the OR. Doing it as two queries
        // with a UNION avoids that problem.
        $union = str_replace('MODIFYCOND', 'fp.modified >= ?', $sql) . ' UNION ' .
                str_replace('MODIFYCOND', 'fd.modified >= ?', $sql) . ' ORDER BY modifyorder ASC';
        $params = array_merge($contextparams, [$modifiedfrom]);
        $params = array_merge($params, $params);

        return $DB->get_recordset_sql($union, $params);
    }

    /**
     * Returns the document associated with this post id.
     *
     * @param \stdClass $record
     * @param array $options
     * @return bool|\core_search\document
     */
    public function get_document($record, $options = array()) {
        try {
            $cm = get_coursemodule_from_instance($this->get_module_name(), $record->id, $record->course);
            $context = \context_module::instance($cm->id);
        } catch (\dml_exception $ex) {
            // Don't throw an exception, apparently it might upset the search process.
            debugging('Error retrieving ' . $this->areaid . ' ' . $record->forumpostid .
                    ' document: ' . $ex->getMessage(), DEBUG_DEVELOPER);
            return false;
        }

        // Remember to check time modified between post and discussion.
        if ($record->discussionmodified > $record->postmodified) {
            $timemodified = $record->discussionmodified;
        } else {
            $timemodified = $record->postmodified;
        }

        // Construct the document instance to return.
        $doc = \core_search\document_factory::instance(
                $record->forumpostid, $this->componentname, $this->areaname);

        // Set document title.
        // Document title will be post title, if post's title is empty, use the discussion's title instead.
        $title = $record->subject;
        if (empty($title)) {
            $title = $record->discussionsubject;
        }
        $doc->set('title', content_to_text($title, false));

        // Set document content.
        $content = $record->message;
        $content = file_rewrite_pluginfile_urls($content, 'pluginfile.php', $context->id, $this->componentname,
                self::FILEAREA['MESSAGE'], $record->forumpostid);
        $doc->set('content', content_to_text($content, FORMAT_HTML));

        // Set document description1: discussion tags.
        $itemtags = $this->get_tag_by_discussion($record->discussionid);
        $itemtagstr = implode(' ', $itemtags);
        $doc->set('description1', content_to_text($itemtagstr, false));

        // Set other search metadata.
        $doc->set('contextid', $context->id);
        $doc->set('type', \core_search\manager::TYPE_TEXT);
        $doc->set('courseid', $record->course);
        $doc->set('modified', $timemodified);
        $doc->set('itemid', $record->forumpostid);
        $doc->set('owneruserid', \core_search\manager::NO_OWNER_ID);
        $doc->set('userid', $record->userid);

        // Store groupid if there is one.
        if ($record->groupid > 0) {
            $doc->set('groupid', $record->groupid);
        }

        // Set optional 'new' flag.
        if (isset($options['lastindexedtime']) && ($options['lastindexedtime'] < $record->created)) {
            // If the document was created after the last index time, it must be new.
            $doc->set_is_new(true);
        }

        return $doc;
    }

    /**
     * Whether the user can access the document or not.
     *
     * @param int $id Post ID
     * @return int
     * @throws \moodle_exception
     */
    public function check_access($id) {
        global $USER;

        // Get post instance and forum instance in an unique record.
        $postinstance = $this->get_post($id);

        if (empty($postinstance) || $postinstance->get_deleted()) {
            // This activity instance was deleted.
            return \core_search\manager::ACCESS_DELETED;
        }

        if ($postinstance->is_old_version()) {
            // This post was an old version.
            return \core_search\manager::ACCESS_DELETED;
        }

        $discussion = $postinstance->get_discussion();
        if (!$discussion->can_view($USER->id)) {
            return \core_search\manager::ACCESS_DENIED;
        } else {
            // If forum's type is iPud then can_view() will return true even when
            // student don't have permission to view both Forum view and SC view.
            $forum = $discussion->get_forum();
            // Check this forum type is iPud.
            if (is_a($forum->get_type(), 'forumngtype_ipud')) {
                // Check if current user can view SC view.
                $loc = $discussion->get_location();
                preg_match('/id=(.+)&/U', $loc, $matches);
                if (!empty($matches[1]) && is_numeric($matches[1]) && strpos($loc, '/mod/oucontent/') !== false) {
                    list(, $cm) = get_course_and_cm_from_cmid($matches[1], 'oucontent');
                    if (!empty($cm) && !$cm->uservisible) {
                        return \core_search\manager::ACCESS_DENIED;
                    }
                }
            }
        }

        return \core_search\manager::ACCESS_GRANTED;
    }

    /**
     * Returns the specified forumng post.
     *
     * @param int $postid
     * @return \mod_forumng_post|boolean Post object
     */
    protected function get_post($postid) {
        return \mod_forumng_post::get_from_id($postid, \mod_forumng::CLONE_DIRECT, false, false, 0, true);
    }

    /**
     * Link to the forumng discussion page
     *
     * @param \core_search\document $doc Document instance returned by get_document function
     * @return \moodle_url
     */
    public function get_doc_url(\core_search\document $doc) {
        $postintance = $this->get_post($doc->get('itemid'));
        $discussion = $postintance->get_discussion();
        $forum = $discussion->get_forum();

        // Check if forum's type is iPud then we'll return the link lead to SC view.
        if (is_a($forum->get_type(), 'forumngtype_ipud')) {
            $url = new \moodle_url($postintance->get_discussion()->get_location());
        } else {
            $url = new \moodle_url('/mod/forumng/discuss.php?' .
                    $postintance->get_discussion()->get_link_params(\mod_forumng::PARAM_PLAIN) . '#p' . $postintance->get_id());
        }

        return $url;
    }

    /**
     * Link to the forumng discussion page
     *
     * @param \core_search\document $doc Document instance returned by get_document function
     * @return \moodle_url
     */
    public function get_context_url(\core_search\document $doc) {
        return $this->get_doc_url($doc);
    }

    /**
     * Returns true if this area uses file indexing.
     *
     * @return bool
     */
    public function uses_file_indexing() {
        return true;
    }

    /**
     * Add the attached description files.
     *
     * @param \core_search\document $document The current document
     * @return null
     */
    public function attach_files($document) {
        $fs = get_file_storage();
        $files = array();

        foreach (self::FILEAREA as $area) {
            $files = array_merge($files, $fs->get_area_files($document->get('contextid'), $this->componentname, $area,
                    $document->get('itemid'), 'sortorder DESC, id ASC'));
        }

        foreach ($files as $file) {
            if ($file->get_filename() == '.') {
                continue;
            }

            $document->add_stored_file($file);
        }
    }

    /**
     * Returns the module name.
     *
     * @return string
     */
    protected function get_module_name() {
        return substr($this->componentname, 4);
    }

    /**
     * Returns array of tag display names
     *
     * @param int $discussionid
     * @return string[]
     */
    public function get_tag_by_discussion($discussionid) {
        return \core_tag_tag::get_item_tags_array('mod_forumng', 'forumng_discussions',
            $discussionid);
    }

    /**
     * Indicates that this search area may restrict access by group.
     *
     * @return bool True
     */
    public function supports_group_restriction() {
        return true;
    }

    /**
     * Used to change ordering within the get_contexts_to_reindex
     * function.
     *
     * It returns 2 values:
     * - Extra SQL joins (tables course_modules 'cm' and context 'x' already exist).
     * - An ORDER BY value which must use aggregate functions, by default 'MAX(cm.added) DESC'.
     *
     * @return string[] Array with 2 elements; extra joins for the query, and ORDER BY value
     */
    protected function get_contexts_to_reindex_extra_sql() {
        return ['JOIN {forumng_discussions} fd ON fd.forumngid = cm.instance',
                'MAX(fd.modified) DESC'];
    }
}
