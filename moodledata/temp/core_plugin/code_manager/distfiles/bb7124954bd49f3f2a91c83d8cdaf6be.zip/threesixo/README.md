![Build Status](https://github.com/junpataleta/moodle-mod_threesixo/actions/workflows/moodle-ci.yml/badge.svg)
[![codecov](https://codecov.io/github/junpataleta/moodle-mod_threesixo/graph/badge.svg?token=45OB4RGUK9)](https://codecov.io/github/junpataleta/moodle-mod_threesixo)


# mod_threesixo
A 360-degree feedback plugin for Moodle
