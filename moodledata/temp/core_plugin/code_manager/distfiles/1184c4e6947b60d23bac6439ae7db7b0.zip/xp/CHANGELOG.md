Changelog
=========

v2.1.2
------

- Minor coding style changes

v2.1.1
------

- Renamed plugin to Level Up XP Availability

v2.1.0
------

- Implemented ability to restrict to a specific level

v2.0.4
------

- Implement privacy API (GDPR compliance) - Jan Dageförde

v2.0.3
------

- Fixed error when the user is not logged in and not a guest

v2.0.2
------

- Fix for restoring xp backup files with availability - Adrian Greeve

v2.0.1
------

- Fixed a bug causing the plugin to be broken in Boost - Adrian Greeve
- Gracefully handle case where required level is greater than max level

v2.0.0
------

- Compatibility with Level up! v3.x
