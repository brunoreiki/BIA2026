![Build Status](https://github.com/junpataleta/moodle-mod_threesixo/actions/workflows/moodle-ci.yml/badge.svg)

# mod_threesixo
A 360-degree feedback plugin for Moodle
