========
Moderate
========

---------
Main View
---------

In the main view, students can only preview, edit or delete their own questions. Teachers and teachers on the other hand can preview, edit and delete all questions.
Additionally, the approved column has turned into clickable links, which allows teachers to un-/approve questions.

.. image:: ../_images/overview.png
	:align: center
