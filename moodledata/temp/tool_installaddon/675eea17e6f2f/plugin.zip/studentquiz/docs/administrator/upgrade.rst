Upgrade
=======

Manually, the same steps as install_.

Moodle also provides you a hint when there are new versions, once you logged in as admin or when you Open 'Site administration > Notifications'

**Important**:
  We highly recommend you to `read the release notes on github`_ for more insights about the changes

.. _install:
.. _read the release notes on github: https://github.com/frankkoch/moodle-mod_studentquiz/releases
