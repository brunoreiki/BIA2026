module.exports = {
  output: {
    chunkLoadingGlobal: 'webpackJsonpSnapCE'
  }
};
